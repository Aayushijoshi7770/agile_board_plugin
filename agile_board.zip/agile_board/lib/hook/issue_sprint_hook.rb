module Hook
    class IssueSprintHook < Redmine::Hook::ViewListener
        def controller_issues_edit_after_save(context = {})
            update_sprint_value(context[:issue], context[:params])
        end
      
        def controller_issues_new_after_save(context = {})
            update_sprint_value(context[:issue], context[:params])
        end
      
          private
      
        def update_sprint_value(issue, params)
            if params[:issue].key?(:sprint_craft)
                sprint_craft = params[:issue][:sprint_craft]
                issue.update_column(:sprint_craft, sprint_craft.present? ? sprint_craft : nil)
            end
        end
    end
end