module Hook
    class BulkUpdateHook < Redmine::Hook::ViewListener
  
        def controller_issues_bulk_edit_before_save(context = {})
          issues = context[:issue]
          params = context[:params]
          update_bulk_values(issues, params)
        end
    
        private
      
      
        # def update_bulk_values(issues, params)
        #   # Ensure that issues is an array
        #   issues = [issues] unless issues.is_a?(Array)
        
        #   issues.each do |issue|
        #     begin
        #       sprint_craft_params = params[:issue][:sprint_craft]
        #       sprint_params = params[:issue][:sprint]
        #       
        #       if sprint_craft_params.present?
        #         puts "good work"
        #         sprint_craft = sprint_craft_params
        #         # Update the sprint_craft attribute in the database
        #         issue.update_column(:sprint_craft, sprint_craft)
        #         # Debugging output to verify the update
        #         Rails.logger.info("Updated sprint_craft for issue #{issue.id} to #{sprint_craft}")
        #       end
        
        #       if sprint_params.present?
                
        #         sprint = sprint_params
        #         # Update the sprint attribute in the database
        #         issue.update_column(:sprint, sprint)
        #         # Debugging output to verify the update
        #         Rails.logger.info("Updated sprint for issue #{issue.id} to #{sprint}")
        #       end
        #     rescue => e
        #       # Error handling in case of any exceptions
        #       Rails.logger.error("Error updating issue #{issue.id}: #{e.message}")
        #     end
        #   end
        # end

        
        def update_bulk_values(issues, params)
          # Ensure that issues is an array
          issues = [issues] unless issues.is_a?(Array)
    
          issues.each do |issue|
            begin
              sprint_craft_params = params[:issue][:sprint_craft]
              # sprint_params = params[:issue][:sprint]
              story_points_params = params[:issue][:story_points]
    
              if sprint_craft_params.present?
                sprint_craft = sprint_craft_params
                # Update the sprint_craft attribute in the database
                issue.update_column(:sprint_craft, sprint_craft)
                # Debugging output to verify the update
                Rails.logger.info("Updated sprint_craft for issue #{issue.id} to #{sprint_craft}")
              end
    
              if story_points_params.present?
                story_points = story_points_params.first.to_i
                # Update the story_points attribute in the database
                issue.update_column(:story_points, story_points)
                # Debugging output to verify the update
                Rails.logger.info("Updated story_points for issue #{issue.id} to #{story_points}")
              end
            rescue => e
              # Error handling in case of any exceptions
              Rails.logger.error("Error updating issue #{issue.id}: #{e.message}")
            end
          end
        end
     end
end
  