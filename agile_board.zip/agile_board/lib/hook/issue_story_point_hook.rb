module Hook
    class IssueStoryPointHook < Redmine::Hook::ViewListener
        def controller_issues_edit_after_save(context = {})
            update_story_point_value(context[:issue], context[:params])
        end
      
        def controller_issues_new_after_save(context = {})
            update_story_point_value(context[:issue], context[:params])
        end
      
          private
      
        def update_story_point_value(issue, params)
            if params[:issue].key?(:story_points)
                story_points = params[:issue][:story_points]
                issue.update_column(:story_points, story_points.present? ? story_points : nil)
            end
        end
    end
end