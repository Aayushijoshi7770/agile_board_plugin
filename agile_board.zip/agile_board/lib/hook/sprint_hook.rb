module Hook
 class SprintHook < Redmine::Hook::ViewListener
    render_on :view_issues_form_details_bottom,:partial => 'issues/sprint_field'
    render_on :view_issues_show_details_bottom, :partial => 'issues/issue_sprint_details'
    render_on :view_layouts_base_content, :partial => 'agileboard/agile_board_menu'
  end
end