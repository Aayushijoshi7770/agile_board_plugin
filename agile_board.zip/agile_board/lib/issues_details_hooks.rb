class IssuesDetailsHooks < Redmine::Hook::ViewListener
    def protect_against_forgery?
        false
    end

    def current_is_detail_page(context)
        ret = context[:controller] && context[:controller].is_a?(IssuesController) && context[:request].original_url.rindex(/\/issues\/\S+/) && !context[:request].original_url.rindex(/\/issues\/new/) && !context[:request].original_url.rindex(/\/issues\/\d+\/edit/)
    end


    def view_layouts_base_html_head(context)
        # return unless current_is_detail_page(context)

        # if User.current.allowed_to?(:edit_issues, context[:project]
        stylesheet_link_tag('jkanban.css', :plugin => :agile_board)+
        javascript_include_tag('jkanban.js', :plugin => :agile_board)+
        javascript_include_tag('project_flow.js', :plugin => :agile_board)+
        javascript_include_tag('issue_navigation.js', :plugin => :agile_board)
        # end

    end
    def view_layouts_base_body_bottom(context)
        return unless current_is_detail_page(context)

        if User.current.allowed_to?(:edit_issues, context[:project])
            # javascript_include_tag('jkanban.js', :plugin => :agile_board)
        end
    end 



end