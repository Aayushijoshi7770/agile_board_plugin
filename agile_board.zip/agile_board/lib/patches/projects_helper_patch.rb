


module Patches
  module ProjectsHelperPatch
    
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          unloadable

          alias_method :project_settings_tabs_without_sprints_settings, :project_settings_tabs
          alias_method :project_settings_tabs, :project_settings_tabs_with_sprints_settings
        end
      end

      module InstanceMethods
        def project_settings_tabs_with_sprints_settings
          tabs = project_settings_tabs_without_sprints_settings

          if User.current.allowed_to?(:manage_sprints, @project) 
            tabs.push(name: 'sprints',
                      partial: 'sprints/index',
                      label: 'tab_sprints')
            end
          tabs
        end
      end
    end
  end



base = ProjectsHelper
patch = Patches::ProjectsHelperPatch
base.send(:include, patch) unless base.included_modules.include?(patch)