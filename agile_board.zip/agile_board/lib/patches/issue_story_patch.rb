module Patches
    module IssueStoryPatch
        
                def self.included(base)
                    base.send :include, InstanceMethods
                    base.class_eval do 

                        alias_method :available_filters_without_sprint, :available_filters
                        alias_method :available_filters, :available_filters_with_sprint

                        alias_method :sql_for_field_without_sprint_craft, :sql_for_field
                        alias_method :sql_for_field, :sql_for_field_with_sprint_craft

                        alias_method :add_filter_error_without_override, :add_filter_error
                        alias_method :add_filter_error, :add_filter_error_with_override
        
                        alias_method :available_columns_without_story_point, :available_columns
                        alias_method :available_columns, :available_columns_with_story_point
                    end 
                end
            end
            
            module InstanceMethods

                def sql_for_field_with_sprint_craft(field, operator, value, db_table, db_field, is_custom_filter = false)
                    case field
                    when 'sprint'
                      sprint_craft_condition( operator , value)
                    else
                      sql_for_field_without_sprint_craft(field, operator, value, db_table, db_field, is_custom_filter)
                    end
                  end

                  def add_filter_error_with_override(field, message)
                    field_label = field.is_a?(Symbol) ? field.to_s.capitalize : label_for(field)
                    m = "#{field_label} #{l(message, :scope => 'activerecord.errors.messages')}"
                    errors.add(:base, m)
                  end

                def available_filters_with_sprint
                    if @available_filters.blank?
                      
                      
                         if project.present?
                            add_available_filter('sprint', :type => :list_optional, :name => (:Sprint),
                             values:  project.filter_sprints.map { |sprint| [sprint.name, sprint.id.to_s] }                           
                            ) if !available_filters_without_sprint.key?('sprint')
                            
                         else
                              add_available_filter('sprint', :type => :list_optional, :name => (:Sprint),
                              values: SprintCraft.all.map{|sprint| [sprint.name, sprint.id.to_s] }
                              ) if !available_filters_without_sprint.key?('sprint')
                              
                         end
                    else
                        available_filters_without_sprint
                    end
                  @available_filters
                end 
        
                def available_columns_with_story_point
                    if @available_columns.blank?
                      @available_columns = available_columns_without_story_point
                      if Setting.plugin_agile_board['story_points'].present? && Setting.plugin_agile_board['story_points']['enabled'] == '1'
                         @available_columns << QueryColumn.new(:story_points , :totalable => true)

                        def total_for_story_points(scope)
                           map_total(scope.sum(:story_points)) {|t| t.to_f.round(2)}
                        end
                      end

                    else
                      @available_columns_without_story_point
                    end
                    @available_columns
                end

                private

                def sprint_craft_condition(operator , value)
                    if value.present? && value.any?(&:present?)
                      sprint_craft_ids = value.map(&:to_i)
                      "#{Issue.table_name}.sprint_craft IN (#{sprint_craft_ids.join(',')})"
                      case operator
                        when "="
                            "#{Issue.table_name}.sprint_craft IN (#{sprint_craft_ids.join(',')})"
                        when "!"
                            "#{Issue.table_name}.sprint_craft NOT IN (#{sprint_craft_ids.join(',')})"
                        else
                            ''
                        end
                    elsif operator == "!*"
                        "#{Issue.table_name}.sprint_craft IS NULL"
                    elsif operator == "*"
                        "#{Issue.table_name}.sprint_craft IS NOT NULL"
                    else 
                      ''
                    end 
                end

            
            end 
        end 
        
        base = IssueQuery
        patch = Patches::IssueStoryPatch
        base.send(:include, patch) unless base.included_modules.include?(patch)