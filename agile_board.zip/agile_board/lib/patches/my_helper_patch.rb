module Patches
    module MyHelperPatch
        def self.included(base)

            base.send(:include, InstanceMethods)

            base.class_eval do
                def render_agile_board(block, settings)
                    render :partial => 'my/blocks/agile_board'
                end
            end
        end
        module InstanceMethods

        end
    end
end

unless MyHelper.included_modules.include?(Patches::MyHelperPatch)
    MyHelper.send(:include, Patches::MyHelperPatch)
end