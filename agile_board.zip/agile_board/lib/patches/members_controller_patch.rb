module Patches
  module MembersControllerPatch
    def self.included(base)
      base.send(:include, InstanceMethods)
      base.class_eval do
        alias_method :create_without_selected_users, :create
        alias_method :create, :create_with_selected_users
      end
    end
  
    module InstanceMethods
      def create_with_selected_users
        if params[:selected_users].present?
          members = []
          user_ids = params[:selected_users].scan(/\d+/)
          Rails.logger.info("User IDs ==: #{user_ids}")
          if user_ids.any?
            user_ids.each do |user_id|
              member = Member.new(project: @project, user_id: user_id)
              member.set_editable_role_ids(params[:membership][:role_ids])
              members << member
            end
            @project.members << members
          end
  
          respond_to do |format|
            format.html { redirect_to_settings_in_projects }
            format.js do
              @members = members
              @member = Member.new
            end
            format.api do
              @member = members.first
              if @member.valid?
                render action: 'show', status: :created, location: membership_url(@member)
              else
                render_validation_errors(@member)
              end
            end
          end
        else
          create_without_selected_users 
        end
      end
    end
  end

end 
  # MembersController.send(:include, MembersControllerPatch)
base = MembersController
patch = Patches::MembersControllerPatch
base.send(:include, patch) unless base.included_modules.include?(patch)
  