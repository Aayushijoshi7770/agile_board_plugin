
module Patches
  module ProjectSprintsPatch
    def self.included(base)
      base.class_eval do

        def shared_sprints
          if new_record?
            SprintCraft.
              joins(:project).
              preload(:project).
              where("#{Project.table_name}.status <> ? AND #{SprintCraft.table_name}.sharing = ? AND #{SprintCraft.table_name}.status IN (?)",
                    Project::STATUS_ARCHIVED, SprintCraft.sharings[:with_all_projects], 
                    [SprintCraft.statuses[:open], SprintCraft.statuses[:active]])
          else
            r = root? ? self : root
            SprintCraft.
              joins(:project).
              preload(:project).
              where(
                "#{Project.table_name}.id = ?" \
                " OR (#{Project.table_name}.status <> ? AND (" \
                " #{SprintCraft.table_name}.sharing = ?" \
                " OR (#{Project.table_name}.lft >= ? AND #{Project.table_name}.rgt <= ? AND #{SprintCraft.table_name}.sharing = ?)" \
                " OR (#{Project.table_name}.lft BETWEEN ? AND ? AND #{SprintCraft.table_name}.sharing = ?)" \
                " OR (#{Project.table_name}.lft < ? AND #{Project.table_name}.rgt > ? AND #{SprintCraft.table_name}.sharing IN (?, ?))" \
                " OR (#{Project.table_name}.lft > ? AND #{Project.table_name}.rgt < ? AND #{SprintCraft.table_name}.sharing = ?)" \
                "))",
                id, Project::STATUS_ARCHIVED,
                SprintCraft.sharings[:with_all_projects],
                r.lft, r.rgt, SprintCraft.sharings[:with_project_tree],
                r.lft, r.rgt, SprintCraft.sharings[:with_subprojects],
                lft, rgt, SprintCraft.sharings[:with_project_hierarchy], SprintCraft.sharings[:descendants],
                lft, rgt, SprintCraft.sharings[:with_project_hierarchy]
              ).where("#{SprintCraft.table_name}.status IN (?)",
                [SprintCraft.statuses[:open], SprintCraft.statuses[:active]])
          end
        end

        def filter_sprints
          if new_record?
            SprintCraft.
              joins(:project).
              preload(:project).
              where("#{Project.table_name}.status <> ? AND #{SprintCraft.table_name}.sharing = ?",
                    Project::STATUS_ARCHIVED, SprintCraft.sharings[:with_all_projects])
          else
            r = root? ? self : root
            SprintCraft.
              joins(:project).
              preload(:project).
              where(
                "#{Project.table_name}.id = ?" \
                " OR (#{Project.table_name}.status <> ? AND (" \
                " #{SprintCraft.table_name}.sharing = ?" \
                " OR (#{Project.table_name}.lft >= ? AND #{Project.table_name}.rgt <= ? AND #{SprintCraft.table_name}.sharing = ?)" \
                " OR (#{Project.table_name}.lft BETWEEN ? AND ? AND #{SprintCraft.table_name}.sharing = ?)" \
                " OR (#{Project.table_name}.lft < ? AND #{Project.table_name}.rgt > ? AND #{SprintCraft.table_name}.sharing IN (?, ?))" \
                " OR (#{Project.table_name}.lft > ? AND #{Project.table_name}.rgt < ? AND #{SprintCraft.table_name}.sharing = ?)" \
                "))",
                id, Project::STATUS_ARCHIVED,
                SprintCraft.sharings[:with_all_projects],
                r.lft, r.rgt, SprintCraft.sharings[:with_project_tree],
                r.lft, r.rgt, SprintCraft.sharings[:with_subprojects],
                lft, rgt, SprintCraft.sharings[:with_project_hierarchy], SprintCraft.sharings[:descendants],
                lft, rgt, SprintCraft.sharings[:with_project_hierarchy]
              ) 
        end
      end

        private

        def sub_project_ids
          project.self_and_descendants.map(&:id)
        end

      end
    end
  end
end



base = Project
patch = Patches::ProjectSprintsPatch
base.send(:include, patch) unless base.included_modules.include?(patch)



