# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html

get '/agile_board', to: 'agile#index'
get '/search_users', to: 'search_users#index'
get 'project_issues_data', to: 'search_users#project_issues'
get '/tracker_workflow_status', to: 'agile#create'
get 'agile_custom_fields', to: 'agile#all_custom_fields'

# version controller route 
get '/agile_versions', to: 'agile_versions#index'
get '/agile_versions/sprints', to: 'agile_versions#sprints'


get 'agile_board_setting' , to: 'agile_settings#index'
get 'agile_card_field' , to: 'agile_settings#card_field_name'
get 'agile_color_name' , to: 'agile_settings#agile_by_color_name'
get 'agile_total_time' , to:'agile_settings#agile_total_time'
get 'agile_issue_statuses' , to:'agile_settings#agile_issue_status'
get '/projects/:id/actived_users' , to: 'agile_settings#actived_users'

post 'agile_board_setting' , to:'agile_settings#create_agile_board'
put 'agile_board_setting/:user_id', to: 'agile_settings#update_agile_board'

get 'board_column_values', to: 'agile_settings#board_columns'
put 'board_columns', to: 'agile_settings#board_column_settings'
put 'update_agiles_boards', to:'agile_settings#update_agiles'
put 'update_wip_limits', to: 'agile_settings#update_wip_limits'

get 'card_fields' ,to: 'agile_settings#card_fields'
put 'card_field_update' , to: 'agile_settings#card_field_settings'

 get 'color_time' ,to: 'agile_settings#color_and_times'
get 'all_colors' ,to: 'agile_settings#colors_all'
# get 'color_optionss' ,to: 'agile_settings#color_optionss'
put 'color_update' ,to: 'agile_settings#color_settings'

get 'total_time' ,to: 'agile_settings#time_field'
put 'total_time_update' ,to: 'agile_settings#time_field_settings'

get 'show/tags' ,to: 'agile#get_tags'

# get counts of notes 
get 'notes/count' , to:'agile#notes_count'
resources :sprint_crafts

put 'update/setting/options', to:'agile_versions#updateSetting'

get 'get/users/permissions',  to:'agile#user_permissions'

# Add routes for CustomAgileBoardsController
# get 'custom_agile_boards', to: 'custome_agile_boards#index'
# get 'custom_agile_boards/new', to: 'custome_agile_boards#new'
# post 'custom_agile_boards', to: 'custome_agile_boards#create'
# get 'custom_agile_boards/:id/edit', to: 'custome_agile_boards#edit'
# config/routes.rb

# Define routes with project_id as a parameter
 get 'custom_agile_boards', to: 'custome_agile_boards#index'
get 'projects/:project_id/custom_agile_boards/new', to: 'custome_agile_boards#new', as: 'new_custom_agile_board'
post 'projects/:project_id/custom_agile_boards', to: 'custome_agile_boards#create', as: 'create_custom_agile_board'
get 'projects/:project_id/custom_agile_boards/:id/edit', to: 'custome_agile_boards#edit', as: 'edit_custom_agile_board'
patch 'projects/:project_id/custom_agile_boards/:id/update', to: 'custome_agile_boards#update', as: 'update_custom_agile_board'
delete 'projects/:project_id/custom_agile_boards/:id/delete', to: 'custome_agile_boards#destroy', as: 'delete_custom_agile_board'
get 'projects/:project_id/custom_agile_boards/:id', to: 'custome_agile_boards#show', as: 'custom_agile_board'
post 'projects/custom_agile_boards_setting/:id', to: 'custome_agile_boards#update_setting', as: 'update_board_setting'

delete '/custom_agileBoard_delete/:id', to: 'custome_agile_boards#custom_agileBoard_delete'