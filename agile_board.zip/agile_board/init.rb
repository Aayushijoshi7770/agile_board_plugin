if Redmine::VERSION::MAJOR == 4
  require_relative './lib/patches/my_helper_patch.rb'
  require_relative './lib/hooks.rb'
  require_relative './lib/issues_details_hooks.rb'
  require_relative './lib/patches/members_controller_patch.rb'
  require_relative './lib/patches/members_helper_patch.rb'

  require File.expand_path('./lib/patches/projects_helper_patch.rb',__dir__)
  require File.expand_path('./lib/hook/sprint_hook.rb',__dir__)
  require File.expand_path('./lib/hook/issue_sprint_hook.rb',__dir__)
  require File.expand_path('./lib/hook/issue_story_point_hook.rb',__dir__)
  require File.expand_path('./lib/patches/issue_story_patch.rb',__dir__)
  require File.expand_path('./lib/patches/project_sprints_patch.rb',__dir__)
  require File.expand_path('./lib/hook/bulk_edit_hook.rb', __dir__)
  require File.expand_path('./lib/hook/bulk_update_hook.rb', __dir__)
  
  
  elsif  Redmine::VERSION::MAJOR == 5
    require File.expand_path('./lib/patches/my_helper_patch.rb', __dir__)
    require File.expand_path('./lib/hooks.rb', __dir__)
    require File.expand_path('./lib/issues_details_hooks.rb', __dir__)
    require File.expand_path('./lib/patches/members_controller_patch.rb', __dir__)
    require File.expand_path('./lib/patches/members_helper_patch.rb',__dir__)
  
  
    require File.expand_path('./lib/patches/projects_helper_patch.rb',__dir__)
    require File.expand_path('./lib/hook/sprint_hook.rb',__dir__)
    require File.expand_path('./lib/hook/issue_sprint_hook.rb',__dir__)
    require File.expand_path('./lib/hook/issue_story_point_hook.rb',__dir__)
    require File.expand_path('./lib/patches/issue_story_patch.rb',__dir__)
    require File.expand_path('./lib/patches/project_sprints_patch.rb',__dir__)
    require File.expand_path('./lib/hook/bulk_edit_hook.rb', __dir__)
    require File.expand_path('./lib/hook/bulk_update_hook.rb', __dir__)
  
  end
  
  
  Redmine::Plugin.register :agile_board do
    name 'Redmineflux Agile Board Plugin'
    author 'Redmineflux - Powered by Zehntech Technologies Inc'
    description 'Enhancing Project Management with Visual Task Tracking for Improved Planning and Prioritization.'
    version '4.2.0'
    url 'https://www.redmineflux.com/knowledge-base/plugins/agile-board/'
    author_url 'https://www.redmineflux.com'
  
    settings default: { 'story_points' => [] }, partial: 'setting/agile_story_points'
  
    project_module :agile_board do 
         permission :agile, { agile: [:index ] }, public: true
         permission :manage_sprints, public: true
         permission :view_agile_board, public: true
         permission :view_story_point, public: true
         permission :agile_versions, { agile_versions: [:index ] }, public: true
  
    menu :application_menu, :agile, { controller: 'agile', action: 'index'}, before: :activity, caption: Proc.new { I18n.t(:label_agile_board) }, param: :project_id
  
    Redmine::MenuManager.map :project_menu do |menu|
      menu.push :agile, { :controller => 'agile', :action => 'index' }, before: :activity, caption: Proc.new { I18n.t(:label_agile_board) }, :param => :project_id
      menu.push :agile_versions, { :controller => 'agile_versions', :action => 'index' }, before: :activity,caption: Proc.new { I18n.t(:label_backlog_board) }, :param => :project_id
    end
    end 
  
  end
  # Rails.configuration.to_prepare do
    Project.send(:has_many , :sprint_crafts)
    Issue.send(:belongs_to , :sprint_crafts )
    User.send(:has_many , :agile_wips) 
  
  # end