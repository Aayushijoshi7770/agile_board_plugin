class AddTimeField < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    add_column :custom_agile_boards, :time_ids, :text 
  end
    
  def self.down
  end
end
