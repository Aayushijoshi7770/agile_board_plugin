class AddStoryPointColumn < ActiveRecord::Migration[5.2]
  def self.up 
    add_column :issues, :story_points, :integer  
   end

   def self.down 
    remove_column :issues, :story_points
   end 
end
