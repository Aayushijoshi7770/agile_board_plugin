class AddSprintCraftFieldValueToCardfieldTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    add_column :card_fields, :sprint_field_value, :boolean, default: false
    # Set the 'selected' column to true for the first 6 versions
  end

  def down
    remove_column :card_fields, :sprint_field_value
  end
end
