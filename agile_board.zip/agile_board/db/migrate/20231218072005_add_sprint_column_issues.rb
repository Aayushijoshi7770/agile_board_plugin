class AddSprintColumnIssues < ActiveRecord::Migration[5.2]
  def self.up 
    add_column :issues, :sprint_craft, :integer  
   end

   def self.down 
    remove_column :issues, :sprint_craft
   end 
end
