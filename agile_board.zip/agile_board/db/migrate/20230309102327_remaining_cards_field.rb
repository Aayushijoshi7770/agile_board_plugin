class RemainingCardsField < ActiveRecord::Migration[5.2]
  def self.up
    @fields = ["Project","Created","Updated","Estimated Time"]
    @fields.each do |f|
      status_created = CardFields.create!(:field_name => f, :field_value => false)
    end
  end

  def self.down
  end 
end
