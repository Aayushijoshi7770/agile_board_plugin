class AddAdditionalCardFieldsAgile < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    @fields = ["Spent Time","Author",  "Category", "Target Version", "Description", "Sub Tasks", "Parent Task"]
    @fields.each do |f|
      status_created = CardFields.create!(:field_name => f, :field_value => false)
    end
  end

  def self.down
  end 
end
