class AddColumnForAgile < ActiveRecord::Migration[5.2]
  def change
    add_default_boolean_column :issue_statuses, :my_page_status
    add_default_boolean_column :issue_statuses, :agile_project_status
    add_default_boolean_column :card_fields, :project_field_value
    add_default_boolean_column :card_fields, :my_page_field
    add_default_boolean_column :total_times, :project_time_value
  end

  private

  def add_default_boolean_column(table_name, column_name)
    add_column table_name, column_name, :boolean, default: false
  end
end
