class ModifyCardFieldsAddNotesField < ActiveRecord::Migration[5.2]
  def change
    # Add the entry during migration
    CardFields.create!(:field_name => "Notes", :field_value => false)
  end


end
