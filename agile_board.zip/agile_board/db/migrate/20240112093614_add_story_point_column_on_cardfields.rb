class AddStoryPointColumnOnCardfields < ActiveRecord::Migration[5.2]
  def change
    CardFields.create!(:field_name => "Story Points", :field_value => false)
  end
end
