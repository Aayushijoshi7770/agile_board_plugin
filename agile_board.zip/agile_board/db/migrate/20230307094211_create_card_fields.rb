class CreateCardFields < ActiveRecord::Migration[5.2]
  def change
    create_table :card_fields do |t|
      t.string :field_name
      t.boolean :field_value
      t.timestamp :created_at
      t.timestamp :updated_at
    end
  end
end
