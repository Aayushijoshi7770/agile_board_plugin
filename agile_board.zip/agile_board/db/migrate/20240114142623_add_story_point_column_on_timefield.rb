class AddStoryPointColumnOnTimefield < ActiveRecord::Migration[5.2]
  def change
    TotalTimes.create!(:time_field => "Story Points", :time_value => false)
  end
end
