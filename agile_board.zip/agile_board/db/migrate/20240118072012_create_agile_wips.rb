class CreateAgileWips < ActiveRecord::Migration[5.2]
  def change
    create_table :agile_wips do |t|
      t.integer :user_id
      t.text :global_wip_limit
      t.text :project_wip_limit
      t.text :mypage_wip_limit
      t.timestamps
    end

    add_foreign_key :agile_wips, :users, column: :user_id
  end
end
