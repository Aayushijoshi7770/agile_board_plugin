class AddColumnIssue < ActiveRecord::Migration[5.2]
  def self.up
    add_column :issue_statuses, :agile_boards, :boolean , default: false
  end
    
  def self.down
  end
end
