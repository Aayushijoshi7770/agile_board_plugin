class DefaultTimes < ActiveRecord::Migration[5.2]
  def self.up
    @times = ["Estimated Time","Spent Time"]
    @times.each do |t|
      times_created = TotalTimes.create!(:time_field => t)
    end
  end

  def self.down
  end 
end
