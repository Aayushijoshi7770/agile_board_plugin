class AddImageInCardField  < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    CardFields.create!(:field_name => "Thumbnails", :field_value => false )
  end
end
 