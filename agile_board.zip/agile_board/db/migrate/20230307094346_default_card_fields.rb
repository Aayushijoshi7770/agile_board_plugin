class DefaultCardFields < ActiveRecord::Migration[5.2]
  def self.up
    @fields = ["Issue ID","Tracker", "Subject", "Assignee", "Due Date", "Priority", "% Done"]
    @fields.each do |f|
      status_created = CardFields.create!(:field_name => f, :field_value => true)
    end
  end

  def self.down
  end 
end
