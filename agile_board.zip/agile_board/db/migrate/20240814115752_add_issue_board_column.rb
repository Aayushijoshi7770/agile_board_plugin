class AddIssueBoardColumn < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    add_column :issue_statuses, :global_issue_agile, :boolean, default: true
    add_column :issue_statuses, :project_issue_agile, :boolean, default: true
    add_column :card_fields, :global_issue_value, :boolean, default: true
    add_column :card_fields, :project_issue_value, :boolean, default: true
    add_column :total_times, :global_issue_time, :boolean, default: true
    add_column :total_times, :project_issue_time, :boolean, default: true
  end
end
