class AddAllCardFieldsTrueByDefault < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change

    CardFields.reset_column_information
    CardFields.update_all(field_value:true, project_field_value:true, my_page_field:true, version_field_value:true, sprint_field_value:true)

    change_column_default :card_fields, :field_value, from: false, to: true
    change_column_default :card_fields, :project_field_value, from: false, to: true
    change_column_default :card_fields, :my_page_field, from: false, to: true
    change_column_default :card_fields, :version_field_value, from: false, to: true
    change_column_default :card_fields, :sprint_field_value, from: false, to: true
  end
end
