class CreateAgileQueriesRoles < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :agile_queries_roles do |t|
      t.integer :custom_agile_board_id, null: false
      t.integer :role_id, null: false
    end

    add_index :agile_queries_roles, [:custom_agile_board_id, :role_id], unique: true, name: :index_agile_queries_roles_on_board_id_and_role_id
  end
end
