class AddSelectedTrueByDefault < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    # Update the first 6 records to have selected set to true if not already true
    Version.reset_column_information

      first_six_versions = Version.order(:id).limit(6)
      first_six_status= IssueStatus.order(:id).limit(6)
      first_six_sprint =SprintCraft.order(:id).limit(6)
     needs_update = first_six_versions.any? { |version| !version.selected }

    if needs_update
      first_six_versions.update_all(selected: true)
      first_six_status.update_all(agile_boards:true, my_page_status:true, agile_project_status:true)
      first_six_sprint.update_all(selected:true)
    end

    change_column_default :versions, :selected, from: false, to: true
    change_column_default :issue_statuses, :agile_boards, from: false, to: true
    change_column_default :issue_statuses, :my_page_status, from: false, to: true
    change_column_default :issue_statuses, :agile_project_status, from: false, to: true
    change_column_default :sprint_crafts, :selected, from: false, to: true
    
  end

  def down
    # Optionally, you can define the reverse of this migration if needed
    Version.order(:id).limit(6).update_all(selected: false)
  end
end
