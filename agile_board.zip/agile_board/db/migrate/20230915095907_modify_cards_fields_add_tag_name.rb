class ModifyCardsFieldsAddTagName < ActiveRecord::Migration[5.2]
  def self.up
    # Delete all records from the CardFields table
     CardFields.delete_all
 
     @fields = ["Issue ID","Tracker", "Subject", "Assignee", "Priority"]
     @fields.each do |f|
       status_created = CardFields.create!(:field_name => f, :field_value => true)
     end
 
     @fields = ["Project","Start Date", "Due Date", "% Done","Estimation","Tags"]
     @fields.each do |f|
       status_created = CardFields.create!(:field_name => f, :field_value => false)
     end
   end
 
   def self.down
   end 
end
