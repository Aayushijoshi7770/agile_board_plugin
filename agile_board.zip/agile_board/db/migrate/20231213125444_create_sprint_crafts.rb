class CreateSprintCrafts < ActiveRecord::Migration[5.2]
  def change
    create_table :sprint_crafts do |t|
      t.references :project
      t.string :name, null: false
      t.text :description
      t.integer :status, null: false, default: 0
      t.date :start_date, null: false
      t.date :end_date, null: false
      t.timestamps null: false
      t.integer :sharing, null: false, default: 0 , index: true
    end
  end
end
