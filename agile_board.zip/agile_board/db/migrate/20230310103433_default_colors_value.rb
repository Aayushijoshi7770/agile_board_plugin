class DefaultColorsValue < ActiveRecord::Migration[5.2]
  def self.up
    @colors = ["Tracker","priority","No Color"]
    @colors.each do |c|
      color_created = ColorsOptions.create!(:color_name => c , :color_value => false)
    end
  end

  def self.down
  end 
end