class CreateCustomAgileBoards < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :custom_agile_boards do |t|
      t.column "project_id", :integer
      t.column "name", :string, :default => "", :null => false
      t.column "filters", :text
      t.column "user_id", :integer, :default => 0, :null => false
      t.column "is_public", :boolean, :default => false, :null => false
      t.column "visibility", :integer, :default => 0, :null => false
      t.column "board_ids" , :text 
      t.column "card_ids" , :text
    end
  end
end
