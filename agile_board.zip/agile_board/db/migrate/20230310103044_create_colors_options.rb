class CreateColorsOptions < ActiveRecord::Migration[5.2]
  def change
    create_table :colors_options do |t|
      t.string :color_name, default: 'tracker'
      t.boolean :color_value
      t.timestamp :created_at
      t.timestamp :updated_at
    end
  end
end
