class CreateTotalTimes < ActiveRecord::Migration[5.2]
  def change
    create_table :total_times do |t|
      t.string :time_field
      t.boolean :time_value, default: false
    end
  end
end
