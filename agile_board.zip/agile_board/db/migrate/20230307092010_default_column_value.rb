class DefaultColumnValue < ActiveRecord::Migration[5.2]
  def self.up
    @statuses = IssueStatus.all
      @statuses.each_with_index do |status, i|
        if i < 4
         status_created = BoardColumns.create!(:status_id => status.id, :status_name => status.name,  :status_value => true)
        else
         status_created = BoardColumns.create!(:status_id => status.id, :status_name => status.name,  :status_value => false)
      end
    end
 end

  def self.down
  end 
end
