class CreateBoardColumns < ActiveRecord::Migration[5.2]
  def change
    create_table :board_columns do |t|
      t.integer :status_id ,null: false
      t.string :status_name , null: false
      t.boolean :status_value
      t.timestamp :created_at
      t.timestamp :updated_at
    end
  end
end
