class AddColumnToVersionTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    add_column :versions, :selected, :boolean, default: false
  end

  def down
    remove_column :versions, :selected
  end
  
end
