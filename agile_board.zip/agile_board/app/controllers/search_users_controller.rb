class SearchUsersController < ApplicationController

  accept_api_auth :index


  # def index
  #   if User.present?
  #     if params[:name].present?
  #       @parameter =   params[:name].downcase
  #       @users = User.logged.where("lower(firstname) LIKE ? OR lower(lastname) LIKE ?", "%#{@parameter}%","%#{@parameter}%")
  #       render :json => @users
  #       respond_to do |format|
  #         format.html
  #         format.api do
  #           @users
  #         end
  #       end        
  #     end
  #   end
  #  rescue ActiveRecord::RecordNotFound
  #   render 404
  # end
  def index
    issue_id = params[:issue_id]
    
    if issue_id.present? && params[:name].present?
      @parameter = params[:name].downcase
      @issue = Issue.find(issue_id)
      @project =  Project.find(@issue.project_id)
      @watchers = Watcher.where(watchable_type: "Issue", watchable_id: issue_id).pluck(:user_id)
      @members =  @project.principals.where.not(id: @watchers).pluck(:id)
      
      @users = User.active.where("(lower(firstname) LIKE :parameter OR lower(lastname) LIKE :parameter) ", parameter: "%#{@parameter}%").where(id:  @members)
    
      respond_to do |format|
        format.api {render json:  @users, status: :ok}
      end 

    else  
      render json: { error: "Issue ID or name parameter can not be blank"}
    end 
 
    rescue ActiveRecord::RecordNotFound
    render 404
  end
end



