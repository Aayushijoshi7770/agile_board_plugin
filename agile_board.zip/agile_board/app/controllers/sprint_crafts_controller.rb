class SprintCraftsController < ApplicationController
    before_action :set_sprint_craft, only: [:edit, :update, :show, :destroy]
    before_action :set_project, only: [:index, :new, :create, :edit, :update, :show, :destroy]


    def index
        @sprint = SprintCraft.all
    end
    
    
    def new
         @sprint = SprintCraft.new
    end
    
    def create
         @sprint = SprintCraft.new(sprint_params)
        respond_to do |format|
         if @sprint.save
            flash[:notice] = "Sprint created successfully"
            if params[:sprint_craft][:from_setting_page].present?
                format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
                format.json { render :show, status: :created, location: @sprint }
            else
                format.html { redirect_to agile_versions_sprints_path(project_id: @project) }
                format.json { render :show, status: :created, location: @sprint }
            end
         else
            format.html { render :new, notice: 'Sprint was not created.' }
            format.json { render json: @sprint.errors, status: :unprocessable_entity }

         end
      end
    end
    
    def edit
    end
    
    def show
    end
    
    def update
        respond_to do |format|
            if @sprint.update(sprint_params)
                flash[:notice] = "Sprint updated successfully"
                format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
                format.json { render :show, status: :ok, location: @sprint }
            else
                format.html { render :edit, notice: 'Sprint was not updated.' }
                format.json { render json: @sprint.errors, status: :unprocessable_entity }
            end
        end
    end
    

    def destroy
        respond_to do |format|
          if Issue.exists?(sprint_craft: @sprint)
            flash[:error] = "Unable to delete sprint. There are issues associated with this sprint."
            format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
            format.json { render json: { error: "Unable to delete sprint. There are issues associated with this sprint." }, status: :unprocessable_entity }
          elsif @sprint.destroy
            flash[:notice] = "Sprint deleted successfully"
            format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
            format.json { head :no_content }
          else
            flash[:error] = "Sprint was not deleted"
            format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
            format.json { head :no_content }
          end
        end   
      end
      
      
    
    # def destroy
    #     respond_to do |format|
    #        if @sprint.destroy
    #            Issue.where(sprint_craft: @sprint).update_all(sprint_craft: nil)
    #             flash[:notice] = "Sprint deleted successfully"
    #             format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
    #             format.json { head :no_content }
    #        else
    #             flash[:notice] = "Sprint was not deleted"
    #             format.html { redirect_back_or_default settings_project_path(@project, :tab => 'sprints') }
    #             format.json { head :no_content }
    #        end
    #     end   
    # end
    
    private
    
    def sprint_params
        params.require(:sprint_craft).permit(:name, :description, :status, :start_date, :end_date , :sharing , :project_id)
    end
    
    def set_sprint_craft
        @sprint = SprintCraft.find(params[:id])
    end
    
    def set_project
        @project = Project.find(params[:project_id])
    end    

    
    end
    