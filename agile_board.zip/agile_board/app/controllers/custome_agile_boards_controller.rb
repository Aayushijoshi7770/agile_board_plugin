class CustomeAgileBoardsController < ApplicationController
  include QueriesHelper
  helper :queries
  before_action :require_login
  before_action :set_project, except: [:update_setting, :custom_agileBoard_delete]
  accept_api_auth :update_setting, :custom_agileBoard_delete

  def update_setting
    @board_columns = params[:boardboxids] || []
    @card_columns = params[:cardboxids] || []
    @time_colums=params[:timeboxids] || []
    @custom_agile_board= CustomAgileBoard.find(params[:id])
    if @board_columns.empty? || @card_columns.empty?
      errors = {}
      if @board_columns.empty? && @card_columns.empty?
        errors[:board_columns] = "Please select at least one Board column and one Card field"
      elsif @board_columns.empty?
        errors[:board_columns] = "Please select at least one Board column"
      elsif @card_columns.empty?
        errors[:card_columns] = "Please select at least one Card field"
      end
      render json: { errors: errors }, status: :unprocessable_entity
      return
    end
    if @custom_agile_board.present?
      @custom_agile_board.update_columns(board_columns: @board_columns, card_columns: @card_columns, time_field_columns: @time_colums)
      render json: @custom_agile_board 
    else
      render json: { error: 'Custom Agile Board not found' }, status: :not_found
    end
  end

  def index
  end

  def create
    @issue_statuses = IssueStatus.all
    @card_fields = CardFields.all
    @time_fields = TotalTimes.all
    @custom_agile_board = CustomAgileBoard.new(custom_agile_board_params)
    @query = query_class.new
    update_query_from_params
  
    if @query.valid?
      @custom_agile_board.filters = @query.attributes.slice('filters')
      @custom_agile_board.user_id = User.current.id
      @custom_agile_board.project_id = params[:query_is_for_all].present? ? nil : @project.id
      if @custom_agile_board.save
        if params.dig(:query, :visibility) == '1'
          role_ids = params.dig(:query, :role_ids).reject(&:blank?)
          save_roles_for_board(@custom_agile_board.id, role_ids)
        end
        redirect_to custom_agile_board_path(@project, @custom_agile_board), notice: 'Custom Agile Board was successfully created.' and return
      else
        render :new, notice: 'Custom Agile Board was not created.' and return
      end
    else
      render :new, notice: 'Custom Agile Board was not created due to query save failure.' and return
    end
  end
  
  

  def new
    @custom_agile_board = CustomAgileBoard.new
    @query = query_class.new
    @query.user = User.current
    @query.project = @project
    @query.build_from_params(params)
    @custom_agile_board.user_id = User.current.id
    @issue_statuses = IssueStatus.all
    @card_fields = CardFields.all
    @time_fields = TotalTimes.all
  end



  def edit
    @custom_agile_board = CustomAgileBoard.find(params[:id])
    @query = query_class.new
    @query.user = User.current
    @query.project = @project
    @query.filters =  @custom_agile_board.filters["filters"]
    @query.name=@custom_agile_board.name
    @query.visibility=@custom_agile_board.visibility
    @query.build_from_params(params)
    if(@custom_agile_board.visibility == 1)
      role_ids = AgileQueriesRole.where(custom_agile_board_id: @custom_agile_board.id).pluck(:role_id)
      @query.role_ids = role_ids
    end
    @has_project_id = @custom_agile_board.project_id.present?
    @issue_statuses = IssueStatus.all
    @card_fields = CardFields.all
    @time_fields = TotalTimes.all
  end
  def update
    @issue_statuses = IssueStatus.all
    @card_fields = CardFields.all
    @time_fields = TotalTimes.all
    @custom_agile_board = CustomAgileBoard.find(params[:id])
    @query = query_class.new
    update_query_from_params
  
    # Save the query and handle potential failure
    if @query.valid?
      @custom_agile_board.filters = @query.attributes.slice('filters')
      @custom_agile_board.project_id = params[:for_all_checkbox_value] == '1' ? nil : @project.id
      previous_visibility = @custom_agile_board.visibility
  
      if @custom_agile_board.update(custom_agile_board_params)
        if params.dig(:query, :visibility) == '1'
          role_ids = params.dig(:query, :role_ids).reject(&:blank?)
          if @custom_agile_board.present?
            role_id = AgileQueriesRole.where(custom_agile_board_id: @custom_agile_board.id).pluck(:role_id)
            role_id.each do |role|
              AgileQueriesRole.where(custom_agile_board_id: @custom_agile_board.id, role_id: role).find_each(&:destroy)
            end
          end
          save_roles_for_board(@custom_agile_board.id, role_ids)
        else
          if previous_visibility != 0 && previous_visibility != 2
            if @custom_agile_board.present?
              role_id = AgileQueriesRole.where(custom_agile_board_id: @custom_agile_board.id).pluck(:role_id)
              role_id.each do |role|
                AgileQueriesRole.where(custom_agile_board_id: @custom_agile_board.id, role_id: role).find_each(&:destroy)
              end
            end
          end
        end
        redirect_to custom_agile_board_path(@project, @custom_agile_board), notice: 'Custom Agile Board was successfully updated.' and return
      else
        render :edit, notice: 'Custom Agile Board was not updated.' and return
      end
    else
      render :edit, notice: 'Custom Agile Board was not updated due to query save failure.' and return
    end
  end
  



  def show
      @custom_agile_board = CustomAgileBoard.find(params[:id])
      @project = Project.find(params[:project_id])
      @query = query_class.new
      @query.user = User.current
      @query.project = @project
      @query.build_from_params(params)
      @query.filters =  @custom_agile_board.filters["filters"]
      @custom_agile_board_name = @custom_agile_board.name
      @custom_agile_board_boards = @custom_agile_board.board_ids
      @custom_agile_board_cards = @custom_agile_board.card_ids
      @custom_agile_board_times = @custom_agile_board.time_ids
      @comments = Setting.timelog_required_fields.include?('comments')
      @user_id = User.current.id
      @user = User.current
      @wip_limit = @user.agile_wips
      @add_issues= User.current.allowed_to?(:add_issues, @project, :global => true) && (@project.nil? || Issue.allowed_target_trackers(@project).any?) 
      filters =  @custom_agile_board.filters["filters"]
      filter_params = set_filter_params(filters)
      @redirect_url= issues_path(filter_params)
  end
  def custom_agileBoard_delete
    @custom_agile_board = CustomAgileBoard.find(params[:id])
    if @custom_agile_board.destroy
      flash[:notice] ='Custom Agile Board was successfully deleted.'
    else
      flash[:notice]='Custom Agile Board could not be deleted.'
    end
  end
  def destroy
    @custom_agile_board = CustomAgileBoard.find(params[:id])
    if @custom_agile_board.destroy
      redirect_to url_for(controller: 'agile', action: 'index', project_id: @project.id), notice: 'Custom Agile Board was successfully deleted.'
    else
      redirect_to url_for(controller: 'agile', action: 'index', project_id: @project.id), alert: 'Custom Agile Board could not be deleted.'
    end
  end  
  
  private

  def set_project
    @project = Project.find(params[:project_id])
  end

  def custom_agile_board_params
    permitted_params = params.require(:query).permit(:name, :visibility)
    custom_agile_board_params = params.fetch(:custom_agile_board, {}).permit(
      board_ids: [],
      card_ids: [],
      time_ids: []
    )
    custom_agile_board_params[:board_ids] ||= []
    custom_agile_board_params[:card_ids] ||= []
  
    permitted_params.merge(custom_agile_board_params)
  end
  
  

  def query_class
    Query.get_subclass(params[:type] || 'IssueQuery')
  end


  def save_roles_for_board(query_id, role_ids)
    puts "#{query_id.inspect}, #{role_ids.inspect} djjdj"
    role_ids.each do |role_id|
      AgileQueriesRole.find_or_create_by(custom_agile_board_id: query_id, role_id: role_id)
    end
  end
  def update_query_from_params
    @query.project = params[:query_is_for_all] ? nil : @project
    @query.build_from_params(params)
    @query.column_names = nil if params[:default_columns]
    @query.sort_criteria = (params[:query] && params[:query][:sort_criteria]) || @query.sort_criteria
    @query.name = params[:query] && params[:query][:name]
    if User.current.allowed_to?(:manage_public_queries, @query.project) || User.current.admin?
      @query.visibility = (params[:query] && params[:query][:visibility]) || Query::VISIBILITY_PRIVATE
      @query.role_ids = params[:query] && params[:query][:role_ids]
    else
      @query.visibility = Query::VISIBILITY_PRIVATE
    end
    @query
  end
  




  def set_filter_params(filters)
    filter_params = {
      set_filter: 1,
      f: [],
      op: {},
      v: {}
  }
    filters.each do |key, value|
      filter_params[:f] << key
      filter_params[:op][key] = value[:operator]
      filter_params[:v][key] = value[:values]
    end
  
    filter_params
  end
end

