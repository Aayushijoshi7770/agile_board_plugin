class AgileSettingsController < ApplicationController
    accept_api_auth :board_columns, :actived_users, :update_wip_limits , :board_column_settings, :update_agiles, :card_fields, :card_field_settings , :color_and_times, :color_settings , :color_optionss , :colors_all, :color_and_time_settings, :time_field , :time_field_settings , :index, :card_field_name, :agile_by_color_name, :agile_total_time, :agile_issue_status, :create_agile_board, :update_agile_board
    



    def board_columns
      @columns = BoardColumns.all
      respond_to do |format|
        format.api {render :json => @columns}
      end 
    end 


    def board_column_settings

      # @board_columns = [{ "status_id": 1,"status_value":"false"},{"status_id":2,"status_value":"false"},{"status_id": "5","status_value":"true"}]
      @board_columns = params[:board_columns]
      respond_to do |format|
          if @board_columns.present?
            @board_columns.each do |column|
              @column = BoardColumns.find_by(status_id: column[:status_id])
                if @column.present?
                  @column.update(status_id: column[:status_id], status_value: column[:status_value])
                else  
                  @column = BoardColumns.create(status_id: column[:status_id], status_value: column[:status_value])
                end 
                format.api{render :json => @board_columns }
            end

           else  
            format.api{render json: :unprocessable_entity}
          end 
      end 
    end 


    def card_fields
      @columns = CardFields.all.order(created_at: :asc)
      respond_to do |format|
        format.api {render :json => @columns}
      end 
    end 


# ============================

  def update_wip_limits
   
    @user_id = params[:user_id]

    if @user_id.present? 
      @agile_wip = AgileWip.find_or_initialize_by(user_id: @user_id)
      
      if params[:global_wip_limit].present?
        @agile_wip.update(global_wip_limit: params[:global_wip_limit])
      elsif params[:project_wip_limit].present?
        @agile_wip.update(project_wip_limit: params[:project_wip_limit])
      elsif params[:mypage_wip_limit].present?
        @agile_wip.update(mypage_wip_limit: params[:mypage_wip_limit])
      end

      respond_to do |format|
        format.api { render json: @agile_wip }
      end
    else
      respond_to do |format|
        format.api { render json: :unprocessable_entity }
      end
    end
  end
 
# ============================================

def card_field_settings

  @card_fields = params[:card_fields]
  @project_card_fields = params[:project_card_fields]
  @my_card_fields = params[:my_card_fields]
  @global_issue_agile_cards = params[:global_issue_agile_cards]
  @project_issue_agile_cards = params[:project_issue_agile_cards]

  respond_to do |format|
      if @card_fields.present?
        @card_fields.each do |column|
          @column = CardFields.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], field_value: column[:field_value])
            else  
              @column = CardFields.create(id: column[:id], field_value: column[:field_value])
            end 
            format.api{render :json => @card_fields }
        end

      elsif  @project_card_fields.present?
        @project_card_fields.each do |column|
          @column = CardFields.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], project_field_value: column[:project_field_value])
            else  
              @column = CardFields.create(id: column[:id], project_field_value: column[:project_field_value])
            end 
            format.api{render :json => @project_card_fields }
        end

      elsif  @global_issue_agile_cards.present?
        @global_issue_agile_cards.each do |column|
          @column = CardFields.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], global_issue_value: column[:global_issue_value])
            else  
              @column = CardFields.create(id: column[:id], global_issue_value: column[:global_issue_value])
            end 
            format.api{render :json => @global_issue_agile_cards }
        end

      elsif  @project_issue_agile_cards.present?
        @project_issue_agile_cards.each do |column|
          @column = CardFields.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], project_issue_value: column[:project_issue_value])
            else  
              @column = CardFields.create(id: column[:id], project_issue_value: column[:project_issue_value])
            end 
            format.api{render :json => @project_issue_agile_cards }
        end

      elsif  @my_card_fields.present?
        @my_card_fields.each do |column|
          @column = CardFields.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], my_page_field: column[:my_page_field])
            else  
              @column = CardFields.create(id: column[:id], my_page_field: column[:my_page_field])
            end 
            format.api{render :json => @my_card_fields }
        end

      else  
        format.api{render json: :unprocessable_entity}
      end 
  end 
end 

# =============================================


    def colors_all
      @columns = ColorsOptions.all
      respond_to do |format|
        format.api {render :json => @columns}
      end 
    end 


    def color_and_times
      @color_fields = ColorsOptions.all
      respond_to do |format|
          if @color_fields.present?
            @color_fields.each do |column|
              @column = ColorsOptions.where(color_value: true)
              format.api {render :json => @column}
            end
          end
        end
      end




def color_settings
  @colors_options = params[:colors_options]
  # Rails.logger.info = " #{@color_fields}, newww__debugg"
      respond_to do |format|
          if @colors_options.present?
            @colors_options.each do |column|
              @column = ColorsOptions.find_by(id: column[:id])
                if @column.present?
                  @column.update(id: column[:id], color_value: column[:color_value])
                else  
                  @column = ColorsOptions.create(id: column[:id], color_value: column[:color_value])
                end 
                format.api{render :json => @colors_options }
            end

          else  
            format.api{render json: :unprocessable_entity}
          end 
      end 
    end





# --------------times field -------------------

def time_field
  @columns = TotalTimes.all
  respond_to do |format|
    format.api {render :json => @columns}
  end 
end 



def time_field_settings
  @total_times = params[:total_times]
  @project_total_times = params[:project_total_times]
  @global_issue_total_times = params[:global_issue_total_times]
  @project_issue_total_times = params[:project_issue_total_times]

      respond_to do |format|
          if @total_times.present?
            @total_times.each do |column|
              @column = TotalTimes.find_by(id: column[:id])
                if @column.present?
                  @column.update(id: column[:id], time_value: column[:time_value])
                else  
                  @column = TotalTimes.create(id: column[:id], time_value: column[:time_value])
                end 
                format.api{render :json => @total_times }
            end
          elsif @project_total_times.present?
            @project_total_times.each do |column|
              @column = TotalTimes.find_by(id: column[:id])
              if @column.present?
                @column.update(id: column[:id], project_time_value: column[:project_time_value])
              else  
                @column = TotalTimes.create(id: column[:id], project_time_value: column[:project_time_value])
              end 
              format.api{render :json => @project_total_times }
          end

        elsif @global_issue_total_times.present?
          @global_issue_total_times.each do |column|
            @column = TotalTimes.find_by(id: column[:id])
            if @column.present?
              @column.update(id: column[:id], global_issue_time: column[:global_issue_time])
            else  
              @column = TotalTimes.create(id: column[:id], global_issue_time: column[:global_issue_time])
            end 
            format.api{render :json => @global_issue_total_times }
        end

      elsif @project_issue_total_times.present?
        @project_issue_total_times.each do |column|
          @column = TotalTimes.find_by(id: column[:id])
          if @column.present?
            @column.update(id: column[:id], project_issue_time: column[:project_issue_time])
          else  
            @column = TotalTimes.create(id: column[:id], project_issue_time: column[:project_issue_time])
          end 
          format.api{render :json => @project_issue_total_times }
      end


          else  
            format.api{render json: :unprocessable_entity}
          end 
      end 
    end 
# ====================================================

    

    #agile issue_statuses [Get API]
    def agile_issue_status
      @data = {}   
      # @issue = IssueStatus.select(:id,:name,:agile_boards)
      @issue = IssueStatus.select(:id,:name,:agile_boards,:my_page_status , :agile_project_status , :global_issue_agile , :project_issue_agile )
      @data[:Issue_statuses] =  @issue
        render :json => @data
        respond_to do |format|
          format.html 
          format.api do
           @data         
         end
       end        
    end



   def update_agiles
    @issue_statuses = params[:issue_statuses]
    @project_issue_statuses = params[:project_issue_statuses]
    @my_page_issue_statuses = params[:my_page_issue_statuses]
    @global_issue_agiles = params[:global_issue_agiles]
    @project_issue_agiles = params[:project_issue_agiles]

    respond_to do |format|
      if @issue_statuses.present?
        @issue_statuses.each do |column|
          @column = IssueStatus.find_by(id: column[:id])
          if @column.present?
            @column.update(agile_boards: column[:agile_boards])
          else  
            render json: { error: 'Issue status not found' }, status: :not_found
            return
          end 
        end
        format.api { render json: @issue_statuses, status: :ok }

       elsif @project_issue_statuses.present?
        @project_issue_statuses.each do |column|
          @column = IssueStatus.find_by(id: column[:id])
          if @column.present?
            @column.update(agile_project_status: column[:agile_project_status])
          else
            render json: { error: 'Issue status not found in particular project' }, status: :not_found
            return
          end 
        end
        format.api { render json: @project_issue_statuses, status: :ok }

      elsif @global_issue_agiles.present?
        @global_issue_agiles.each do |column|
          @column = IssueStatus.find_by(id: column[:id])
          if @column.present?
            @column.update(global_issue_agile: column[:global_issue_agile])
          else
            render json: { error: 'Issue status not found in particular project' }, status: :not_found
            return
          end 
        end
        format.api { render json: @global_issue_agiles, status: :ok }

      elsif @project_issue_agiles.present?
        @project_issue_agiles.each do |column|
          @column = IssueStatus.find_by(id: column[:id])
          if @column.present?
            @column.update(project_issue_agile: column[:project_issue_agile])
          else
            render json: { error: 'Issue status not found in particular project' }, status: :not_found
            return
          end 
        end
        format.api { render json: @project_issue_agiles, status: :ok }

      elsif @my_page_issue_statuses.present?
        @my_page_issue_statuses.each do |column|
          @column = IssueStatus.find_by(id: column[:id])
          if @column.present?
            @column.update(my_page_status: column[:my_page_status])
          else
            render json: { error: 'Issue status not found in particular project' }, status: :not_found
            return
          end 
        end
        format.api { render json: @my_page_issue_statuses, status: :ok }

      else  
        format.api { render json: { error: 'No issue statuses provided' }, status: :unprocessable_entity }
        Rails.logger.info  " #{@issue_statuses}, params of this api"
      end 
    end 
  end


  # =============
  

    def actived_users
      project = Project.find_by(id: params[:id])
      if project.nil?
        render json: { error: 'Project not found' }, status: :not_found
        return
      end
      
      # active_users = project.users.where(status: 1).map { |user| { id: user.id, name: user.name } }
      active = project.users.where(status: 1)
      sorted_active_users = active.map { |user| { id: user.id, name: user.name } }
      active_users = sorted_active_users.sort_by { |user| user[:name] }

      
      render json: { active_users: active_users }, status: :ok
    end
  


end
