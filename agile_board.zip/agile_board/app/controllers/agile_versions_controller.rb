class AgileVersionsController < ApplicationController
  before_action :require_login
  accept_api_auth :updateSetting 
  include QueriesHelper
  helper :queries

  def index
    setup_query_and_project
    respond_to do |format|        
      format.html do
        @trackers = @project.trackers.sorted.to_a
        retrieve_selected_tracker_ids(@trackers, @trackers.select {|t| t.is_in_roadmap?})
        @with_subprojects = params[:with_subprojects].nil? ? Setting.display_subprojects_issues? : (params[:with_subprojects] == '1')
        project_ids = @with_subprojects ? @project.self_and_descendants.pluck(:id) : [@project.id]
 
        @versions = @project.shared_versions.preload(:custom_values)
        @versions += @project.rolled_up_versions.visible.preload(:custom_values) if @with_subprojects
        @versions = @versions.to_a.uniq
        @versions = @versions.sort_by(&:created_on).reverse
        unless params[:completed]
          @completed_versions = @versions.select(&:completed?).reverse
          @versions -= @completed_versions
        end
 
        @issues_by_version = {}
        if @selected_tracker_ids.any? && @versions.any?
          issues = Issue.visible.
            includes(:project, :tracker).
            preload(:status, :priority, :fixed_version).
            where(:tracker_id => @selected_tracker_ids, :project_id => project_ids, :fixed_version_id => @versions.map(&:id)).
            order("#{Project.table_name}.lft, #{Tracker.table_name}.position, #{Issue.table_name}.id")
          @issues_by_version = issues.group_by(&:fixed_version)
        end
        @versions.reject! {|version| !project_ids.include?(version.project_id) && @issues_by_version[version].blank?}
      end
      format.api do
        @versions = @project.shared_versions.to_a
      end
    end
  end

  def sprints 
    setup_query_and_project
    # @sprints = SprintCraft.where(:project => @project, :status => 0).order(created_at: :desc) if @project

    if @project
      @sprints = @project.shared_sprints.order(created_at: :desc)
    end
  end

  def updateSetting
    versions = params[:versions]
    card_fields_sprint = params[:card_fields_sprint]
    card_fields_version = params[:card_fields_version]
    sprints = params[:sprints]
    unless   versions.present? ||  card_fields_version.present? || sprints.present? || card_fields_sprint.present?
      render json: { error: 'Please select version, card fields or sprints' }, status: :unprocessable_entity
      return
    end
    errors = []
    errors.concat(update_versions(versions)) if   versions.present?
    errors.concat(update_card_fields_version(card_fields_version)) if card_fields_version.present?
    errors.concat(update_card_fields_sprint(card_fields_sprint)) if card_fields_sprint.present?
    errors.concat(update_sprints(sprints)) if sprints.present?
  
    if errors.empty?
      render json: { message: 'Settings updated successfully' }, status: :ok
    else
      render json: { errors: errors }, status: :not_found
    end
  end
  
  private
  
  def update_versions(versions)
    errors = []
    versions.each do |version|
      version_record = Version.find_by(id: version[:id])
      if version_record.present?
        version_record.update(selected: version[:checked])
      else
        errors << "Version with id #{version[:id]} not found"
      end
    end
    errors
  end
  
  def update_card_fields_version(card_fields_version)
    errors = []
    card_fields_version.each do |cards|
      card_record = CardFields.find_by(id: cards[:id])
      if card_record.present?
          card_record.update(version_field_value: cards[:checked])
      else
        errors << "Card field  with id #{cards[:id]} not found"
      end
    end
    errors
  end

  def update_card_fields_sprint(card_fields_sprint)
    errors = []
    card_fields_sprint.each do |cards|
      card_record = CardFields.find_by(id: cards[:id])
      if card_record.present?
          card_record.update(sprint_field_value: cards[:checked])
      else
        errors << "Card field  with id #{cards[:id]} not found"
      end
    end
    errors
  end

  def update_sprints(sprints)
    errors = []
    sprints.each do |sprint|
      sprint_record = SprintCraft.find_by(id: sprint[:id])
      if sprint_record.present?
        sprint_record.update(selected: sprint[:checked])
      else
        errors << "Sprint with id #{sprint[:id]} not found"
      end
    end
    errors
  end

  private

  def setup_query_and_project
     @comments = Setting.timelog_required_fields.include?('comments')
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
      @card_fields=CardFields.all.order(created_at: :asc)
      @add_issues= User.current.allowed_to?(:add_issues, @project, :global => true) && (@project.nil? || Issue.allowed_target_trackers(@project).any?) 

      # for filter
      @query = query_class.new
      @query.user = User.current
      @query.project = @project
      @query.build_from_params(params)
    end
  end
  end
  
  def query_class
    Query.get_subclass(params[:type] || 'IssueQuery')
  end

  def retrieve_selected_tracker_ids(selectable_trackers, default_trackers=nil)
    if ids = params[:tracker_ids]
      @selected_tracker_ids =
        if ids.is_a? Array
          ids.collect {|id| id.to_i.to_s}
        else
          ids.split('/').collect {|id| id.to_i.to_s}
        end
    else
      @selected_tracker_ids =
        (default_trackers || selectable_trackers).collect {|t| t.id.to_s}
    end
  end
