class AgileController < ApplicationController
  before_action :require_login
  accept_api_auth :create, :get_tags, :notes_count, :user_permissions
  include QueriesHelper
  helper :queries


  def index 
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
      @query = query_class.new
      @query.user = User.current
      @query.project = @project
      @query.build_from_params(params)
    else
      @query = query_class.new
      @query.user = User.current
      @query.project = @project if @project
      @query.build_from_params(params)
    end
    @comments = Setting.timelog_required_fields.include?('comments')
    @user_id = User.current.id
    @custom_agile_board = CustomAgileBoard.all
    @user = User.current
    @wip_limit = @user.agile_wips

   @add_issues= User.current.allowed_to?(:add_issues, @project, :global => true) && (@project.nil? || Issue.allowed_target_trackers(@project).any?) 

   
  end 
  
  def query_class
      Query.get_subclass(params[:type] || 'IssueQuery')
  end

  def create
    # @issue=Issue.find(47)

     @issue_id = params[:issue_id]
     @issue=Issue.find_by_id(@issue_id)
     @allowed_statuses = @issue.new_statuses_allowed_to(User.current)
     @allowed_ids =  @allowed_statuses.map { |item| item[:id] }
        render :json => @allowed_ids
   end

  def all_custom_fields 
      respond_to do |format|
          format.html do
            @custom_fields_by_type = CustomField.all.group_by {|f| f.class.name}
            @custom_fields_projects_count =
              IssueCustomField.where(is_for_all: false).joins(:projects).group(:custom_field_id).count
          end
          format.api do
            @custom_fields = CustomField.all
          end
      end
  end 

  def get_tags
       @issues_scope = Issue.visible.select(params[:id]).joins(:project)
       if  Redmine::Plugin.registered_plugins[:flux_tags]
        @result_scope = ActsAsTaggableOn::Tag.joins(:taggings)
          .select('tags.id, taggings.taggable_id,tags.name, tags.taggings_count, COUNT(taggings.id) as count')
          .group('tags.id, tags.name, tags.taggings_count,  taggings.taggable_id ').order('tags.name')

            # Group the tags by taggable_id
         tags_by_taggable_id = @result_scope.group_by { |tag| tag.taggable_id }

       # Use the Rails session to store and retrieve background colors
        #  session[:background_colors] ||= {}

        # Create a new array of unique objects
        unique_objects = tags_by_taggable_id.values.map do |tag_group|
          taggable_id = tag_group.first.id
          # Use the stored color if it exists, otherwise generate a new one
          # background_color = session[:background_colors][taggable_id] || generate_random_light_color

           # Store the background color in the session
          # session[:background_colors][taggable_id] = background_color
          {
            id: tag_group.first.id,
            taggable_id:tag_group.first.taggable_id,
            name: tag_group.first.name,
            taggings_count: tag_group.first.taggings_count,
            count: tag_group.first.count,
            tag_list: tag_group.map { |tag| { :id => tag.id, :name =>tag.name,  background_color: FluxTags.settings[:issues_use_colors].to_i > 0 ? tag_color(tag) : " " } }
          }
        end
        render json: unique_objects
        else 
        render json: []
        end
        end

        def tag_color(tag)
          tag_name = tag.respond_to?(:name) ? tag.name : tag
          digest = Digest::MD5.hexdigest(tag_name)[2..7]
          char_mapping = {
            '0' => 'b', '1' => 'c', '2' => 'd',
            '3' => 'e', '4' => 'b', '5' => 'c',
            '6' => 'd', '7' => 'e', '8' => 'b',
            '9' => 'c', 'a' => 'd', 'b' => 'e',
            'c' => 'b', 'd' => 'c', 'e' => 'd',
            'f' => 'e'
          }
      
          light_color = digest.chars.map { |char| char_mapping[char] }.join
        
          "##{light_color}"
        end

         # get notes count from journal table 
         def notes_count
          issue_ids = params[:issue_ids]
          if issue_ids.present? 
          @notes_count = Journal.where(journalized_type: 'Issue', journalized_id: issue_ids).where.not(notes: [nil,''])
          render json:   @notes_count
           else
          render json: { error: 'Issues ids not available' }, status: :unprocessable_entity
          end

        end
     

         def user_permissions
          @project = Project.find(params[:project_id])
          user_id = User.current.id
          user = User.find(user_id)
          roles = user.roles_for_project(@project)
          render json: roles 
         end

end