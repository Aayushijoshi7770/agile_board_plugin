class AgileboardController < IssuesController
  accept_api_auth :index
  def index
    @issue_id = params[:issue_id]
    @issue = Issue.find(@issue_id)
    @allowed_statuses = @issue.new_statuses_allowed_to(User.current)
    render :json => @allowed_statuses
  end
end
