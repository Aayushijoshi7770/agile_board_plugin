module SprintCraftsHelper
end
