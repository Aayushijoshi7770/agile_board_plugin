module AgileHelper
  def filtered_agile_boards(user, project_id)
    custom_agile_boards = CustomAgileBoard.where(project_id: [project_id.id, nil])
    return custom_agile_boards if user.admin?
    custom_agile_boards.select do |query|
      case query.visibility
      when 0
        query.user_id == user.id
      when 1
        roles = AgileQueriesRole.where(custom_agile_board_id: query.id).pluck(:role_id)
        user.roles.where(id: roles).exists?
      when 2
        true
      else
        false
      end
    end
  end  
end
