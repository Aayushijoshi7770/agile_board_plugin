class SprintCraft < ActiveRecord::Base
    belongs_to :project
    has_many :issues

    validates :name, presence: true
    validates_uniqueness_of :name,  :case_sensitive => true
    validates :start_date, presence: true
    validates :end_date, presence: true
    validates :sharing, presence: true
    validates :status, presence: true
    validate :date_validation
    validate :active_sprint_craft_exists, if: :active?
    validates :name, presence: true, uniqueness: { scope: :project_id }
    
    enum status: { open: 0, active: 1, closed: 2 }
    enum sharing: {
      not_shared: 0,
      with_subprojects: 1,
      with_project_hierarchy: 2,
      with_project_tree: 3,
      with_all_projects: 4
    }
  
    def self.status_options
      statuses.keys.map { |status| [status.capitalize, status] }
    end
  
    def self.sharing_options
      sharings.keys.map { |sharing| [sharing.humanize, sharing] }
    end

    private

    def date_validation
        if end_date.present? && start_date.present? && end_date < start_date
            errors.add(:end_date, "must be greater than start date")
        end
    end

    def active_sprint_craft_exists
        if project && project.sprint_crafts.active.exists?
            project.sprint_crafts.active.update_all(status: :open)
        end
    end

end
