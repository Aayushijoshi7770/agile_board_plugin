class BoardColumns < ActiveRecord::Base
end
