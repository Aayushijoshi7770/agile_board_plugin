class TotalTimes < ActiveRecord::Base
end
