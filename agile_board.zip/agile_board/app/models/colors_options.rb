class ColorsOptions < ActiveRecord::Base
end
