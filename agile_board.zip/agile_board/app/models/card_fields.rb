class CardFields < ActiveRecord::Base
end
