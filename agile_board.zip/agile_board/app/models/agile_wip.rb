class AgileWip < ActiveRecord::Base
    belongs_to :user
end
