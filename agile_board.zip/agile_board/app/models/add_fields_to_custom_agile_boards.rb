class AddFieldsToCustomAgileBoards < ActiveRecord::Base
end
