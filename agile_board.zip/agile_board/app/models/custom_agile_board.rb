class CustomAgileBoard < ActiveRecord::Base
  validates :name, presence: true
  validate :at_least_one_board_id_selected
  validate :at_least_one_card_id_selected
  serialize :filters, Hash
  before_validation :filter_blank_ids

  def update_columns(board_columns:, card_columns:, time_field_columns:)
    self.board_ids = board_columns.reject(&:blank?).to_json
    self.card_ids = card_columns.reject(&:blank?).to_json
    self.time_ids = time_field_columns.reject(&:blank?).to_json
    save
  end

  private

  def filter_blank_ids
    if board_ids.present?
      self.board_ids = JSON.parse(board_ids).reject(&:blank?).to_json
    end

    if card_ids.present?
      self.card_ids = JSON.parse(card_ids).reject(&:blank?).to_json
    end

    if time_ids.present?
      self.time_ids = JSON.parse(time_ids).reject(&:blank?).to_json
    end
  end

  def at_least_one_board_id_selected
    puts "at_least_one_board_id_selected"
    if board_ids.nil? || JSON.parse(board_ids).empty?
      errors.add(:base, "Please select at least one Board column")
    end
  end

  def at_least_one_card_id_selected
    puts "at_least_one_card_id_selected"
    if card_ids.nil? || JSON.parse(card_ids).empty?
      errors.add(:base, "Please select at least one Card field")
    end
  end
end
