class AgileColoredBy < ActiveRecord::Base
end
