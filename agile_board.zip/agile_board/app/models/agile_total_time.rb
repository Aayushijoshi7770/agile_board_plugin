class AgileTotalTime < ActiveRecord::Base
end
