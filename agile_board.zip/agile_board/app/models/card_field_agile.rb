class CardFieldAgile < ActiveRecord::Base
end
