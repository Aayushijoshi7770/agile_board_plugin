class AgileQueriesRole < ActiveRecord::Base
  belongs_to :custom_agile_board
end
