

$(document).ready(function () {

 
    var url=window.location.origin
     
    var my_page_url = url + "/my/page";
    if (window.location.href !== my_page_url) {

    var card_array=[{name:"Issue ID", value:"id" }, {name:"Tracker", value:"tracker"}, {name:"Priority", value:"priority"},{name:"Assignee", value:"assigned_to"}, {name:"Subject",value:"subject"}, {name:"Start date", value:"start_date"},{name:"Due date", value:"due_date"}, {name:"Project", value:"project"}, {name:"Created", value:"created_on"}, {name:"Updated",value:"updated_on"},{name:"Estimated time",value:"estimated_hours"},{name:"% Done",  value:"done_ratio"}]
    var total_hour=" ";
    var card_field=["id","tracker","priority","assigned_to","start_date","due_date","subject"];
    var boards_array=[];
    var total_story_points = "" ;
    var total_spent_time=" ";
    var total_spent_time_project = "";
    var total_issues;
    var total_time=[{name:"Estimated Time",value:"estimated_time"},{name:"Spent Time",value:"spent_time"}];
   
    


    $.ajax({
      type: "GET",
      url:url+`/total_time.json?key=${api_key}`,
      dataType: "json",
      async:false,
      success: function (result, status, xhr) {
        Total_time=result;
    }
    })

 

    window.hideColumn = function (value) {
      // console.log(boardId.target.getAttribute("value"),"board IDD");
      let boardId=value.target.getAttribute("id");
      let mainEle=value.target.getAttribute("value");
     
      function toggleColumnExpansion(columnId) {
        const column = document.getElementById(columnId);
        if (column.classList.contains("expanded")) {
            localStorage.setItem(`issue-${columnId}`, "expanded");
        } else {
            localStorage.setItem(`issue-${columnId}`, "collapsed");
        }
    }
      const columns = document.querySelectorAll(".kanban-board");

      columns.forEach(column => {
          const columnId = column.id;
          column.addEventListener("click", function () {
              toggleColumnExpansion(columnId);
          });
      
          // Restore the state when the page loads
          // const initialState = localStorage.getItem(columnId);
          // console.log(columnId,"columns ID")
          // if (initialState === "collapsed") {
          //     toggleColumnExpansion(columnId);
          // }
     
      });

       const cards = document.querySelectorAll('.kanban-board');
     
      // Define a function to handle the click event
      function clickHandler() {
          // Increase the width of the clicked card by a certain amount (e.g., 50px)
            if(this.getAttribute("data-id")==boardId)
            {
              this.classList.toggle('expanded'); 
            } 
          
          // Toggle a class on elements with the class "header-back" when the card is expanded
          const headerBackElements = this.querySelectorAll('.header-back');
          headerBackElements.forEach(element => {
            if(this.getAttribute("data-id")==boardId)
            {
             element.classList.toggle('expanded-header-back');
           }  
          });
        // Toggle the visibility of the specified element when the card is expanded
     
        const kanbanContent=  document.querySelector(`#myKanban > div.kanban-container > div.kanban-board.board${boardId} > main `);
    
        if (kanbanContent) {
            if(this.getAttribute("data-id")===boardId)
            {
              kanbanContent.classList.toggle('hidden'); 
         
           }
        }
      // Remove the click event listener after it has been executed once
      this.removeEventListener('click', clickHandler);
      }
      // Add a click event listener to each card
         cards.forEach(card => {
           card.addEventListener('click', clickHandler);
        });
            // Get all the div elements with the class "kanban-board"
          var boardElements = document.querySelectorAll('div.kanban-board');
          // Check if all of them have the class "expanded"
      //     setTimeout(()=>{
      //       var allExpanded = Array.from(boardElements).every(function(element) {
      //         return element.classList.contains('expanded');
      //       });
      //       // If all elements have the class "expanded", add a minimum height to them
      //       if (allExpanded) {
      //         Array.from(boardElements).forEach(function(element) {
      //          element.style.minHeight = '79vh'; // Change this value to your desired minimum height
      //         });
      //       }
      //       else{
      //         Array.from(boardElements).forEach(function(element) {
      //           element.style.minHeight = '0px'; // Change this value to your desired minimum height
      //         });  
      //       }
      // })
  }
  

        window.toggleSet= function (el) {
 
                $("input[name='input-check']:checked").attr("checked","checked");
               $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                dataType: "json",
                success: function (result, status, xhr) {
              $(".table-div-board").html(" ");
                   let content=result.issue_statuses;
                   let board_data=JSON.parse(localStorage.getItem("boards"))
                   
                  content.forEach((object,i)=>{
                      if(i<4)
                      {
                        $(".table-div-board").append(`
                    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                   <div style="display:flex;">
                     <input checked  disabled name="input-board"  value=${object.id} class="board-checkbox" type="checkbox">
                   </div>
                  <div style="display:flex;">
                     <span  class="board-name">${object.name}</span>
                      </div>
                 </div>
                     `);
                      }
                      else if(board_data&&board_data.includes(object.id))
                      {
                        $(".table-div-board").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                        <div style="display:flex;">
                          <input checked  name="input-board"  value=${object.id} class="board-checkbox"   type="checkbox">
                        </div>
                       <div style="display:flex;">
                          <span  class="board-name">${object.name}</span>
                           </div>
                      </div>`);
                      }
                      else{
                           $(".table-div-board").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                           <div style="display:flex;">
                             <input  name="input-board"  value=${object.id} class="board-checkbox"   type="checkbox">
                           </div>
                          <div style="display:flex;">
                             <span  class="board-name">${object.name}</span>
                              </div>
                        </div>`);
                      }
                   })
               
                },
                  error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
               })
               var fieldset = $(el).parents('fieldset').first();
               fieldset.toggleClass('collapsed');
               fieldset.children('legend').toggleClass('icon-collapsed icon-setting');
               fieldset.children('div').toggle();
             }
             window.toggleBoard=function (el)
             {
              var fieldset = $(el).parents('fieldset').first();
              fieldset.toggleClass('collapsed');
             fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
             fieldset.children('div').toggle();
             }
                    window.toggleCards=function (el)
             {
               var fieldset = $(el).parents('fieldset').first();
               fieldset.toggleClass('collapsed');
               fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
               fieldset.children('div').toggle();
             }
             window.clearOptions=function(){
              // localStorage.clear();
              // location.reload();
              window.event.preventDefault();
              $(".context-menu-popup-main").css("display", "none");
               $(".setting-div").css("display", "none");

                  // console.log("tab index......")
                $("[tabindex='-1']").attr("tabindex", 0);
            
             }
             
      function removeAjaxIndicator() {
  
          $(document).bind('ajaxSend', function(event, xhr, settings) {
            if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
            $('#ajax-indicator').hide();   
            }
          });
          $(document).bind('ajaxStop', function() {
            $('#ajax-indicator').hide(); 
          });
        }
     
       
          
          function getSpentTime(project_Id){
          
              $.ajax({
              type: "GET",
              url: self.url+`/time_entries.json?key=${api_key}`,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              success: function (result, status, xhr) {
              result.time_entries.reduce(function(sum, current) {
  
               return total_spent_time= sum + current.hours;
                 
            }, 0);


// --------------particular projects spent time -------

            if(project_Id){
              $.ajax({
              type: "GET",
              url: self.url+`/time_entries.json?project_id=${project_Id}&key=${api_key}`,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              success: function (result, status, xhr) {
                // console.log(result,'this is particular projects spent time');
                // --------
                total_spent_time_project = result.time_entries.reduce(function(sum, current) {
                  return sum + current.hours;
                }, 0);

                // console.log(total_spent_time_project, 'current project spent time');
              },
              error: function(xhr, status, error) {
                // console.log("Error:", error);
              }

              
            });
            }

            
              
                  



                


                Total_time.forEach((object,i)=>{


              if(project_Id){
                if(object.id === 2 && object.project_issue_time === true && view_spent_time === true){
                    $("#query-id").css("display","flex");
                     $(".total-for-spent-hours").css("display","inline-block");
                     if (total_spent_time_project!= NaN){
                      total_spent_time_project=parseFloat(total_spent_time_project).toFixed(2);
                      $(".value-spent-time").html(total_spent_time_project);
                     } else {
                      $(".value-spent-time").html("0.00");
                     }
                }
              } 
              else {
              if (object.id === 2 && object.global_issue_time === true && view_spent_time === true) {
                $("#query-id").css("display","flex");
                $(".total-for-spent-hours").css("display","inline-block");
                if (total_spent_time!= NaN){
                 total_spent_time=parseFloat(total_spent_time).toFixed(2);
                  $(".value-spent-time").html(total_spent_time);
                } else {
                  $(".value-spent-time").html("0.00");
                }
              }

              }
            })


                    
            //       }
            //     })
            //   }
            // })
                  //})
              },
      
              error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
            })
          }
          
        function showSettings(){

           $(` <!--  <div  id="query_form_with_buttons" class="hide-when-print setting-agile outside">
             <div id="query_form_content">
               <fieldset  class="collapsible collapsed">
               <legend onclick="toggleSet(this)" class="icon icon-collapsed">Settings</legend>
                 <div class="table-div" style="display:none">
                    <table >
                    <tbody>
                    <tr>
                    <td colspan="2">
                    <fieldset   style="margin-bottom:13px;"   class="collapsible collapsed">
                      <legend  id="legend-setting" onclick="toggleBoard(this)" class="icon icon-boards">Board columns</legend>
                          <div class="table-div-board" style="display:flex; flex-wrap:wrap;">
                            
                          </div>
                    </fieldset>
                    </td>
                    </tr>
                         <tr>
                    <td colspan="2">
                    <fieldset  style="margin-bottom:13px;" class="collapsible collapsed">
                      <legend onclick="toggleCards(this)" class="icon icon-boards">Card fields</legend>
                          <div class="table-div-cardfields" style="display:flex; flex-wrap:wrap;" >
                          </div>
                    </fieldset>
                    </td>
                    </tr>
                        <tr>
                    <td colspan="2">
                    <div style="display:flex;  flex-direction:column; gap:6px; margin-bottom:13px;">
                       <div style="display:flex; flex-direction:row; margin-bottom:0.25rem; gap:20px;">
                       <div  style="display:flex; justify-content:center; align-items:center;">
                       <div   style="display:flex; ">
                          <label class="agile_options_label">
                           Colored by
                           </label>
                           </div>
                           </div>
                           <div style="display:flex;">
                             <select name="color_base" id="color_base">
                               <option value="none">No colors</option>
                               <option  value="tracker">Tracker</option>
                               <option value="priority">Priority</option>
                               <option  value="user">Assignee</option>
                         </select>  
                         </div> 
                         </div>
                     
                    </td>
                    </tr>
                   <tr>
                      <td colspan="2">
                    <div style="display:flex; flex-direction:row;  gap:22px;">
                      <div  style="display:flex;">
                      <label  class="agile_options_label">Totals</label>
                      </div>
                      <div   style="display:flex;" class="total_time">
                      </div>
                  </div>
                      </td>
                    </tr>
                    </tbody>
                    </table>
                    </div>
             </div>
            <p   style="margin-bottom:32px !important"; id="setting-button" class="buttons">
            <a  style="cursor:pointer"  onclick="updateOptions()"  class="icon icon-checked"">Apply</a>
            <a   style="cursor:pointer"  onclick="clearOptions()"  class="icon icon-reload" >Clear</a>
               
            </p>
          </div>
          --> `).insertAfter("#query_form");
            let time=JSON.parse(localStorage.getItem("total_time"));
            // console.log(time,"time");
           total_time.forEach((list,i)=>{
            if(time&&time.includes(list.value))
            {
             $(".total_time").append(`
             <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input checked name="time-check" value=${list.value} class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
            else{
             $(".total_time").append(`  <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input  name="time-check" value=${list.value} class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
            })
          let card_data=JSON.parse(localStorage.getItem("card_fields"))
          // console.log(card_data,"card data");
           card_array.forEach((list,i)=>{
            if((list.value==="id")||(list.value==="tracker")||(list.value==="priority")||(list.value==="assigned_to")||(list.value==="start_date")||(list.value==="due_date")||(list.value==="subject"))
            {
             $(".table-div-cardfields").append(` <label class="floating">
             <input name="input-check"  disabled checked value=${list.value}  class="board-checkbox"  type="checkbox" >
                 ${list.name}
            </label>`)
            }
            else if(card_data&&card_data.includes(list.value))
            {
              $(".table-div-cardfields").append(`
              <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
              <div style="display:flex;">
              <input name="input-check"   checked value=${list.value}  class="board-checkbox"  type="checkbox" >
              </div>
             <div style="display:flex;">
                <span  class="board-name"> ${list.name}</span>
                 </div>
             </div>
            `)
            }
            else{
             $(".table-div-cardfields").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input name="input-check"    value=${list.value}  class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
        })
        }
        var workflow_status;
        
      
        function getWorkflow(id){
           // var workflow_status;
               $.ajax({
              type: "GET",
              url: `${self.url}/tracker_workflow_status.json?key=${api_key}` ,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              data:  {
                issue_id:parseInt(id)
              },
              success: function (result, status, xhr) {
                 workflow_status= result;
              },
              error: function (xhr, status, error) {
                // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
            })
            
            return workflow_status;
        }
        window.getRedmineWorkflow=function(){
          var workflow;
          $.ajax({
         type: "GET",
         url: `${self.url}/workflow/transitions.json?role_id=3&tracker_id=6&key=${api_key}` ,
         dataType: "json",
         async:false,
         contentType: 'application/json',
     
         success: function (result, status, xhr) {
          // console.log(result.transitions,"result of workflow transitions ")
           workflow= result.transitions;
         },
         error: function (xhr, status, error) {
           // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
          }
       })
       //console.log(workflow,"worflow Satus ");
       return workflow;
 
 
 
 
      }
// ------------------------------------------------------------my code ------------------------------------

$(document).ready(function () {


  const params = window.location.search;
  // const parameters = new URLSearchParams(params);
  // const project_id = parameters.get("project_id");
  // console.log(project_id,"pro==id");

      // Get the full URL path
    let url = window.location.origin ;
    const urls = window.location.pathname;
    const match = urls.match(/projects\/([^\/]+)\//);
    const projectId = match ? match[1] : null;
    // console.log(projectId, "pro==id");
    // console.log(url,"url=-=>>");
    

  
  $.ajax({
    type: "GET",
    url:url+`/agile_issue_statuses.json?key=${api_key}`,
    dataType: "json",
    async:false,
    success: function (result, status, xhr) {

      var boards_result = result.Issue_statuses ;
      // console.log(boards_result,"boardss--result ");
      if(projectId){

        boards_result.forEach((object,i)=>{
          if (object.project_issue_agile === true ){
            boardss.push(object.id);
        
          }
        })

      } else {
      boards_result.forEach((object,i)=>{
        if (object.global_issue_agile === true ){
          boardss.push(object.id);
      
        }
      })
    }
  

    }})

    // console.log(boardss,"boardss==>>");
  
    

});




// -------------------------------------------------------------------------------------------------------------------
        $(document).ready(function () {

          if(!localStorage.getItem("total_time"))
             {
                localStorage.setItem("total_time",JSON.stringify(total_time))
             }
            //  if(!localStorage.getItem("selected_color"))
            //  {
            //     localStorage.setItem("selected_color","tracker")
            //  }
            //  if(!localStorage.getItem("card_fields"))
            //  {
            //     localStorage.setItem("card_fields",JSON.stringify(card_field))
            //  }
 
         
        //  $("#options").css("display","none"); 
          //  showSettings();
             removeAjaxIndicator();
                const params =window.location.search
                // const parameters = new URLSearchParams(params);
                // let  params =window.location.pathname
                let  parameters = new URLSearchParams(params);
               
                
        
          
                if(window.location.href===`${url}/issues`)
                
                {
                 
              //  console.log('if cases');    

               $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,                
                dataType: "json",
                sync: false,
                success: function (result, status, xhr) {
           
                const params =window.location.search
              
                //   let  parameters = new URLSearchParams(params);
                // const  project_id = parameters.get('project_id');
                let  get_project =window.location.pathname
                let  parameters = new URLSearchParams(params);
                let params_split = get_project.split('/');
               var project_id = params_split[2] ;
   
                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&&include=trackers`:url+`/issues.json?key=${api_key}`,
                dataType: "json",
                beforeSend: function(){
                let body_div=document.getElementsByClassName("has-main-menu controller-issues action-index");
                let div=document.createElement("div");
                div.className="unknown-div";
                div.style.display="block";
                body_div[0].appendChild(div);
                 $('.circle-loader').show();
               },
                success: function (res, status, xhr) {
                  total_issues= res.total_count;
                  agile_issues_issue_page=res.issues;
                  //console.log(total_issues,"toal issues");
                if(res.issues.length==0)
                {
                  console.log("condition--11--issue");
                  $(".nodata").css("display","none");
                  $("#myKanban").css("display","block");
                      // $("#myKanban").css("display","none");
                      // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                }
                else{
                    
                       $(".nodata").css("display","none");
                       $("#myKanban").css("display","block");
                }
                 getSpentTime(project_id);
                  $('.circle-loader').toggleClass('load-complete');
                 $('.checkmark').toggle();
                  setTimeout(() => { 
                  $(".unknown-div").css("display","none");
                  $('.circle-loader').hide();
                  }, 300);
            
                  result.issue_statuses.forEach(object => {
                    
                            object.item= []
                            
                  });
                  // console.log(res.issues,"issues");
               
                // console.log(getWorkflow(),"getworloadflow")
                  res.issues.forEach(object => {
                     result.issue_statuses.forEach(option=>{
                    
                       if(object.status.name==option.name)
                        {
                         option.item.push(object)
                          }
                        });
                     });           
                 
                   const  array_item=[];
                    result.issue_statuses.forEach(object => {
                   
                            array_item.push(''+object.id)    
                  });
                        // console.log(array_item,"array item nnnn ");
                    // ----

                    // console.log(boards_array,"bords array");
                    // console.log(result.issue_statuses,"result issues sattue s")
                   result.issue_statuses.forEach((object,i)=> {
                    
                    //  if(i<6)
                    //     {
                    //        boards_array.push(object)
                          
                    //      }


                         if(boardss){
                          boardss.forEach((list)=>{
                           if(list==object.id)
                           {
                             boards_array.push(object)
           
                             
                           }
                          })
                        }

                            object.id=''+object.id
                            object.dragTo=array_item
                            object.issueCount=object.item.length
                            object.total_issue_count=total_issues
                           
                        });
                      
                   
                  
   
            
                  let local_data= boardss
                  
         
                       result.issue_statuses.forEach((object,i)=> {
                            if(local_data.includes(object.id))
                            {
                               boards_array.push(object)
                            }
                            
                       })
                //}

                // ----
                   if(res.issues.length!=0)
                  {
                  res.issues.reduce(function(sum, current) {
                    //  console.log(current.estimated_hours,"current esitmeatd hour");
                     return total_hour= sum + current.estimated_hours;
                      }, 0); 
                    }
                    else{
                      total_hour=0.00;
                    }

                    if(res.issues.length!=0)
                    {
                    res.issues.reduce(function(sum, current) {
                        // console.log(current.story_points,"current story points ");
                      return total_story_points = sum + current.story_points;
                      
                        }, 0); 
                       
                        // console.log(total_story_points,"total story points");
                      }
                      else{
                        total_story_points=0.00;
                      }


                      Total_time.forEach((object,i)=>{

                      if(project_id){

                        if (object.time_field === "Story Points" && object.project_issue_time === true && view_story_point === true){
                          //  console.log(total_story_points,"total story points");
                              $("#query-id").css("display","flex");
                                $(".total-for-story-point").css("display","inline-block");
                              
                                      total_story_points=parseFloat(total_story_points).toFixed(2);
                                      $(".value-story-points").html(total_story_points);
                                    
                                }

                      } else {

                        if (object.time_field === "Story Points" && object.global_issue_time === true && view_story_point === true){
                    //  console.log(total_story_points,"total story points");
                        $("#query-id").css("display","flex");
                          $(".total-for-story-point").css("display","inline-block");
                        
                                total_story_points=parseFloat(total_story_points).toFixed(2);
                                $(".value-story-points").html(total_story_points);
                              
                          }
                        }
                          
                          
                          });

                        Total_time.forEach((object,i)=>{
                              
                          if (project_id){
                            if (object.id === 1 && object.project_issue_time === true && view_estimated_time === true )
                              {
                                if(total_hour!=NaN)
                                {
                                $("#query-id").css("display","flex");
                                $(".total-for-estimated-hours").css("display","inline-block");
                                 total_hour=parseFloat(total_hour).toFixed(2);
                                $(".value-estimated-time").html(total_hour);
                                }
                                else{
                                   $(".value-estimated-time").html("0.00");
                                }
                              }
                              if (object.id === 2 && object.project_issue_time === true && view_spent_time === true)
                              {
                                $("#query-id").css("display","flex");
                                $(".total-for-spent-hours").css("display","inline-block");
                                  if(total_spent_time!= NaN){ 
                                     total_spent_time=parseFloat(total_spent_time).toFixed(2);
                                     $(".value-spent-time").html(total_spent_time);
                                    // console.log("this is  outside project");
                                  } else {
                                     $(".value-spent-time").html("0.00");
                                  }
                              }
                              if (object.timefield === "Story Points" && object.project_issue_time === true && view_story_point === true) {
                                $("#query-id").css("display", "flex");
                                $(".total-for-story-point").css("display", "inline-block");
                                total_story_points = parseFloat(total_story_points).toFixed(2);
                                $(".value-story-points").html(total_story_points);
                          }
                          } 
                          else {

                      
                          if (object.id === 1 && object.global_issue_time === true && view_estimated_time === true )
                          {
                            if(total_hour!=NaN)
                            {
                            $("#query-id").css("display","flex");
                            $(".total-for-estimated-hours").css("display","inline-block");
                             total_hour=parseFloat(total_hour).toFixed(2);
                            $(".value-estimated-time").html(total_hour);
                            }
                            else{
                               $(".value-estimated-time").html("0.00");
                            }
                          }
                          if (object.id === 2 && object.global_issue_time === true && view_spent_time === true)
                          {
                            $("#query-id").css("display","flex");
                            $(".total-for-spent-hours").css("display","inline-block");
                                 if(total_spent_time!= NaN){
                                 total_spent_time=parseFloat(total_spent_time).toFixed(2);
                                 $(".value-spent-time").html(total_spent_time);
                                 } else {
                                  $(".value-spent-time").html("0.00");
                                 }
                                // console.log("this is  outside project");
                          }
                          if (object.timefield === "Story Points" && object.global_issue_time === true && view_story_point === true) {
                            $("#query-id").css("display", "flex");
                            $(".total-for-story-point").css("display", "inline-block");
                            total_story_points = parseFloat(total_story_points).toFixed(2);
                            $(".value-story-points").html(total_story_points);
                      }
                    }
                          })
            // --------

            // ----           
                        


                
                 var KanbanTest = new jKanban({
                  element: "#myKanban",
                  color:"red",
                  // gutter: "10px",
                  // widthBoard: "420px",
                  
                  itemHandleOptions:{
                    enabled: true,
                  },
                 context: function(el, e) {
                 },
                 dropEl: function(el, target, source, target_id,source_id){
      
                  getWorkflow(el.dataset.eid);

                  var target_int = parseInt(target_id);
                
                  toastr.options = {
                    closeButton: true,
                    debug: false,
                    newestOnTop: false,
                    progressBar: true,
                    positionClass: "toast-top-right",
                    preventDuplicates: false,
                    onclick: null,
                    showDuration: "300",
                    hideDuration: "1000",
                    timeOut: "2000",
                    extendedTimeOut: "1000",
                    showEasing: "swing",
                    hideEasing: "linear",
                    showMethod: "fadeIn",
                    hideMethod: "fadeOut",
                  };
                  
                


                  if (workflow_status.includes(target_int)) {
                 
                  } 
                  else if (workflow_status.length === 0) {
                    // console.log("No the issue[#"+ el.dataset.eid +"] status is never be changed ");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);

                    
                  }
                   else {
                    // console.log(workflow_status,"NO the issue[#" + el.dataset.eid +"] status not be change please drop another container");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);

                  }


 
                  var content =
                 {
                     "status_id": parseInt(target_id)
                  }
                 $.ajax({
                type: "PUT",
                url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
                dataType: "json",
                contentType: 'application/json',
                data: JSON.stringify({
                "issue": content
               }),
                success: function (res,status, xhr) {      
                $.ajax({
                 type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                 dataType: "json",
                success: function (Newresult, status, xhr) {
                const params =window.location.search
                // const parameters = new URLSearchParams(params);
                // const  project_id = parameters.get('project_id');
                let  get_project =window.location.pathname
                let  parameters = new URLSearchParams(params);
                let params_split = get_project.split('/');
               var project_id = params_split[2] ;
                // console.log(params,'params');
                // console.log(parameters,'parameters');
                // console.log(project_id,'project ids');

                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}`:url+`/issues.json?key=${api_key}`,
                dataType: "json",
                success: function (Newres, status, xhr) {
                  agile_issues_issue_page=Newres.issues;
                  if(Newres.issues.length==0)
                {
                  $(".nodata").css("display","none");
                  $("#myKanban").css("display","block");
                      // $("#myKanban").css("display","none");
                      // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                }
                else{
                    
                      agile_issues=Newres.issues;
                       $(".nodata").css("display","none");
                       $("#myKanban").css("display","block");
                }
                 Newresult.issue_statuses.forEach(object => {
                            object.item= []
                  });
                Newres.issues.forEach(object => {
                    Newresult.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                          option.item.push(object)
                         }
                        });
                     });           
                  const  array_item=[];
                   Newresult.issue_statuses.forEach(object => {
                            array_item.push(''+object.id)    
                  });
                  Newresult.issue_statuses.forEach(object => {
                            object.id=''+object.id
                            object.dragTo=array_item
                          object.issueCount=object.item.length

                   });
                 
                   Newresult.issue_statuses.forEach(object => {
                         result.issue_statuses.forEach(option => {
                          option.issueCount=object.item.length
                            
                  });
                   })
// ------------
                 
issue_bords_ids = KanbanTest.options.boards ;  //boards id
issue_counting = KanbanTest.boardContainer ;    //issue updated values

var issue_update_value = [];
var issue_bords_update = [];


// console.log(issue_bords_update,'isssue boards update');

issue_bords_ids.forEach((object,i)=>{
issue_bords_update.push(object.id);
});



issue_counting.forEach((object,i)=>{
issue_update_value.push(object.childElementCount);
// console.log(object.childElementCount,'child countingg')
});



// -------------
for (let i = 0; i < issue_bords_update.length; i++) {
$('.counting' + issue_bords_update[i]).html('('+ issue_update_value[i] + ')');
}

                }
               });
              
              },
               error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
              },
               error: function (xhr, status, error) {
               alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
                });
                  },
                  
                  itemAddOptions: {
                    enabled: project_id?true:false,
                    content: '+ Add New ISSUE',
                    class: 'Add-card',
                    footer:true
                  },
                  boards:boards_array,
                  //boards:boardss,
                   cardCounter:result.issue_statuses.length
                 

                });
                   }, 
                 error: function (xhr, status, error) {
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                 alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                }
                });
              },
               error: function (xhr, status, error) {
              setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
                }
                else{
                  // console.log("in particulrproject id")
                  window.getProjects=function(id)
                  {
                    var trackers;
                    $.ajax({
                      type: "GET",
                      url:`${url}/projects/${id}.json?key=${api_key}&&include=trackers`,
                      dataType: "json",
                      async:false,
                      success: function (result, status, xhr) {
                        // console.log(result,"result");
                        trackers=result.project.trackers;
                      },
                      error:function(error,status,xhr){

                      }
                    })
                    return  trackers;
                  }
                 let params = window.location.search
                 let  get_project = window.location.pathname
                 let  parameters = new URLSearchParams(params);
                 let params_split = get_project.split('/');
                //  console.log(params_split[2],'pro new');
                //  var  project_id = parameters.get('project_id');
                var project_id = params_split[2] ;
                //  console.log(params,'params');
                //  console.log(parameters,'parameters');
                //  console.log(project_id,'project ids');
                 if(project_id)
                 {
                  var trackers= getProjects(project_id);
                 }
              // console.log(project_id,'pro pro pro');
                //  console.log(trackers,"trackers");
                $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                dataType: "json",
                success: function (result, status, xhr) {
                const params =window.location.search
                //  let  parameters = new URLSearchParams(params);
                // const  project_id = parameters.get('project_id');
                let  get_project =window.location.pathname
                let  parameters = new URLSearchParams(params);
                let params_split = get_project.split('/');          
               var project_id = params_split[2] ;
  

                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}` :url+`/issues.json?key=${api_key}&${params}` ,
                dataType: "json",
                beforeSend: function(){
                let body_div=document.getElementsByClassName("has-main-menu controller-issues action-index");
                let div=document.createElement("div");
                div.className="unknown-div";
                div.style.display="block";
                body_div[0].appendChild(div);
                 $('.circle-loader').show();
               },
                success: function (res, status, xhr) {
                  // console.log(res,"res");
     
                  if(res.issues.length==0)
                {
                  $(".nodata").css("display","none");
                  $("#myKanban").css("display","block");
                      // $("#myKanban").css("display","none");
                      // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                }
                else{
                    
                        agile_issues_issue_page=res.issues;
                       $(".nodata").css("display","none");
                       $("#myKanban").css("display","block");
                }
                 getSpentTime(project_id);
                $('.circle-loader').toggleClass('load-complete');
                $('.checkmark').toggle();
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                //  if(res.issues.length==0&&!project_id)
                //  {
                //        $("#myKanban").css("display","none");
                //        $(".setting-agile").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                //  }
                //  else{
                //         $(".nodata").css("display","none");
                //         $("#myKanban").css("display","block");
                //  }
                  result.issue_statuses.forEach(object => {
                            object.item= []
                            
                  });
                  res.issues.forEach(object => {
                     result.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                         option.item.push(object)
                          }
                        });
                     });    
                     
                  if(res.issues.length!=0)
                  {
                     res.issues.reduce(function(sum, current) {
                      return total_hour= sum + current.estimated_hours;
                      }, 0); 
                  }
                  else{
                    total_hour=0.00;
                  }

                  if(res.issues.length!=0)
                  {
                  res.issues.reduce(function(sum, current) {
                      // console.log(current.story_points,"current story points project");
                    return total_story_points = sum + current.story_points;
                    
                      }, 0); 
                    }
                    else{
                      total_story_points=0.00;
                    }

                    Total_time.forEach((object,i)=>{
                           
                      if(project_id){
                        if (object.id === 1 && object.project_issue_time === true && view_estimated_time === true)
                          {
                            if(total_hour!=NaN)
                            {
                            $("#query-id").css("display","flex");
                            $(".total-for-estimated-hours").css("display","inline-block");
                             total_hour=parseFloat(total_hour).toFixed(2);
                            $(".value-estimated-time").html(total_hour);
                            }
                            else{
                               $(".value-estimated-time").html("0.00");
                            }
                          }
                      }else{
                        if (object.id === 1 && object.global_issue_time === true && view_estimated_time === true)
                        {
                          if(total_hour!=NaN)
                          {
                          $("#query-id").css("display","flex");
                          $(".total-for-estimated-hours").css("display","inline-block");
                           total_hour=parseFloat(total_hour).toFixed(2);
                          $(".value-estimated-time").html(total_hour);
                          }
                           else{
                            $(".value-estimated-time").html("0.00");
                          }
                        }
                    }
                     
                      })

                      Total_time.forEach((object,i)=>{
                        if(project_id){
                          if (object.time_field === "Story Points" && object.project_issue_time === true && view_story_point === true){
                            //  console.log(total_story_points,"total story points");
                             $("#query-id").css("display","flex");
                             $(".total-for-story-point").css("display","inline-block");
                           
                                   total_story_points=parseFloat(total_story_points).toFixed(2);
                                   $(".value-story-points").html(total_story_points);
                                 
                             }
                        }else{
                        if (object.time_field === "Story Points" && object.global_issue_time === true && view_story_point === true){
                         //  console.log(total_story_points,"total story points");
                          $("#query-id").css("display","flex");
                          $(".total-for-story-point").css("display","inline-block");
                        
                                total_story_points=parseFloat(total_story_points).toFixed(2);
                                $(".value-story-points").html(total_story_points);
                              
                          }
                        }
                          
                          });

                  
                

                   const  array_item=[];
                   result.issue_statuses.forEach(object => {
                            array_item.push(''+object.id)    
                  });
                  result.issue_statuses.forEach(object => {
                            object.id=''+object.id
                            object.dragTo=array_item
                            object.issueCount=object.item.length
                   });
                   result.issue_statuses.forEach((object,i)=> {
                    //  if(i<6)
                    //     {
                    //      boards_array.push(object)
      
                    //      }
  
                       if(boardss){
                          boardss.forEach((list)=>{
                           if(list==object.id)
                           {
                             boards_array.push(object)
                             
                           }
                          })
                        }

                            object.id=''+object.id
                            object.dragTo=array_item
                            object.issueCount=object.item.length
                            object.tracker_data=trackers
                   });
                    

                  let local_data= boardss
                 
                       result.issue_statuses.forEach((object,i)=> {
                            if(local_data.includes(object.id))
                            {
                               boards_array.push(object)
                            }
                       })
             
                
                // --------------------
                 var KanbanTest = new jKanban({
                  element: "#myKanban",
                  // gutter: "8px",
                  // widthBoard: "420px",
                  itemHandleOptions:{
                    enabled: true,
                  },
                 context: function(el, e) {
                 },
                 dropEl: function(el, target, source, sibling ,source_id){
                  getWorkflow(el.dataset.eid);
 

                  var target_int = parseInt(sibling);
                  var source_int = parseInt(source_id);




                  if (workflow_status.includes(target_int)) {
                    // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully");
                    // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");                
                  }
                   else if (workflow_status.length === 0) {
                    // console.log("no the issue[#"+ el.dataset.eid +"] can't be changed ");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);
 
                    
                  } else {
                    // console.log("no the issue[#" + el.dataset.eid +"] cant drop this status");
                    toastr["error"]('workflow is not defined for this status');
                   KanbanTest.drake.cancel(true);
  
                  }

              



                 var content =
                 {
                     "status_id": parseInt(sibling)
                  }
                 $.ajax({
                type: "PUT",
                url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
                dataType: "json",
                contentType: 'application/json',
                data: JSON.stringify({
                "issue": content
               }),
                success: function (res,status, xhr) {      
                $.ajax({
                 type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                 dataType: "json",
                success: function (Newresult, status, xhr) {
                const params =window.location.search
                // const parameters = new URLSearchParams(params);
                // const  project_id = parameters.get('project_id');
                let  get_params =window.location.pathname
                let  parameters = new URLSearchParams(params);
                let params_split = get_params.split('/');
               var project_id = params_split[2] ;
        

                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}`:url+`/issues.json?key=${api_key}&${params}`,
                dataType: "json",
                success: function (Newres, status, xhr) {
              
                if(Newres.issues.length==0)
                {
                  $(".nodata").css("display","none");
                  $("#myKanban").css("display","block");
                      // $("#myKanban").css("display","none");
                      // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                }
                else{
                  agile_issues_issue_page=Newres.issues;
                       $(".nodata").css("display","none");
                       $("#myKanban").css("display","block");
                }
                 Newresult.issue_statuses.forEach(object => {
                            object.item= []
                  });
                Newres.issues.forEach(object => {
                    Newresult.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                          option.item.push(object)
                         }
                        });
                     });           
                  const  array_item=[];
                   Newresult.issue_statuses.forEach(object => {
                            array_item.push(''+object.id)    
                  });
                  Newresult.issue_statuses.forEach(object => {
                            object.id=''+object.id
                            object.dragTo=array_item
                          object.issueCount=object.item.length

                   });
                 
                   Newresult.issue_statuses.forEach(object => {
                         result.issue_statuses.forEach(option => {
                          option.issueCount=object.item.length
                        
                            
                  });
                   })
// ----------------------------------------------

                     issue_bords_ids = KanbanTest.options.boards ;  //boards id
                    issue_counting = KanbanTest.boardContainer ;    //issue updated values

                   var issue_update_value = [];
                   var issue_bords_update = [];

                  
                  // console.log(issue_bords_update,'isssue boards update');

                  issue_bords_ids.forEach((object,i)=>{
                    issue_bords_update.push(object.id);
                  });



                  issue_counting.forEach((object,i)=>{
                    issue_update_value.push(object.childElementCount);
                  // console.log(object.childElementCount,'child countingg')
                }); 

         
              
// -------------
                for (let i = 0; i < issue_bords_update.length; i++) {
                  $('.counting' + issue_bords_update[i]).html('('+ issue_update_value[i] + ')');
                }

                  
                  //    Newresult.issue_statuses.forEach((data,i)=>{
                  //   $(".counting"+data.id).each(function(index,value){
                  //     //  --------add there---
                  //     $(this).html(`(${data.issueCount})`)
                      
                  //    });
                  //  })
                }
               });
              },
               error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
              },
               error: function (xhr, status, error) {
              //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
                });
                  },
                  itemAddOptions: {
                    enabled: (project_id&&trackers.length!=0)?true:false,
                    content: '+ Add New ISSUE',
                    class: 'Add-card',
                    footer: true
                  },
                  boards:boards_array,
                  //boards:boardss,
                  cardCounter:result.issue_statuses.length
                 
                });
                   }, 
                 error: function (xhr, status, error) {
                $(".show-error").css("display","none");
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
              if(xhr.status==422)
              {
               let content=JSON.parse(xhr.responseText).errors;
                $("#myKanban").before(`<div class="show-error" id='errorExplanation'><ul class="ul-time"></ul> </div>`);
                content.forEach(p=>{
                  $(".ul-time").append(`<li>${p}</li>`);
                })
              }
              else{
                // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
                }
                });
              },
               error: function (xhr, status, error) {
              setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
               }
  });

}
  
})