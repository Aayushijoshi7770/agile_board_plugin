


(function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw ((a.code = "MODULE_NOT_FOUND"), a);
          }
          var p = (n[i] = { exports: {} });
          e[i][0].call(
            p.exports,
            function (r) {
              var n = e[i][1][r];
              return o(n || r);
            },
            p,
            p.exports,
            r,
            e,
            n,
            t
          );
        }
        return n[i].exports;
      }
      for (
        var u = "function" == typeof require && require, i = 0;
        i < t.length;
        i++
      )
        o(t[i]);
      return o;
    }
    return r;
  })()(
    {
      1: [
        function (require, module, exports) {
          /**
      /* =========================================================
       * Created by Aayushi Joshi
       * 
       * Tiny little kanban board in vanilla JS
       * Might not work effectively on older browsers
       * Uses HTML5 Drag API
       *
       * =========================================================
       * 
       */
          //Require dragula
          var dragula = require("dragula");
  
          (function () {
            this.jKanban = function () {
              var self = this;
              var __DEFAULT_ITEM_HANDLE_OPTIONS = {
                enabled: false,
              };
              var __DEFAULT_ITEM_ADD_OPTIONS = {
                enabled: false,
              };
              this._disallowedItemProperties = [
                "id",
                "title",
                "click",
                "context",
                "drag",
                "dragend",
                "drop",
                "order",
              ];
  
              this.currentPage = 1;
              this.limit = 25;
              this.total = 0;
              this.url = window.location.origin;
              this.element = "";
              this.container = "";
              this.boardContainer = [];
              this.handlers = [];
              this.dragula = dragula;
              this.drake = "";
              this.drakeBoard = "";
              this.data = {};
              this.itemAddOptions = __DEFAULT_ITEM_ADD_OPTIONS;
              this.itemHandleOptions = __DEFAULT_ITEM_HANDLE_OPTIONS;
              var defaults = {
                element: "",
                data: {},
                color: "red",
                gutter: "2.5px",
                widthBoard: "300px",
                responsive: "700",
                responsivePercentage: false,
                boards: [],
                dragBoards: false,
                dragItems: true, //whether can drag cards or not, useful when set permissions on it.
                itemAddOptions: __DEFAULT_ITEM_ADD_OPTIONS,
                itemHandleOptions: __DEFAULT_ITEM_HANDLE_OPTIONS,
                dragEl: function (el, source) { },
                dragendEl: function (el) { },
                dropEl: function (el, target, source, sibling) { },
                dragBoard: function (el, source) { },
                dragendBoard: function (el) { },
                dropBoard: function (el, target, source, sibling) { },
                click: function (el) { 
                },
                context: function (el, e) { },
                buttonClick: function (el, boardId) { },
                propagationHandlers: [],
              };
              if (arguments[0] && typeof arguments[0] === "object") {
                this.options = __extendDefaults(defaults, arguments[0]);
              }
  
              this.__getCanMove = function (handle) {
                if (!self.options.itemHandleOptions.enabled) {
                  return !!self.options.dragItems;
                }
                if (self.options.itemHandleOptions.handleClass) {
                  return handle.classList.contains(
                    self.options.itemHandleOptions.handleClass
                  );
                }
           
                return handle.classList.contains("kanban-item-color");
              };
  
              this.init = function () {
         
                //set initial boards
                __setBoard();
                //set drag with dragula
                if (window.innerWidth > self.options.responsive) {
               
                  //Init Drag Board
                  self.drakeBoard = self
                    .dragula([self.container], {
                      moves: function (el, source, handle, sibling) {
                        if (!self.options.dragBoards) return false;
                        return (
                          handle.classList.contains("kanban-board-header") ||
                          handle.classList.contains("kanban-title-board")
                        );
                      },
                      accepts: function (el, target, source, sibling) {
                          // console.log("vertical")
                        return target.classList.contains("kanban-container");
                      },
                      revertOnSpill: true,
                      direction: "horizontal",
                    })
                    .on("drag", function (el, source) {
                      // console.log("draggging")
                      el.classList.add("is-moving");
                      self.options.dragBoard(el, source);
                      if (typeof el.dragfn === "function") el.dragfn(el, source);
                    })
                    .on("dragend", function (el) {
                      __updateBoardsOrder();
                      el.classList.remove("is-moving");
                      self.options.dragendBoard(el);
                      if (typeof el.dragendfn === "function") el.dragendfn(el);
                    })
                    .on("drop", function (el, target, source, sibling) {
                      el.classList.remove("is-moving");
                      self.options.dropBoard(el, target, source, sibling);
                      if (typeof el.dropfn === "function")
                        el.dropfn(el, target, source, sibling);
                    });
  
                  //Init Drag Item
             
                  self.drake =  self
                    .dragula(self.boardContainer, {
                      moves: function (el, source, handle, sibling) {
            
                        return self.__getCanMove(el);
                      },
                      revertOnSpill: true,
                    })
                    .on("cancel", function (el, container, source) {
                      self.enableAllBoards();
                    })
                    .on("drag", function (el, source) {
           
                      var elClass = el.getAttribute("class");
                      if (
                        elClass !== "" &&
                        elClass.indexOf("not-draggable") > -1
                      ) {
                        self.drake.cancel(true);
                        return;
                      }
                      el.classList.add("is-moving");
                      self.options.dragEl(el, source);
                      var boardJSON = __findBoardJSON(
                        source.parentNode.dataset.id
                      );
                      if (boardJSON.dragTo !== undefined) {
                        self.options.boards.map(function (board) {
                          if (
  
                            boardJSON.dragTo.indexOf(board.id) === -1 &&
                            board.id !== source.parentNode.dataset.id
                          ) {
  
                            // console.log(board,"board");
                            self
                              .findBoard(board.id)
                              .classList.add("disabled-board");
                          }
                        });
                      }
                      if (el != null && typeof el.dragfn === "function")
                        el.dragfn(el, source);
                    })
                    .on("dragend", function (el) {
                      self.options.dragendEl(el);
                      if (el !== null && typeof el.dragendfn === "function")
                        el.dragendfn(el);
                    })
                    .on("drop", function (el, target, source, sibling) {
                      self.enableAllBoards();
                      // console.log(el.dataset.tracker,"e");
                      var board_id = target.parentNode.dataset.id;
  
                      var source_id = source.parentNode.dataset.id;
                      var boardJSON = __findBoardJSON(
                        source.parentNode.dataset.id
                      );
                      if (boardJSON.dragTo !== undefined) {
                        if (
                          boardJSON.dragTo.indexOf(
                            target.parentNode.dataset.id
                          ) == -1 &&
                          target.parentNode.dataset.id !==
                          source.parentNode.dataset.id
                        ) {
                          self.drake.cancel(true);
                        }
                      }
                      if (el !== null) {
                        var result = self.options.dropEl(
                          el,
                          target,
                          source,
                          board_id,
                          source_id
                        );
                        if (result === false) {
                          self.drake.cancel(true);
                        }
                        el.classList.remove("is-moving");
                        if (typeof el.dropfn == "function")
                          el.dropfn(el, target, source, sibling);
                      }
                    });
                }
              };
  
              this.enableAllBoards = function () {
                var allB = document.querySelectorAll(".kanban-board");
                if (allB.length > 0 && allB != undefined) {
                  for (var i = 0; i < allB.length; i++) {
                    allB[i].classList.remove("disabled-board");
                  }
                }
              };
  
              //Draggable kanban-card Autoscroll----------------------
     
              interact(".kanban-item-color").draggable({
                // keep the element within the area of it's parent
                restrict: {
                  restriction: "parent",
                  endOnly: true,
                  elementRect: { top: 0, left: 0, bottom: 1, right: 1 },
                },
                // enable autoScroll
                autoScroll: { container: 
                  self.options.element == "#version-board" ? document.getElementById("version-board") :
                  self.options.element == "#sprint-board" ? document.getElementById("sprint-board") :
                  self.options.element == "#myKanban" ? document.getElementById("myKanban") : null
                  },
              });
  
          
  
              // validation toaster
              toastr.options = {
                closeButton: true,
                debug: false,
                newestOnTop: false,
                progressBar: true,
                positionClass: "toast-top-right",
                preventDuplicates: false,
                onclick: null,
                showDuration: "100",
                hideDuration: "1000",
                timeOut: "6000",
                extendedTimeOut: "1000",
                showEasing: "swing",
                hideEasing: "linear",
                showMethod: "fadeIn",
                hideMethod: "fadeOut",
              };
  
              window.getIssueData = function (page, limit) {
    
                notes=[];
                const params = window.location.search;
                const parameters = new URLSearchParams(params);
                const project_id = parameters.get("project_id");
     
                if (window.location.href === `${url}/agile_board`) {
                    
                  $.ajax({
                    type: "GET",
                    url: url + "/issue_statuses.json?key=" + api_key + " ",
                    dataType: "json",
                    beforeSend: function () {
                      $(".circle-loader").show();
                    },
                    success: function (Newresult, status, xhr) {
                      $(".circle-loader").toggleClass("load-complete");
                      $(".checkmark").toggle();
                      setTimeout(() => {
                        $(".circle-loader").hide();
                      }, 1000);
                      $("#ajax-indicator").css("display", "none");
                
                      $.ajax({
                        type: "GET",
                        url: project_id
                          ? url +
                          "/projects/" +
                          project_id +
                          `/issues.json?limit=${limit}&page=${page}&key=${api_key}`
                          : url +
                          `/issues.json?limit=${limit}&page=${page}&key=${api_key}`,
                        dataType: "json",
                        beforeSend: function () {
                          $(".circle-loader").show();
                        },
                        success: function (Newres, status, xhr) {
                          $(".circle-loader").toggleClass("load-complete");
                          $(".checkmark").toggle();
                          setTimeout(() => {
                            $(".circle-loader").hide();
                          }, 500);
                          var total_hour = "";
                        
                          Newres.issues.reduce(function (sum, current) {
                            return (total_hour = sum + current.estimated_hours);
                          }, 0);
  
                          $(".value-estimated-time").each(function () {
                          });
                          if (Newres.issues.length != 0) {
                            agile_issues=Newres.issues;
  
  
                            if(cards.includes("Tags")&&tagPluginExists)
                            {
                             fetchtags();
                        
                            }
                            if(project_id)
                            {
                              if(project_cards.includes("Notes"))
                              {
                               fetchnotes();
                              }
                            }
                            else{
                              if(cards.includes("Notes"))
                              {
                      
                               fetchnotes();
                              }
                            }
                            for (var i = 0; i < Newres.issues.length; i++) {
                              for (
                                var j = 0;
                                j < self.options.boards.length;
                                j++
                              ) {
                                if (
                                  Newres.issues[i].status.name ==
                                  self.options.boards[j].name
                                ) {
                                  self.options.boards[j].item.push(
                                    Newres.issues[i]
                                  );
                                  self.options.boards[j].issueCount =
                                    self.options.boards[j].item.length;
                                  self.addElement(self.options.boards[j].id, {
                                    created_on: Newres.issues[i].created_on,
                                    updated_on: Newres.issues[i].updated_on,
                                    estimated_hours: Newres.issues[i]
                                      .estimated_hours,
                                      total_spent_hours: Newres.issues[i].total_spent_hours,
                                    description: Newres.issues[i].description
                                      ? Newres.issues[i].description
                                      : "No data",
                                      ...(Newres.issues[i].hasOwnProperty("category")) ? {
                                        category: {
                                            id: Newres.issues[i].category && Newres.issues[i].category.id,
                                            name: Newres.issues[i].category && Newres.issues[i].category.name,
                                        }
                                    } : {},
                                    ...(Newres.issues[i].hasOwnProperty("fixed_version")) ? {
                                      fixed_version:{
                                        id: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.id,
                                        name: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.name,
                                      }}:{},
                                      ...(Newres.issues[i].hasOwnProperty("parent")) ? {
                                        parent:{
                                        id:  Newres.issues[i].parent&&Newres.issues[i].parent.id,
                                      }}:{},
                                      ...(Newres.issues[i].hasOwnProperty("children")) ? {children:Newres.issues[i].children}:{},
                                    subject: Newres.issues[i].subject,
                                    done_ratio: Newres.issues[i].done_ratio
                                      ? Newres.issues[i].done_ratio
                                      : "No data",
                                    id: Newres.issues[i].id,
                                    project: {
                                      id: Newres.issues[i].project.id,
                                      name: Newres.issues[i].project.name,
                                    },
                                    assigned_to: {
                                      id: Newres.issues[i].assigned_to
                                        ? Newres.issues[i].assigned_to.id
                                        : "Anonymous",
                                      name: Newres.issues[i].assigned_to
                                        ? Newres.issues[i].assigned_to.name
                                        : "Anonymous",
                                    },
                                    status :{
                                      id: Newres.issues[i].status.id,
                                      name: Newres.issues[i].status.name,
                                    },
                                    author:{
                                      id: Newres.issues[i].author.id,
                                      name: Newres.issues[i].author.name,
                                    },
                                    tracker: {
                                      id: Newres.issues[i].tracker.id,
                                      name: Newres.issues[i].tracker.name,
                                    },
                                    priority: {
                                      id: Newres.issues[i].priority.id,
                                      name: Newres.issues[i].priority.name,
                                    },
                                    start_date: Newres.issues[i].start_date,
                                    due_date: Newres.issues[i].due_date,
                                    story_points: Newres.issues[i].story_points,
                                    attachments: Newres.issues[i].attachments
                                  });
                                }
                              }
                            }
                              // -----
                         
  
                        issue_bords_ids = self.options.boards ;  //boards id
                        issue_counting = self.boardContainer ;    //issue updated values
                        
                        var issue_update_value = [];
                        var issue_bords_update = [];
                        
                        
                        // console.log(issue_bords_update,'isssue boards update');
                        
                        issue_bords_ids.forEach((object,i)=>{
                        issue_bords_update.push(object.id);
                        });
                        
                        
                        
                        issue_counting.forEach((object,i)=>{
                        issue_update_value.push(object.childElementCount);
                        // console.log(object.childElementCount,'child countingg')
                        });
                        
    
                        
                        // -------------
                        // for (let i = 0; i < issue_bords_update.length; i++) {
                        // $('.counting' + issue_bords_update[i]).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                        // }
                        // setTimeout(() => {
                        //   updateWipLimits();
                        //   }, 1000);
                        
                        //   setTimeout(() => {
                        //     updateKanbanContainerStatus();
                        //     }, 500);  
  
  
                        if(project_id){
                       
                          for (let i = 0; i < issue_bords_update.length; i++) {
                            let currentStatusId = issue_bords_update[i];
                            // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                            // let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                          
                            // let wipLimitHtml = '';
                            // if (currentWipLimit) {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            // } else {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            // }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                          
                            $('.counting' + currentStatusId).html(wipLimitHtml);
                          }
          
                        }
                        else {
                         
                        for (let i = 0; i < issue_bords_update.length; i++) {
                           currentStatusId = issue_bords_update[i];
                         //  let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                         // let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                        //   let wipLimitHtml = '';
                        //   if (currentWipLimit) {
                        //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                        //   } else {
                        //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                        //   }
                        let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                        
                          $('.counting' + currentStatusId).html(wipLimitHtml);
                        }
                      }
                        //  updateKanbanContainerStatus();
                          setTimeout(() => {
                            updateKanbanContainerStatus();
                            }, 500); 
  
                            //console.log(self,'self');
                          }
                        },
                      });
                    },
                    error: function (xhr, status, error) {
                      $(".circle-loader").toggleClass("load-complete");
                      $(".checkmark").toggle();
                      setTimeout(() => {
                        $(".circle-loader").hide();
                      }, 500);
                      //  console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText);
                    },
                  });
                } else {
                //  console.log("in prooject....")
                //   const params = window.location.search;
                //   const parameters = new URLSearchParams(params);
                  const params = redirect_path.split('?')[1];;

                  // Get the full URL path
                    const path = window.location.pathname;

                    // Extract the project identifier from the path
                    const pathSegments = path.split('/');
                    const project_id = pathSegments[2]; 

                  
                  if(project_id)
                  {
                   var trackers= getProjects(project_id);
                  }
       
                  $.ajax({
                    type: "GET",
                    url: url + "/issue_statuses.json?key=" + api_key + " ",
                    dataType: "json",
                    beforeSend: function () {
                      $(".circle-loader").show();
                    },
                    success: function (Newresult, status, xhr) {
                      $(".circle-loader").toggleClass("load-complete");
                      $(".checkmark").toggle();
                      setTimeout(() => {
                        $(".circle-loader").hide();
                      }, 1000);
                      $("#ajax-indicator").css("display", "none");
                   
                    
                      $.ajax({
                        type: "GET",
                        url: project_id
                          ? url +
                          "/projects/" +
                          project_id +
                          `/issues.json?limit=${limit}&page=${page}&&${params}&key=${api_key}`
                          : url +
                          `/issues.json?limit=${limit}&page=${page}&&${params}&key=${api_key}`,
                        dataType: "json",
                        beforeSend: function () {
                          $(".circle-loader").show();
                        },
                        success: function (Newres, status, xhr) {
                          $(".circle-loader").toggleClass("load-complete");
                          $(".checkmark").toggle();
                          setTimeout(() => {
                            $(".circle-loader").hide();
                          }, 500);
                    if (Newres.issues.length != 0) {
                          agile_issues=Newres.issues;
                          boards_array=[];
  
                          var  group_by = parameters.get('group_by');
                          
                          if(cards.includes("Tags")&&tagPluginExists)
                          {
                           fetchtags();
                      
                          }
                          if(project_id)
                          {
                            if(project_cards.includes("Notes"))
                            {
                             fetchnotes();
                            }
                          }
                          else{
                            if(cards.includes("Notes"))
                            {
                             fetchnotes();
                            }
                          }
  
                          if(Newres.issues.length!=0)
                          {
                  // increaseDynamicHeight();
                  var sprintId = parameters.get('sprint_craft');
                  if(params.includes("sprint_craft")){
  
                    for (var i=0; i<Newres.issues.length; i++)
                      {
                        if ( Newres.issues[i].sprint_craft !== null && Newres.issues[i].sprint_craft == sprintId ){
  
                        for(var j=0; j<self.options.boards.length; j++)
                           {
                           if(Newres.issues[i].status.name==self.options.boards[j].name)
                              {
                               self.options.boards[j].item.push(Newres.issues[i]);
                               self.options.boards[j].issueCount=self.options.boards[j].item.length
                               $(".counting"+self.options.boards[j].id).each(function(index,value){
                                 // $(this).html(`(${ self.options.boards[j].issueCount})`);
                                 $(this).html('( '+ self.options.boards[j].issueCount + ')');
                                });
                               self.addElement(self.options.boards[j].id,{
                               created_on:Newres.issues[i].created_on,
                               updated_on:Newres.issues[i].updated_on,
                               estimated_hours:Newres.issues[i].estimated_hours,
                               total_spent_hours: Newres.issues[i].total_spent_hours,
                               description: Newres.issues[i].description
                                 ? Newres.issues[i].description
                                 : "No data",
                                 ...(Newres.issues[i].hasOwnProperty("category")) ? {
                                   category: {
                                       id: Newres.issues[i].category && Newres.issues[i].category.id,
                                       name: Newres.issues[i].category && Newres.issues[i].category.name,
                                   }
                               } : {},
                               ...(Newres.issues[i].hasOwnProperty("fixed_version")) ? {
                                 fixed_version:{
                                   id: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.id,
                                   name: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.name,
                                 }}:{},
                                 ...(Newres.issues[i].hasOwnProperty("parent")) ? {
                                   parent:{
                                   id:  Newres.issues[i].parent&&Newres.issues[i].parent.id,
                                 }}:{},
                               subject:Newres.issues[i].subject, 
                               done_ratio:Newres.issues[i].done_ratio?Newres.issues[i].done_ratio:"No data",
                               id:Newres.issues[i].id,
                               project:{
                                 id:Newres.issues[i].project.id,
                                 name:Newres.issues[i].project.name
                               },
                              assigned_to:{
                                 id:Newres.issues[i].assigned_to?Newres.issues[i].assigned_to.id:"Anonymous",
                                 name:Newres.issues[i].assigned_to?Newres.issues[i].assigned_to.name:"Anonymous"
                               },
                               ...(Newres.issues[i].hasOwnProperty("children")) ? {children:Newres.issues[i].children}:{},
                               status :{
                                 id: Newres.issues[i].status.id,
                                 name: Newres.issues[i].status.name,
                               },
                               author:{
                                 id: Newres.issues[i].author.id,
                                 name: Newres.issues[i].author.name,
                               },
                               tracker:{
                                 id:Newres.issues[i].tracker.id,
                                 name:Newres.issues[i].tracker.name
                               },
                               priority:{
                                 id:Newres.issues[i].priority.id,
                                 name:Newres.issues[i].priority.name
                               },
                               start_date:Newres.issues[i].start_date,
                               due_date:Newres.issues[i].due_date,
                              attachments: Newres.issues[i].attachments
                             }); 
                          }
                        }
                      }
                      }  
                     //  ----------------
  
  
                  } else {
                  
                
                 for (var i=0; i<Newres.issues.length; i++)
                 {
                   for(var j=0; j<self.options.boards.length; j++)
                      {
                      if(Newres.issues[i].status.name==self.options.boards[j].name)
                         {
                          self.options.boards[j].item.push(Newres.issues[i]);
                          self.options.boards[j].issueCount=self.options.boards[j].item.length
                          $(".counting"+self.options.boards[j].id).each(function(index,value){
                            // $(this).html(`(${ self.options.boards[j].issueCount})`);
                            $(this).html('( '+ self.options.boards[j].issueCount + ')');
                           });
                          self.addElement(self.options.boards[j].id,{
                          created_on:Newres.issues[i].created_on,
                          updated_on:Newres.issues[i].updated_on,
                          estimated_hours:Newres.issues[i].estimated_hours,
                          total_spent_hours: Newres.issues[i].total_spent_hours,
                          description: Newres.issues[i].description
                            ? Newres.issues[i].description
                            : "No data",
                            ...(Newres.issues[i].hasOwnProperty("category")) ? {
                              category: {
                                  id: Newres.issues[i].category && Newres.issues[i].category.id,
                                  name: Newres.issues[i].category && Newres.issues[i].category.name,
                              }
                          } : {},
                          ...(Newres.issues[i].hasOwnProperty("fixed_version")) ? {
                            fixed_version:{
                              id: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.id,
                              name: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.name,
                            }}:{},
                            ...(Newres.issues[i].hasOwnProperty("parent")) ? {
                              parent:{
                              id:  Newres.issues[i].parent&&Newres.issues[i].parent.id,
                            }}:{},
                          subject:Newres.issues[i].subject, 
                          done_ratio:Newres.issues[i].done_ratio?Newres.issues[i].done_ratio:"No data",
                          id:Newres.issues[i].id,
                          project:{
                            id:Newres.issues[i].project.id,
                            name:Newres.issues[i].project.name
                          },
                         assigned_to:{
                            id:Newres.issues[i].assigned_to?Newres.issues[i].assigned_to.id:"Anonymous",
                            name:Newres.issues[i].assigned_to?Newres.issues[i].assigned_to.name:"Anonymous"
                          },
                          ...(Newres.issues[i].hasOwnProperty("children")) ? {children:Newres.issues[i].children}:{},
                          status :{
                            id: Newres.issues[i].status.id,
                            name: Newres.issues[i].status.name,
                          },
                          author:{
                            id: Newres.issues[i].author.id,
                            name: Newres.issues[i].author.name,
                          },
                          tracker:{
                            id:Newres.issues[i].tracker.id,
                            name:Newres.issues[i].tracker.name
                          },
                          priority:{
                            id:Newres.issues[i].priority.id,
                            name:Newres.issues[i].priority.name
                          },
                          start_date:Newres.issues[i].start_date,
                          due_date:Newres.issues[i].due_date,
                         attachments: Newres.issues[i].attachments
                        }); 
                     }
                   }
                 }  
                }
                //  ----------------
  
                }
  
                
      
                          
                          // ..................logic start 
                               // function to convert in date format
                   function changeDateFormat(format){
                    var today = new Date(format);
                    var dd = String(today.getDate()).padStart(2, "0");
                    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
                    var yyyy = today.getFullYear();
                    return  today = dd + "." + mm + "." + yyyy;
                    }
            
                    // if group by filter is applied 
                    if(group_by)
                    {
                          
                     // Given array of issues
                     const issues =Newres.issues;
                     // console.log(res.issues,"issues");
                     // Initialize an empty object to store assigned issues
                     const assignedIssues = {};
                     // Iterate through the issues and group them by assigned user
                     issues.forEach((issue) => {
                      if(params.includes('sprint_craft'))
                      {
                     
                        if(issue.sprint_craft !== null && issue.sprint_craft == sprintId)
                        {
                  
                        let assignedUserId = "No";
                       // Set default values based on the 'group_by' condition
                        if (group_by === 'category' && !issue.hasOwnProperty(group_by)) {
                          assignedUserId = 'Blank';
                        }     else if(group_by === 'assigned_to' && !issue.hasOwnProperty(group_by)){
                          assignedUserId = 'Anonymous';
                        }else if (issue.hasOwnProperty(group_by)) {
                      
                          switch (group_by) {
                            case 'closed_on':
                              assignedUserId = issue.closed_on == null ? 'Blank' : changeDateFormat(issue[group_by]) ;
                              break;
                            case 'is_private':
                              assignedUserId = 'No';
                              break;
                            case 'updated_on':
                            case 'created_on':
                            case 'start_date':
                            case 'due_date':
                              const updatedDate =issue[group_by]!=null? changeDateFormat(issue[group_by]) : "Blank";
                              assignedUserId = updatedDate;
                              break;
                            default:
                              assignedUserId = typeof issue[group_by] === 'object' ? issue[group_by].name : issue[group_by];
                          }
                        }
    
                        // Check if the user key exists, if not, initialize it with an empty array
                        if (!assignedIssues[assignedUserId]) {
                          assignedIssues[assignedUserId] = [];
                        }
                        // Push the issue to the array of assigned issues for the user
                        assignedIssues[assignedUserId].push(issue)   
                      }    
                      else{
                        // if($(".nodata").length==0)
                        // {
                        //   $("#myKanban").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                        // }
                   
                      }      
                      }
                      else{
                        let assignedUserId = "No";
                        // if sprint is not there
                          // Set default values based on the 'group_by' condition
                          if (group_by === 'category' && !issue.hasOwnProperty(group_by)) {
                            assignedUserId = 'Blank';
                          }     else if(group_by === 'assigned_to' && !issue.hasOwnProperty(group_by)){
                            assignedUserId = 'Anonymous';
                          }else if (issue.hasOwnProperty(group_by)) {
                            switch (group_by) {
                              case 'closed_on':
                                assignedUserId = issue.closed_on == null ? 'Blank' : changeDateFormat(issue[group_by]) ;
                                break;
                              case 'is_private':
                                assignedUserId = 'No';
                                break;
                              case 'updated_on':
                              case 'created_on':
                              case 'start_date':
                              case 'due_date':
                                const updatedDate =issue[group_by]!=null? changeDateFormat(issue[group_by]) : "Blank";
                                assignedUserId = updatedDate;
                                break;
                              default:
                                assignedUserId = typeof issue[group_by] === 'object' ? issue[group_by].name : issue[group_by];
                            }
                          }
    
                          // Check if the user key exists, if not, initialize it with an empty array
                          if (!assignedIssues[assignedUserId]) {
                            assignedIssues[assignedUserId] = [];
                          }
                          // Push the issue to the array of assigned issues for the user
                          assignedIssues[assignedUserId].push(issue)    
                 }
                     });
                      //  console.log(assignedIssues,"on page scrolll");
                       kanban_issues=assignedIssues;
                  
                       const  array_item=[];
                       Newresult.issue_statuses.forEach(object => {
                                array_item.push(''+object.id)    
                      });
                      Newresult.issue_statuses.forEach(object => {
                                object.id=''+object.id
                                object.dragTo=array_item
                               //  object.issueCount=object.item.length
                       });
                       Newresult.issue_statuses.forEach((object,i)=> {
                         if(i<6)
                            {
                             boards_array.push(object)
                             }
                            else if(project_boards_values){
                              project_boards_values.forEach((list)=>{
                               if(list==object.id)
                               {
                                 boards_array.push(object)
                                 
                               }
                              })
                            }
                          object.id=''+object.id
                          object.dragTo=array_item
                         //  object.issueCount=object.item.length
                          object.tracker_data=trackers
                       });
                       // Counter for unique container IDs
     
                 
                    // console.log(assignedIssues,"assigne dISsueess");
                   let mainContainer =document.getElementById("myKanban");
              
                     for (const key in  assignedIssues) {
               
                       if (Object.hasOwnProperty.call( assignedIssues, key)) {
                     
             
                         var stringWithoutSpaces = key.replace(/[\s\W-]/g, '');
                         var containerId = `group-${stringWithoutSpaces}`;
                      // Check if a container with the same id already exists
                         var existingContainer = document.getElementById(containerId);
                         var kanban_array=Newresult.issue_statuses.map(item1 => ({
                          ...item1,
                          item:  assignedIssues[key].filter(item2 => item2.status.id == item1.id),
                          dragTo: Newresult.issue_statuses.map(item=>item.id),
                          issueCount:assignedIssues[key].filter(item2 => item2.status.id == item1.id).length
                        }));;
                         if(existingContainer)
                         {
                          let totalCount=parseInt($(`#${containerId} .group-div .badge-count `).html())+assignedIssues[key].length;
                   
                          $(`#${containerId} .group-div .badge-count `).html(totalCount);
                         }
                         else{
                          var userContainer = document.createElement("div");
                          userContainer.className = "myKanban";
                          userContainer.innerHTML+=`<div class="myKanban"  id="${containerId}"> 
                            <div class="group-div">
                            <span  value=${stringWithoutSpaces} class="expander icon icon-expended agile-arrow" onclick="toggleGroup(this)">&nbsp;</span>
                            <span class="name"><span class="user" >${key}</span></span>
                            <span style="top:0px;" class="badge badge-count count">${assignedIssues[key].length}</span>
                              </div>
                          </div>`;
                
                             mainContainer.appendChild(userContainer);
  
                                // Creating a new key "item" in the first array and populating it with matching objects from the second array
                            kanban_array=  Newresult.issue_statuses.map(item1 => ({
                              ...item1,
                              item:  assignedIssues[key].filter(item2 => item2.status.id == item1.id),
                              dragTo: Newresult.issue_statuses.map(item=>item.id),
                              issueCount:assignedIssues[key].filter(item2 => item2.status.id == item1.id).length
                            }));
      
                         }
                        
                  
                             if( assignedIssues[key].length!=0)
                             {
                               assignedIssues[key].reduce(function(sum, current) {
                                 return total_hour= sum + current.estimated_hours;
                                 }, 0); 
                             }
                             else{
                               total_hour=0.00;
                             }
                             let local_data= project_boards_values
                             Newresult.issue_statuses.forEach((object,i)=> {
                                  if(local_data.includes(object.id))
                                  {
                                     boards_array.push(object)
                                  }
                             })
             
     
                     
                         //  console.log(boards_array,"boards array")
                         var ele1 = `#${containerId}`;
                         createdContainers.push(ele1);
                        //  console.log( createdContainers,"kanbanissues????");
               
                       if(existingContainer){
                        // console.log("yes exisiting >>>");
                        let iscontainer=false;
                        createdContainers.forEach((container)=>{
                          if(container===ele1)
                          {
                            iscontainer=true;
                           
                          }
                        })
                        if(iscontainer)
                        {
                          kanban_array.forEach((i)=>{
                        
                            i.item.forEach((j)=>{
                              self.addElement(i.id, {
                                created_on:j.created_on,
                                updated_on: j.updated_on,
                                estimated_hours: j
                                  .estimated_hours,
                                total_spent_hours: j.total_spent_hours,
                                description:j.description
                                  ? j.description
                                  : "No data",
                                  ...(j.hasOwnProperty("category"))?{category:{
                                    id: j.category&&j.category.id,
                                    name: j.category&&j.category.name,
                                  }}:{},
                                  ...(j.hasOwnProperty("fixed_version"))?{fixed_version:{
                                    id:  j.fixed_version&&j.fixed_version.id,
                                    name: j.fixed_version&&j.fixed_version.name,
                                  }}:{},
                                  ...(j.hasOwnProperty("parent"))?{parent:{
                                    id: j.parent&&j.parent.id,
                                  }}:{},
                                subject: j.subject,
                                ...(j.hasOwnProperty("children")) ? {children:j.children}:{},
                                done_ratio:j.done_ratio
                                  ? j.done_ratio
                                  : "No data",
                                id: j.id,
                                project: {
                                  id: j.project.id,
                                  name:j.project.name,
                                },
                                status :{
                                  id:  j.status.id,
                                  name: j.status.name,
                                },
                                author:{
                                  id:  j.author.id,
                                  name:  j.author.name,
                                },
                                assigned_to: {
                                  id:j.assigned_to
                                    ?j.assigned_to.id
                                    : "Anonymous",
                                  name: j.assigned_to
                                    ?j.assigned_to.name
                                    : "Anonymous",
                                },
                                tracker: {
                                  id: j.tracker.id,
                                  name: j.tracker.name,
                                },
                                priority: {
                                  id: j.priority.id,
                                  name:j.priority.name,
                                },
                                start_date: j.start_date,
                                due_date:j.due_date,
                                story_points:j.story_points,
                  
                              });
                            })
                       
                           })
                          //  console.log(  issue_counting ,"self.....");
                          //  logic to count cards 
                          issue_bords_ids = self.options.boards ;  //boards id
                          issue_counting = self.boardContainer ;
                   
                             //issue updated values
                          
                          var issue_update_value = [];
                          var issue_bords_update = [];
                          
                          issue_bords_ids.forEach((object,i)=>{
                          issue_bords_update.push(object.id);
                          });
                          
                          
                          issue_counting.forEach((object,i)=>{
                          issue_update_value.push(object.childElementCount);
                          });
                          
                          
  
                          // -------------
                          // for (let i = 0; i < issue_bords_update.length; i++) {
                          //   $(`.${containerId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                          // }
                          // setTimeout(() => {
                          //   updateWipLimits();
                          //   }, 1000);
                          
                          //   setTimeout(() => {
                          //     updateKanbanContainerStatus();
                          //     }, 500);  
                          if(project_id){
                          
                            for (let i = 0; i < issue_bords_update.length; i++) {
                              let currentStatusId = issue_bords_update[i];
                              // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                              let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                            
                            //   let wipLimitHtml = '';
                            //   if (currentWipLimit) {
                            //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            //   } else {
                            //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            //   }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            
                              $(`.${containerId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                            }
            
                          }
                          else {
                          
                          for (let i = 0; i < issue_bords_update.length; i++) {
                            let currentStatusId = issue_bords_update[i];
                            // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                            // let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === issue_bords_update[i]) : null;
                          
                            // let wipLimitHtml = '';
                            
                            // if (currentWipLimit) {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            // } else {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            // }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                          
                            $(`.${containerId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                          }
                        }
                          setTimeout(() => {
                              updateKanbanContainerStatus();
                              }, 500);  
                          // updateKanbanContainerStatus();
  
                        }
                      }
                         else{
                 
                          createKanban(ele1,containerId);
                          issue_bords_ids = self.options.boards ;  //boards id
                          issue_counting = self.boardContainer ;    //issue updated values
                          
                          var issue_update_value = [];
                          var issue_bords_update = [];
                          
                          issue_bords_ids.forEach((object,i)=>{
                          issue_bords_update.push(object.id);
                          });
                          
                          
                          issue_counting.forEach((object,i)=>{
                          issue_update_value.push(object.childElementCount);
                          });
                          
                   
                          // -------------
                          // for (let i = 0; i < issue_bords_update.length; i++) {
                          //   $(`.${containerId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                          // }
                          // setTimeout(() => {
                          //   updateWipLimits();
                          //   }, 1000);
                          
                          //   setTimeout(() => {
                          //     updateKanbanContainerStatus();
                          //     }, 500);  
  
                          if(project_id){
                        
                            for (let i = 0; i < issue_bords_update.length; i++) {
                              let currentStatusId = issue_bords_update[i];
                              // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                              let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                            
                            //   let wipLimitHtml = '';
                            //   if (currentWipLimit) {
                            //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            //   } else {
                            //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            //   }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            
                              $(`.${containerId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                            }
            
                          }
                          else {
                          
                          for (let i = 0; i < issue_bords_update.length; i++) {
                            let currentStatusId = issue_bords_update[i];
                            // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                            let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === issue_bords_update[i]) : null;
                            
                            // let wipLimitHtml = '';
                            // if (currentWipLimit) {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            // } else {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            // }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                          
                            $(`.${containerId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                          }
                        }
                        setTimeout(() => {
                          updateKanbanContainerStatus();
                          }, 500);  
                        // updateKanbanContainerStatus();
  
                         }
                  
                   function createKanban(ele,groupId) {
                    // console.log(ele,"<<<<<<");
                    // if(self.options.element===ele)
                    // {
                    //   console.log(self,   kanban_array,"&&&&yes exisiing")
                    //   // self.addElement( assignedIssues[key])
                       
                     
                    // }else{
                    var KanbanTest = new jKanban({
                       element: ele,
                       itemHandleOptions:{
                         enabled: true,
                       },
                       dragEl:function(el, source){
                   
                     },
                      context: function(el, e) {
                     
                      },
                      dropEl: function(el, target, source, sibling ,source_id){
                    
                       
                       getWorkflow(el.dataset.eid);
                       var target_int = parseInt(sibling);
                       var source_int = parseInt(source_id);
                       if (workflow_status.includes(target_int)) {
                        // console.log("successfully applied 4");
                         // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully");
                         // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                         var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                         var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);
       
                        //  console.log(header_kanban,"header kanban");
                        //  console.log(matches,"matches");
                         if (matches && matches.length === 3) {
                           // Extracted values in integer format
                           var value1 = parseInt(matches[1]);
                           var value2 = parseInt(matches[2]);
               
                          
                           value1++;
               
                         
                           if (value1 > value2) {
                               toastr.warning("Work-in-progress limit exceeded !! ");
                              }       
                           }
                          //  updateKanbanContainerStatus();
  
                        //  setTimeout(() => {
                        //   updateWipLimits();
                        //   }, 2000);
              
                          setTimeout(() => {
                            updateKanbanContainerStatus();
                            }, 500);        
                       }
                        else if (workflow_status.length === 0) {
                         // console.log("no the issue[#"+ el.dataset.eid +"] can't be changed ");
                         toastr["error"]('workflow is not defined for this status');
                         KanbanTest.drake.cancel(true);
                        //  console.log("its applied 1");
                       } else {
                         // console.log("no the issue[#" + el.dataset.eid +"] cant drop this status");
                         toastr["error"]('workflow is not defined for this status');
                        KanbanTest.drake.cancel(true);
  
                       }
     
                      var content =
                      {
                          "status_id": parseInt(sibling)
                       }
                      $.ajax({
                     type: "PUT",
                     url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
                     dataType: "json",
                     contentType: 'application/json',
                     data: JSON.stringify({
                     "issue": content
                    }),
                     success: function (res,status, xhr) {      
                     $.ajax({
                      type: "GET",
                     url:url+`/issue_statuses.json?key=${api_key}`,
                      dataType: "json",
                     success: function (Newresult, status, xhr) {
                     const params =window.location.search
                     const parameters = new URLSearchParams(params);
                     const  project_id = parameters.get('project_id');
                     $.ajax({
                     type: "GET",
                     url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}`:url+`/issues.json?key=${api_key}&${params}`,
                     dataType: "json",
                     success: function (Newres, status, xhr) {
                      Newresult.issue_statuses.forEach(object => {
                                 object.item= []
                       });
                     Newres.issues.forEach(object => {
                         Newresult.issue_statuses.forEach(option=>{
                            if(object.status.name==option.name)
                             {
                               option.item.push(object)
                              }
                             });
                          });           
                       const  array_item=[];
                        Newresult.issue_statuses.forEach(object => {
                                 array_item.push(''+object.id)    
                       });
                       Newresult.issue_statuses.forEach(object => {
                                 object.id=''+object.id
                                 object.dragTo=array_item
                               object.issueCount=object.item.length
     
                        });
                      
                        Newresult.issue_statuses.forEach(object => {
                              Newresult.issue_statuses.forEach(option => {
                               option.issueCount=object.item.length
                             
                                 
                       });
                        })
     // ----------------------------------------------
                         issue_bords_ids = KanbanTest.options.boards ;  //boards id
                         issue_counting = KanbanTest.boardContainer ;
                 //issue updated values
                       
     
                        var issue_update_value = [];
                        var issue_bords_update = [];
     
                       issue_bords_ids.forEach((object,i)=>{
                         issue_bords_update.push(object.id);
                       });
                       issue_counting.forEach((object,i)=>{
                         issue_update_value.push(object.childElementCount);
                     
                     }); 
     
                   
                    //  for (let i = 0; i < issue_bords_update.length; i++) {
                    //   $(`.${groupId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] +  ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span> )');
                    //  }
  
  
                     if(project_id){
                      for (let i = 0; i < issue_bords_update.length; i++) {
                        let currentStatusId = issue_bords_update[i];
                        // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                        let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                      
                        // let wipLimitHtml = '';
                        // if (currentWipLimit) {
                        //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                        // } else {
                        //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                        // }
                        let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                      
                        $(`.${groupId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                      }
      
                    }
                    else {
                    for (let i = 0; i < issue_bords_update.length; i++) {
                      let currentStatusId = issue_bords_update[i];
                      // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                    //   let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                    
                    //   let wipLimitHtml = '';
                    //   if (currentWipLimit) {
                    //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                    //   } else {
                    //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                    //   }
                    let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                    
                      $(`.${groupId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
                    }
                  }
            
                    // updateKanbanContainerStatus();
                     
  
                    //  setTimeout(() => {
                    //   updateWipLimits();
                    //   }, 1000);
                    
                      setTimeout(() => {
                        updateKanbanContainerStatus();
                        }, 500);  
                     }
                    });
                   },
                    error: function (xhr, status, error) {
                     // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                   }
               });
                   },
                    error: function (xhr, status, error) {
                   //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    }
                     });
                       },
                       itemAddOptions: {
                         enabled: (project_id&&trackers.length!=0)?true:false,
                         content: '+ Add New ISSUE',
                         class: 'Add-card',
                         footer: true
                       },
                       boards:kanban_array,
                       cardCounter:Newresult.issue_statuses.length
                     });
                    }
                   }
                    //  }
                   }
                 }
              // .......logic end 
              else{
                
                // if user in a particular project page and only project id is visible not the entire params 
                var sprintId = parameters.get('sprint_craft');
                if(params.includes("sprint_craft")){
                  if (Newres.issues.length != 0) {
                    for (var i = 0; i < Newres.issues.length; i++) {
  
                      if (
                        Newres.issues[i].sprint_craft !== null &&
                        Newres.issues[i].sprint_craft == sprintId
                      ) {
                      for ( var j = 0; j < self.options.boards.length; j++) {
                        if (
                          Newres.issues[i].status.name ==
                          self.options.boards[j].name
                        ) {
                          self.options.boards[j].item.push(
                            Newres.issues[i]
                          );
                          self.options.boards[j].issueCount =
                            self.options.boards[j].item.length;
  
                            if(project_id){
                              // var wipLimit = project_wip_limit.find(entry => entry.status_id === self.options.boards[j].id);
                              var wipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === self.options.boards[j].id) : null;
                            }else{
                              // var wipLimit = global_wip_limit.find(entry => entry.status_id === self.options.boards[j].id);
                              var wipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === self.options.boards[j].id) : null;
                            }
  
  
                            $(".counting" + self.options.boards[j].id).each(
                              function (index, value) {
                                $(this).html(                              
                                  // `( ${self.options.boards[j].issueCount}  <span class="wip" id="wip_limit_${self.options.boards[j].id}"></span> )`
                                //   `( ${self.options.boards[j].issueCount}${wipLimit ? ' / ' + wipLimit.limit : ''} <span class="wip" id="wip_limit_${self.options.boards[j].id}"></span> )`
                                `( ${self.options.boards[j].issueCount} )`
                            );
                              }
                            );
                          self.addElement(self.options.boards[j].id, {
                            created_on: Newres.issues[i].created_on,
                            updated_on: Newres.issues[i].updated_on,
                            estimated_hours: Newres.issues[i]
                              .estimated_hours,
                            total_spent_hours: Newres.issues[i].total_spent_hours,
                            description: Newres.issues[i].description
                              ? Newres.issues[i].description
                              : "No data",
                              ...(Newres.issues[i].hasOwnProperty("category")) ? {
                                category: {
                                    id: Newres.issues[i].category && Newres.issues[i].category.id,
                                    name: Newres.issues[i].category && Newres.issues[i].category.name,
                                }
                            } : {},
                            ...(Newres.issues[i].hasOwnProperty("fixed_version")) ? {
                              fixed_version:{
                                id: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.id,
                                name: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.name,
                              }}:{},
                              ...(Newres.issues[i].hasOwnProperty("parent")) ? {
                                parent:{
                                id:  Newres.issues[i].parent&&Newres.issues[i].parent.id,
                              }}:{},
                            subject: Newres.issues[i].subject,
                            done_ratio: Newres.issues[i].done_ratio
                              ? Newres.issues[i].done_ratio
                              : "No data",
                            id: Newres.issues[i].id,
                            project: {
                              id: Newres.issues[i].project.id,
                              name: Newres.issues[i].project.name,
                            },
                            status :{
                              id: Newres.issues[i].status.id,
                              name: Newres.issues[i].status.name,
                            },
                            author:{
                              id: Newres.issues[i].author.id,
                              name: Newres.issues[i].author.name,
                            },
                            assigned_to: {
                              id: Newres.issues[i].assigned_to
                                ? Newres.issues[i].assigned_to.id
                                : "Anonymous",
                              name: Newres.issues[i].assigned_to
                                ? Newres.issues[i].assigned_to.name
                                : "Anonymous",
                            },
                            tracker: {
                              id: Newres.issues[i].tracker.id,
                              name: Newres.issues[i].tracker.name,
                            },
                            priority: {
                              id: Newres.issues[i].priority.id,
                              name: Newres.issues[i].priority.name,
                            },
                            start_date: Newres.issues[i].start_date,
                            due_date: Newres.issues[i].due_date,
                            story_points: Newres.issues[i].story_points,
                            attachments: Newres.issues[i].attachments
                          });
                        }
                      }
                  }
                }
                //  updateKanbanContainerStatus();
                // setTimeout(() => {
                //   updateWipLimits();
                //   }, 1000);
                
                  setTimeout(() => {
                    updateKanbanContainerStatus();
                    }, 500);  
                }
              }
                else{
                //  -------------deuplicate issue resolve by  commet this code ---
              //      if (Newres.issues.length != 0) {
              //               for (var i = 0; i < Newres.issues.length; i++) {
              //                 for (var j = 0; j < self.options.boards.length; j++ ) {
              //                   if ( Newres.issues[i].status.name == self.options.boards[j].name ) {
              //                     self.options.boards[j].item.push(
              //                       Newres.issues[i]
              //                     );
              //                     self.options.boards[j].issueCount =
              //                       self.options.boards[j].item.length;
  
              //                       if(project_id){
              //                         // var wipLimit = project_wip_limit.find(entry => entry.status_id === self.options.boards[j].id);
              //                         var wipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === self.options.boards[j].id) : null;
              //                       }else{
              //                         // var wipLimit = global_wip_limit.find(entry => entry.status_id === self.options.boards[j].id);
              //                         var wipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === self.options.boards[j].id) : null;
              //                       }
  
              //                     $(".counting" + self.options.boards[j].id).each(
              //                       function (index, value) {
              //                         $(this).html(
              //                           // `( ${self.options.boards[j].issueCount}  <span class="wip" id="wip_limit_${self.options.boards[j].id}"></span> )`
              //                           `( ${self.options.boards[j].issueCount}${wipLimit ? ' / ' + wipLimit.limit : ''} <span class="wip" id="wip_limit_${self.options.boards[j].id}"></span> )`
              //                         );
              //                       }
              //                     );  
  
              //                     self.addElement(self.options.boards[j].id, {
              //                       created_on: Newres.issues[i].created_on,
              //                       updated_on: Newres.issues[i].updated_on,
              //                       estimated_hours: Newres.issues[i]
              //                         .estimated_hours,
              //                         total_spent_hours: Newres.issues[i].total_spent_hours,
              //                       description: Newres.issues[i].description
              //                         ? Newres.issues[i].description
              //                         : "No data",
              //                         ...(Newres.issues[i].hasOwnProperty("category")) ? {
              //                           category: {
              //                               id: Newres.issues[i].category && Newres.issues[i].category.id,
              //                               name: Newres.issues[i].category && Newres.issues[i].category.name,
              //                           }
              //                       } : {},
              //                       ...(Newres.issues[i].hasOwnProperty("fixed_version")) ? {
              //                         fixed_version:{
              //                           id: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.id,
              //                           name: Newres.issues[i].fixed_version&&Newres.issues[i].fixed_version.name,
              //                         }}:{},
              //                         ...(Newres.issues[i].hasOwnProperty("parent")) ? {
              //                           parent:{
              //                           id:  Newres.issues[i].parent&&Newres.issues[i].parent.id,
              //                         }}:{},
              //                       subject: Newres.issues[i].subject,
              //                       done_ratio: Newres.issues[i].done_ratio
              //                         ? Newres.issues[i].done_ratio
              //                         : "No data",
              //                       id: Newres.issues[i].id,
              //                       project: {
              //                         id: Newres.issues[i].project.id,
              //                         name: Newres.issues[i].project.name,
              //                       },
              //                       status :{
              //                         id: Newres.issues[i].status.id,
              //                         name: Newres.issues[i].status.name,
              //                       },
              //                       author:{
              //                         id: Newres.issues[i].author.id,
              //                         name: Newres.issues[i].author.name,
              //                       },
              //                       assigned_to: {
              //                         id: Newres.issues[i].assigned_to
              //                           ? Newres.issues[i].assigned_to.id
              //                           : "Anonymous",
              //                         name: Newres.issues[i].assigned_to
              //                           ? Newres.issues[i].assigned_to.name
              //                           : "Anonymous",
              //                       },
              //                       tracker: {
              //                         id: Newres.issues[i].tracker.id,
              //                         name: Newres.issues[i].tracker.name,
              //                       },
              //                       priority: {
              //                         id: Newres.issues[i].priority.id,
              //                         name: Newres.issues[i].priority.name,
              //                       },
              //                       start_date: Newres.issues[i].start_date,
              //                       due_date: Newres.issues[i].due_date,
              //                       story_points: Newres.issues[i].story_points,
              //                       attachments: Newres.issues[i].attachments
              //                     });
              //                   }
              //            }
              //       }
              // }  //  -------------deuplicate issue resolve by  commet this code ---
  
              setTimeout(() => {
                updateKanbanContainerStatus();
                }, 500);  
  
            }
            
          }
          }
                        }
            });
                    
                  },
                    error: function (xhr, status, error) {
                      $(".circle-loader").toggleClass("load-complete");
                      $(".checkmark").toggle();
                      setTimeout(() => {
                        $(".circle-loader").hide();
                      }, 500);
                      //  console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
                //  updateKanbanContainerStatus();
  
                // setTimeout(() => {
                //   updateWipLimits();
                //   }, 2000);
      
                  setTimeout(() => {
                    updateKanbanContainerStatus();
                    }, 500);
  
              };
  
                // function to show tooltip start
              function showtooltip(event,issue) {
             
                currentIssue = issue;
                var tooltip = document.getElementById('kanban-tooltip');
                let Estimation=issue.estimated_hours!=null?issue.estimated_hours:0;            
                if(timeFormat=="minutes")
                {
                  Estimation=convertToHHMM(Estimation)
                }
                else{
                  if(Number.isInteger(Estimation))
                  {
                    Estimation=Estimation;
                  }
                  else{
                    Estimation=Estimation.toFixed(2);
                  }
                 
                }
       
                tooltip.innerHTML = `<table class="issue-card">
                      <tbody>
                        <tr class="issue-card__attr"><td class="issue-card__label">Subject:</td><td  id="issue_subject" class="issue-card__value">${issue.subject}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Project:</td><td class="issue-card__value">${issue.project&&issue.project.name}</td></tr>
                          ${self.options.element=="#version-board"?`<tr class="issue-card__attr"><td class="issue-card__label">Status:</td><td class="issue-card__value">${issue.status&&issue.status.name}</td></tr>`:""}
                        <tr class="issue-card__attr"><td class="issue-card__label">Priority:</td><td class="issue-card__value">${issue.priority&&issue.priority.name}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Tracker:</td><td class="issue-card__value">${issue.tracker&&issue.tracker.name}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Assignee:</td><td class="issue-card__value">${issue.hasOwnProperty("assigned_to")?issue.assigned_to.name:"Anonymous"}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Author:</td><td class="issue-card__value">${issue.author&&issue.author.name}</tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Start date:</td><td class="issue-card__value">${issue.start_date!=null?issue.start_date:"yyyy/mm/dd"}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Due date:</td><td class="issue-card__value">${issue.due_date!=null?issue.due_date:"yyyy/mm/dd"}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Done%:</td><td class="issue-card__value">${issue.done_ratio+"%"}</td></tr>
                        <tr class="issue-card__attr"><td class="issue-card__label">Estimated time:</td><td class="issue-card__value">${Estimation+"h"}</td></tr>
                      </tbody>
                    </table>`;
  
                    tooltip.style.display = 'block';
                    // Calculate the horizontal position
                    var left = event.clientX + 10;
                    if (left + tooltip.offsetWidth > window.innerWidth) {
                        left = event.clientX - tooltip.offsetWidth - 10;
                    }
  
                    // Select the main div for the kanban item
                    var mainDiv = document.querySelector(`.kanban-item${issue.id}`);
                    var rect = mainDiv.getBoundingClientRect();
                    var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                    var topPosition = rect.top + scrollTop + 50;
  
                    // Check if there is enough space below the item to display the tooltip
                    var bottomSpace = window.innerHeight - rect.bottom;
                    if (bottomSpace < tooltip.clientHeight) {
                        topPosition = rect.top + scrollTop - tooltip.clientHeight - 10;
                    }
  
                    // Ensure the tooltip does not go off the top of the screen
                    if (topPosition < scrollTop) {
                        topPosition = scrollTop + 10;
                    }
  
                    // Set the tooltip position
                    tooltip.style.top = topPosition + 'px';
                    tooltip.style.left = left + 'px';
              }
  
              // Function to show tooltip end here
  
            
              window.loadData = function (page, limit) {
                window.event.preventDefault();
                // 0.5 second later
  
                // try {
                //   // if having more data to fetch
                // if (hasMoreData(page, limit, self.total)) {
                  // call the API to get issues
            
                  if(self.options.element=="#version-board"|| self.options.element=="#sprint-board")
                  {
                    createKanbanBoard();
                  }
          
                  else{
                    getIssueData(page, limit);
                  }
               
                // }
                // } catch (error) {
                //   // console.log(error.message);
                // } finally {
                //   // hideLoader();
                // }
              };
           
             var url=window.location.origin
                //var selected__ff=[] ;
                var color
                // $.ajax({
                //   type: "GET",
                //   url:url+`/all_colors.json?key=${api_key}`,
                //   dataType: "json",
                //   async:false,
                //   success: function (result, status, xhr) {
                //     result.forEach((object,i)=>{
                //       if(object.color_value === true)
                //       color = object.color_name
                       
                //     })
                //   }
                // });
  
              // $(document).ready(callscrollFunction);
  
  
              // function callscrollFunction() {
              //   // console.log(  $("#myKanban").height(),"kaban height");
              //   $("#query_form").before(
              //     `<div style="display:none" class="show-error" id='errorExplanation'><ul class="ul-time"><li>No tracker associated with  project please check your project setting</li></ul> </div>`
              //   );
  
              //   $(document).on("scroll", function (e) {
              //     increaseDynamicHeight();
              //      if( ( $(window).scrollTop() + $(window).height() + 1) >= $(document).height() && hasMoreData(self.currentPage, self.limit, self.total)) {
              //       console.log('if condition applied');
              //       increaseDynamicHeight();
              //       // ajax call get data from server and append to the div
              //       self.currentPage++;
              //       loadData(self.currentPage, self.limit);
              //       setTimeout(()=>{
              //         var boardElements = document.querySelectorAll('div.kanban-board');
              //         var allExpanded = Array.from(boardElements).every(function(element) {
              //                 return element.classList.contains('expanded');
              //               });
              //               // If all elements have the class "expanded", add a minimum height to them
              //               if (allExpanded) {
              //                 Array.from(boardElements).forEach(function(element) {
              //                  element.style.minHeight = '64vh'; // Change this value to your desired minimum height
              //                 });
              //               }
              //               else{
              //                 Array.from(boardElements).forEach(function(element) {
              //                   element.style.minHeight = '0px'; // Change this value to your desired minimum height
              //                 });  
              //               }
              //          },500);
              //     }
              //   });
              // }
              const params = window.location.search;
              const parameters = new URLSearchParams(params);
              var project_id = parameters.get("project_id");
  
  
              window.capitalizeFirstLetter = function (letter) {
                return letter.charAt(0).toUpperCase() + letter.slice(1);
  
              }
              this.addElement = function (boardID, element, position) {
                // console.log(position,"postion");
  
                if (typeof position === "undefined") {
                  // console.log("hello")
                  position = -1;
                }
                
                var board = self.element.querySelector(
                  '[data-id="' + boardID + '"] .kanban-drag'
                );
            
                var refElement = board.childNodes[position];
                // console.log(refElement,"resElement");
                var nodeItem = document.createElement("div");
                nodeItem.classList.add("kanban-item-color");
                nodeItem.classList.add("kanban-item" + element.id);
  
    
  
                if (typeof element.id !== "undefined" && element.id !== "") {
                  nodeItem.setAttribute("data-eid", element.id);
                }
                if (element.class && Array.isArray(element.class)) {
                  element.class.forEach(function (cl) {
                    nodeItem.classList.add(cl);
                  });
                }
                //  console.log(nodeItem,"nodeItem");
  
  
                nodeItem.innerHTML = __buildItemCard(element);
          
  
                //add function
                nodeItem.clickfn = element.click;
                nodeItem.contextfn = element.context;
                nodeItem.dragfn = element.drag;
                nodeItem.dragendfn = element.dragend;
                nodeItem.dropfn = element.drop;
  
                __appendCustomProperties(nodeItem, element);
                __onclickHandler(nodeItem);
                __onContextHandler(nodeItem);
                board.insertBefore(nodeItem, refElement);
  
                  
                (function(element) {
                  nodeItem.addEventListener('mouseover', function (event) {
                    // console.log(itemKanban,"item kanbannbbbb");
                    showtooltip(event, element);
  
                    });
                    nodeItem.addEventListener('mouseout', function () {
                      document.getElementById('kanban-tooltip').style.display = 'none';
                    });
                  })(element);
                return self;
              };
      
              this.addForm = function (boardID, formItem) {
                var board = self.element.querySelector(
                  '[data-id="' + boardID + '"] .kanban-drag'
                );
                var _attribute = formItem.getAttribute("class");
                formItem.setAttribute("class", _attribute + " not-draggable");
                board.appendChild(formItem);
               
                return self;
              };
              var currentIssue = null;
              this.addBoards = function (boards, isInit) {
     
                if (self.options.responsivePercentage) {
                  self.container.style.width = "100%";
                  self.options.gutter = "1%";
                  if (window.innerWidth > self.options.responsive) {
                    var boardWidth = (100 - boards.length * 2) / boards.length;
                  } else {
                    var boardWidth = 100 - boards.length * 2;
                  }
                } else {
                  var boardWidth = self.options.widthBoard;
                }
                var addButton = self.options.itemAddOptions.enabled;
                // console.log(addButton,"adButton")
                var buttonContent = self.options.itemAddOptions.content;
                var buttonClass = self.options.itemAddOptions.class;
                var buttonFooter = self.options.itemAddOptions.footer;
                //for on all the boards
  
       
                for (var boardkey in boards) {
                  // single board
                  var board = boards[boardkey];
             
     
                  if (!isInit) {
                    self.options.boards.push(board);
                  }
                      
                   let mainElementId=self.element.getAttribute("id");
                  //create node
                  var boardNode = document.createElement("div");
                  boardNode.dataset.id = board.id;
                  boardNode.dataset.order = self.container.childNodes.length + 1;
                  boardNode.classList.add("kanban-board");
             
                  boardNode.classList.add("board" + boardNode.dataset.id);
                  boardNode.setAttribute("id" ,`column${boardNode.dataset.id}`);
                  //console.log(board.id,'id of boards');
        
                  let initialState = null;
                  if(self.options.element=="#version-board")
                  {
                     initialState = localStorage.getItem(`version-column${boardNode.dataset.id}`);
                  }
                  else if(self.options.element=="#sprint-board")
                  {
                    initialState = localStorage.getItem(`sprint-column${boardNode.dataset.id}`);
                  }
                  else{
                    initialState = localStorage.getItem(`column${boardNode.dataset.id}`);
                  }
                
            
                  if (self.options.responsivePercentage) {
                    boardNode.style.width = boardWidth + "%";
                  } else {
                    boardNode.style.width = boardWidth;
                    // console.log(boardNode,"boardnode");
                  }
                  boardNode.style.marginLeft = self.options.gutter;
                  boardNode.style.marginRight = self.options.gutter;
                  // header board
                  var headerBoard = document.createElement("header");
  
                  if (board.class !== "" && board.class !== undefined)
                    var allClasses = board.class.split(",");
                  else allClasses = [];
                  headerBoard.classList.add("kanban-board-header");
                  allClasses.map(function (value) {
                    // Remove empty spaces
                    return (value = value.replace(/^[ ]+/g, ""));
                    
                  });
                  // console.log(board,"*******")
                  // console.log("this ..");
              
                  //content board 
                  if(project_id){
                    // var wipLimit = project_wip_limit.find(entry => entry.status_id === board.id);
                    var wipLimit = Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id ===  board.id) : null;
                    if(initialState==="collapsed")
                    {
    
                    headerBoard.innerHTML =`<div  class="kanban-title-board ${mainElementId}">
                                             <div style="display:flex;">
                                                <div  data-toggle="tooltip" title=${board.name.split(" ").join("&nbsp;")} class="status-name">${board.name}</div>
                                              </div>
                                             <div  class="counting${board.id} pc-counting">( ${board.issueCount})</div>
                                            </div>
                                           <div  value=${mainElementId} id=${board.id} onclick='hideColumn(event)' class='header-back expanded-header-back'></div>`;
                    }
                    else{
  
                      headerBoard.innerHTML =`<div  class="kanban-title-board ${mainElementId}">
                      <div style="display:flex;">
                         <div  data-toggle="tooltip"  title=${board.name.split(" ").join("&nbsp;")} class="status-name">${board.name}</div>     
                       </div>
                      <div  class="counting${board.id} pc-counting">( ${board.issueCount})</div>
                     </div>
                    <div  value=${mainElementId} id=${board.id} onclick='hideColumn(event)' class='header-back'></div>`;
                    }
  
                  } 
  
                  else {
                    // var wipLimit = global_wip_limit.find(entry => entry.status_id === board.id);
                    var wipLimit = Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === board.id) : null;
                  if(initialState==="collapsed")
                  {
                  headerBoard.innerHTML =`<div  class="kanban-title-board ${mainElementId}">
                                           <div style="display:flex;">
                                              <div data-toggle="tooltip" title=${board.name.split(" ").join("&nbsp;")} class="status-name">${board.name}</div>
                                            </div>
                                           <div  class="counting${board.id} pc-counting">( ${board.issueCount})</div>
                                          </div>
                                         <div  value=${mainElementId} id=${board.id} onclick='hideColumn(event)' class='header-back expanded-header-back'></div>`;
                  }
                  else{
                  
                    headerBoard.innerHTML =`<div  class="kanban-title-board ${mainElementId}">
                    <div style="display:flex;">
                       <div data-toggle="tooltip" title=${board.name.split(" ").join("&nbsp;")} class="status-name">${board.name}</div>     
                     </div>
                    <div  class="counting${board.id} pc-counting">(  ${board.issueCount} )</div>
                   </div>
                  <div  value=${mainElementId} id=${board.id} onclick='hideColumn(event)' class='header-back'></div>`;
                  }
  
                }
                
                  
  
                  var contentBoard = document.createElement("main");
                  var cardDiv = document.createElement("div");
                  cardDiv.setAttribute("board",board.id);
                  cardDiv.classList.add("kanban-content");
               
           
                  contentBoard.classList.add("kanban-drag");
                  contentBoard.setAttribute("board",board.id);
                
                  // contentBoard.appendChild(cardDiv);
                  // contentBoard.classList.add(`card-div${board.id}`);
                  if (board.bodyClass !== "" && board.bodyClass !== undefined)
                  
                    var bodyClasses = board.bodyClass.split(",");
               
                  else bodyClasses = [];
                  bodyClasses.map(function (value) {
                    return contentBoard.classList.add(value);
                  });
  
                  //add drag to array for dragula
                  self.boardContainer.push(contentBoard);
              
  
                  for (var itemkey in board.item) {
                    //create item
                    var itemKanban = board.item[itemkey];
                 
                          
                
                    // Add other properties and classes to nodeItem...
               
                    var nodeItem = document.createElement("div");
                    nodeItem.classList.add("kanban-item-color");
            
                    (function(itemKanban) {
                    nodeItem.addEventListener('mouseover', function (event) {
                      // console.log(itemKanban,"item kanbannbbbb");
                      showtooltip(event, itemKanban);
  
                      });
                      nodeItem.addEventListener('mouseout', function () {
                        document.getElementById('kanban-tooltip').style.display = 'none';
                      });
                    })(itemKanban);
  
                 
                    if (itemKanban.id) {
                      nodeItem.dataset.eid = itemKanban.id;
                      nodeItem.classList.add("kanban-item" + itemKanban.id);
                    }
                    if (itemKanban.class && Array.isArray(itemKanban.class)) {
                      itemKanban.class.forEach(function (cl) {
                        nodeItem.classList.add(cl);
                      });
                    }
                    
                    nodeItem.innerHTML = __buildItemCard(itemKanban);
  
                    //add function
                    nodeItem.clickfn = itemKanban.click;
                    nodeItem.contextfn = itemKanban.context;
                    nodeItem.dragfn = itemKanban.drag;
                    nodeItem.dragendfn = itemKanban.dragend;
                    nodeItem.dropfn = itemKanban.drop;
                    __appendCustomProperties(nodeItem, itemKanban);
                    //add click handler of item
                    __onclickHandler(nodeItem);
                    __onContextHandler(nodeItem);
                    // if (self.options.itemHandleOptions.enabled) {
                    //   nodeItem.style.cursor = 'default'
                    // }
                    // cardDiv.appendChild(nodeItem);
                    contentBoard.appendChild(nodeItem);
                  }
           
              
                  const params = window.location.search;
                  const parameters = new URLSearchParams(params);
                  let value = parameters.get("project_id");
                  // add new input field
                  //footer board
                  // console.log(board,"board id")
                  var footerBoard = document.createElement("footer");
                  footerBoard.setAttribute("class", "footer-form");
                  // if add button is true, add button to the board
                  if (addButton) {
                    // console.log("yes add button...");
                    var formItem = document.createElement("form");
                    formItem.setAttribute("class", "todoForm");
                    var AddCard = document.createElement("input");
                    AddCard.setAttribute(
                      "class",
                      buttonClass
                        ? buttonClass
                        : "kanban-title-button btn btn-default btn-xs"
                    );
                    AddCard.placeholder = "+ ADD NEW ISSUE";
                    AddCard.autocomplete = "off";
                    AddCard.type = "text";
                    AddCard.id = "input-add-card";
                    AddCard.name = "todo_text";
                    formItem.appendChild(AddCard);
                    if (buttonFooter) {
                      footerBoard.appendChild(formItem);
                    } else {
                      headerBoard.appendChild(formItem);
                    }
  
                    __onButtonClickHandler(formItem, board.id);
                  
                  }
                  //board assembly
              // Clear the boardNode
  
                  boardNode.appendChild(headerBoard);
                  if (value) {
                    if(addIssues=="true" && card_creation === "true")
                    {
                    if(self.options.element==="#version-board"||self.options.element==="#sprint-board")
                    {
                    if(boardkey==0)
                    {
                    
                        boardNode.appendChild(footerBoard);
                    }
                  }
          
                  else{
  
                    if(board.name.toLowerCase()==="new")
                    {
                    
                        boardNode.appendChild(footerBoard);
                    }
                  }
               
                    }
                   
                  }
                  if(initialState==="collapsed")
                  {
  
          
                  
                    boardNode.classList.add("expanded");
                    contentBoard.classList.add("hidden");
                    footerBoard.classList.add("hidden");
                    // footerBoard.style.display="none";
                  }
                  else{
                    boardNode.classList.remove("expanded");
                  }
                  //board add
                  boardNode.appendChild(contentBoard);
                  self.container.appendChild(boardNode);
           
                }
                //  console.log(self,"self>>>>>>>>>>>");
                return self;
              };
              // setTimeout(()=>{
              //   var boardElements = document.querySelectorAll('div.kanban-board');
              //   var allExpanded = Array.from(boardElements).every(function(element) {
              //           return element.classList.contains('expanded');
              //         });
              //         // If all elements have the class "expanded", add a minimum height to them
              //         if (allExpanded) {
              //           Array.from(boardElements).forEach(function(element) {
              //            element.style.minHeight = '79vh'; // Change this value to your desired minimum height
                
              //           });
                 
              //         }
              //         else{
              //           Array.from(boardElements).forEach(function(element) {
              //             element.style.minHeight = '0px'; // Change this value to your desired minimum height
  
              //           });  
                       
              //         }
              //    },500);
  
              this.findBoard = function (id) {
                var el = self.element.querySelector('[data-id="' + id + '"]');
                return el;
              };
  
              this.getParentBoardID = function (el) {
                if (typeof el === "string") {
                  el = self.element.querySelector('[data-eid="' + el + '"]');
                }
                if (el === null) {
                  return null;
                }
                return el.parentNode.parentNode.dataset.id;
              };
  
              this.moveElement = function (targetBoardID, elementID, element) {
                if (targetBoardID === this.getParentBoardID(elementID)) {
                  return;
                }
  
                this.removeElement(elementID);
                return this.addElement(targetBoardID, element);
              };
  
              this.replaceElement = function (el, element) {
                var nodeItem = el;
                if (typeof nodeItem === "string") {
                  nodeItem = self.element.querySelector(
                    '[data-eid="' + el + '"]'
                  );
                }
                nodeItem.innerHTML = __buildItemCard(element);
                // add function
                nodeItem.clickfn = element.click;
                nodeItem.contextfn = element.context;
                nodeItem.dragfn = element.drag;
                nodeItem.dragendfn = element.dragend;
                nodeItem.dropfn = element.drop;
                __appendCustomProperties(nodeItem, element);
                __onclickHandler(nodeItem);
                __onContextHandler(nodeItem);
                return self;
              };
  
  
  
              this.findElement = function (id) {
                var el = self.element.querySelector('[data-eid="' + id + '"]');
                return el;
              };
  
              this.getBoardElements = function (id) {
                var board = self.element.querySelector(
                  '[data-id="' + id + '"] .kanban-drag'
                );
                return board.childNodes;
              };
  
              this.removeElement = function (el) {
                el = self.element.querySelector('[data-eid="' + el + '"]');
                if (el != null) {
                  //fallback for IE
                  if (typeof el.remove == "function") {
                    el.remove();
                  } else {
                    el.parentNode.removeChild(el);
                  }
                }
                return self;
              };
  
              this.removeBoard = function (board) {
                var boardElement = null;
                if (typeof board === "string")
                  boardElement = self.element.querySelector(
                    '[data-id="' + board + '"]'
                  );
                if (boardElement !== null) {
                  //fallback for IE
                  if (typeof boardElement.remove == "function") {
                    boardElement.remove();
                  } else {
                    boardElement.parentNode.removeChild(boardElement);
                  }
                }
  
                // remove thboard in options.boards
                for (var i = 0; i < self.options.boards.length; i++) {
                  if (self.options.boards[i].id === board) {
                    self.options.boards.splice(i, 1);
                    break;
                  }
                }
  
                return self;
              };
  
              // board button on click function
              this.onButtonClick = function (el) { };
  
              //PRIVATE FUNCTION
              function __extendDefaults(source, properties) {
                var property;
                for (property in properties) {
                  if (properties.hasOwnProperty(property)) {
                    source[property] = properties[property];
                  }
                }
                return source;
              }
  
              function __setBoard() {
                self.element = document.querySelector(self.options.element);
                //create container
             
                var boardContainer = document.createElement("div");
                boardContainer.classList.add("kanban-container");
           
                self.container = boardContainer;
                //add boards
  
                if (
                  document
                    .querySelector(self.options.element)
                    .dataset.hasOwnProperty("board")
                ) {
                  url = document.querySelector(self.options.element).dataset
                    .board;
                  window
                    .fetch(url, {
                      method: "GET",
                      headers: { "Content-Type": "application/json" },
                    })
                    .then(function (response) {
                      // log response text
                      response.json().then(function (data) {
                        self.options.boards = data;
                        self.addBoards(self.options.boards, true);
                      });
                    })
                    .catch(function (error) {
                      // console.log('Error: ', error)
                    });
                } else {
                  self.addBoards(self.options.boards, true);
                }
                //appends to container
                self.element.appendChild(self.container);
              }
  
              function __onclickHandler(nodeItem, clickfn) {
                  // console.log(nodeItem,"nodeITem")
                nodeItem.addEventListener("click", function (e) {
                  // console.log(e,"e")
                  if (!self.options.propagationHandlers.includes("click"))
                    // e.preventDefault()
                    var cardId=nodeItem.getAttribute("data-eid");
                    if(e.target.parentElement.id!=="restrict-popup")
                    {
                      openPopup(cardId);
                    }
                  
                    self.options.click(this);
                  if (typeof this.clickfn === "function") this.clickfn(this);
                });
              }
  
              function __onContextHandler(nodeItem, contextfn) {
                if (nodeItem.addEventListener) {
                  nodeItem.addEventListener(
                    "contextmenu",
                    function (e) {
                      if (!self.options.propagationHandlers.includes("context"))
                        e.preventDefault();
                      self.options.context(this, e);
                      if (typeof this.contextfn === "function")
                        this.contextfn(this, e);
                    },
                    false
                  );
                } else {
                  nodeItem.attachEvent("oncontextmenu", function () {
                    self.options.context(this);
                    if (typeof this.contextfn === "function")
                      this.contextfn(this);
                    if (!self.options.propagationHandlers.includes("context"))
                      window.event.returnValue = false;
                  });
                }
              }
  
              window.getIssueAPI = function () {
                $.ajax({
                  type: "GET",
                  url: url + "/issue_statuses.json?key=" + api_key + " ",
                  dataType: "json",
                  success: function (response, status, xhr) {
                    const params = window.location.search;
                    const parameters = new URLSearchParams(params);
                    const project_id = parameters.get("project_id");
                    $.ajax({
                      type: "GET",
                      url: project_id
                        ? url +
                        `/projects/${project_id}/issues.json?key=${api_key}`
                        : url + `/issues.json?key=${api_key}`,
                      dataType: "json",
                      success: function (res, status, xhr) {
                
                        response.issue_statuses.forEach((object) => {
                          object.item = [];
                        });
                        res.issues.forEach((object) => {
                          response.issue_statuses.forEach((option) => {
                            if (object.status.name == option.name) {
                              option.item.push(object);
                            }
                          });
                        });
                        const array_item = [];
                        response.issue_statuses.forEach((object) => {
                          array_item.push("" + object.id);
                        });
                        response.issue_statuses.forEach((object) => {
                          object.id = "" + object.id;
                          object.dragTo = array_item;
                          object.issueCount = object.item.length;
  
                        });
                        // -----
                        issue_bords_ids = self.options.boards ;  //boards id
                        issue_counting = self.boardContainer ;    //issue updated values
                        
                        var issue_update_value = [];
                        var issue_bords_update = [];
                        
                        
                        // console.log(issue_bords_update,'isssue boards update');
                        
                        issue_bords_ids.forEach((object,i)=>{
                        issue_bords_update.push(object.id);
                        });
                        
                        issue_counting.forEach((object,i)=>{
                        issue_update_value.push(object.childElementCount);
                        // console.log(object.childElementCount,'child countingg')
                        });
     
                        
                        // -------------
                        // for (let i = 0; i < issue_bords_update.length; i++) {
                        // $('.counting' + issue_bords_update[i]).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                        // }
  
  
  
                        if(project_id){
                          for (let i = 0; i < issue_bords_update.length; i++) {
                            let currentStatusId = issue_bords_update[i];
                            // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                            // let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                          
                            // let wipLimitHtml = '';
                            // if (currentWipLimit) {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                            // } else {
                            //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                            // }
                            let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                          
                            $('.counting' + currentStatusId).html(wipLimitHtml);
                          }
  
                        } else {
                        for (let i = 0; i < issue_bords_update.length; i++) {
                          let currentStatusId = issue_bords_update[i];
                          // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                        //   let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                        
                        //   let wipLimitHtml = '';
                        //   if (currentWipLimit) {
                        //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                        //   } else {
                        //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                        //   }
                        let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                        
                          $('.counting' + currentStatusId).html(wipLimitHtml);
                        }
                      }
                        //  updateKanbanContainerStatus();
  
                        // setTimeout(() => {
                        //   updateWipLimits();
                        //   }, 1000);
                        if(self.options.element==="#myKanban")
                        {
                          setTimeout(() => {
                            updateKanbanContainerStatus();
                            }, 500); 
                        }
                  
                        // setTimeout(() => {
                        //   updateWipLimits();
                        //   }, 1000);
                        
                        //   setTimeout(() => {
                        //     updateKanbanContainerStatus();
                        //     }, 500);  
         
                      },
                    });
                  },
                  error: function (xhr, status, error) {
                    //  console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
              window.getVariableValue = function (
                project_id,
                boardId,
                text,
                value
              ) {
                return (content = {
                  project_id: project_id,
                  tracker_id: 1,
                  priority_id: 6,
                  status_id: parseInt(boardId),
                  subject: text,
                  custom_fields: value,
                });
              };
              function getTrackers(project_id) {
                var tracker_id = " ";
                $.ajax({
                  type: "GET",
                  url: `${self.url}/projects/${project_id}.json?key=${api_key}&&include=trackers`,
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    if (result.project.trackers.length != 0) {
                      tracker_id = result.project.trackers[0].id;
                    }
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
                return tracker_id;
              }
              function getPriority() {
                var priority_id = " ";
                $.ajax({
                  type: "GET",
                  url:
                    self.url +
                    "/enumerations/issue_priorities.json?key=" +
                    api_key +
                    " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    priority_id = result.issue_priorities[0].id;
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
  
                return priority_id;
              }
              function getStatus(){
                let status_id = " ";
                $.ajax({
                  type: "GET",
                  url:`${self.url}/issue_statuses.json?key=${api_key}`,
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    let openStatuses = result.issue_statuses.filter(function (status) {
                      return !status.is_closed;
                    });
                    status_id = openStatuses[0].id;
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
                 
                return status_id;
              }
              function __onButtonClickHandler(nodeItem, boardId) {
                nodeItem.addEventListener("submit", function (e) {
                  e.preventDefault();
                  var text = e.target[0].value;
                  const params = window.location.search;
                  const parameters = new URLSearchParams(params);
                  const project_id = parameters.get("project_id");
                  if (parameters.get("sprint_craft") != null) {
                  var sprint_id = parameters.get("sprint_craft");
                  }
                  var tracker_id = getTrackers(project_id);
                  var priority_id = getPriority();
                  let status_id =parseInt(boardId);
                  if(self.options.element=="#version-board"||self.options.element=="#sprint-board")
                  {
                    status_id = getStatus();
                  }
              
         
                  var content = {
                    project_id: project_id,
                    tracker_id: tracker_id,
                    priority_id: priority_id,
                    status_id: status_id,
                    subject: text,
                  }
                  if (parameters.get("sprint_craft") != null) {
                    content.sprint_craft = sprint_id;
                  }
                  // console.log(self.options.element,"elementn");
                  if(self.options.element=="#version-board")
                  {
                    content.fixed_version_id=" ";
                  }
                  if(self.options.element=="#sprint-board")
                  {
                    content.sprint_craft=" ";
                  }
                  $.ajax({
                    type: "POST",
                    url: self.url + "/issues.json?key=" + api_key + " ",
                    contentType: "application/json",
                    dataType: "json",
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      getIssueAPI();
                      var today = new Date();
                      var dd = String(today.getDate()).padStart(2, "0");
                      var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
                      var yyyy = today.getFullYear();
                      today = mm + "-" + dd + "-" + yyyy;
                   
                      self.addElement(boardId, {
                        created_on: result.issue.created_on,
                        updated_on: result.issue.updated_on,
                        estimated_hours: result.issue.estimated_hours,
                        total_spent_hours: result.issue.total_spent_hours,
                        description: result.issue.description
                          ? result.issue.description
                          : "No data",
                          ...(result.issue.hasOwnProperty("category")) ? {
                            category: {
                                id: result.issue.category && result.issue.category.id,
                                name: result.issue.category && result.issue.category.name,
                            }
                        } : {},
                        ...(result.issue.hasOwnProperty("fixed_version")) ? {
                          fixed_version:{
                            id: result.issue.fixed_version&&result.issue.fixed_version.id,
                            name: result.issue.fixed_version&&result.issue.fixed_version.name,
                          }}:{},
                          ...(result.issue.hasOwnProperty("parent")) ? {
                            parent:{
                            id:  result.issue.parent&&result.issue.parent.id,
                          }}:{},
                        subject: text,
                        id: result.issue.id,
                        done_ratio: result.issue.done_ratio
                          ? result.issue.done_ratio
                          : "No data",
                        project: {
                          id: result.issue.project.id,
                          name: result.issue.project.name,
                        },
                        assigned_to: {
                          id: result.issue.assigned_to
                            ? result.issue.assigned_to.id
                            : "Anonymous",
                          name: result.issue.assigned_to
                            ? result.issue.assigned_to.name
                            : "Anonymous",
                        },
                        status :{
                          id: result.issue.status.id,
                          name: result.issue.status.name,
                        },
                        author:{
                          id: result.issue.author.id,
                          name: result.issue.author.name,
                        },
  
                        tracker: {
                          id: result.issue.tracker.id,
                          name: result.issue.tracker.name,
                        },
                        priority: {
                          id: result.issue.priority.id,
                          name: result.issue.priority.name,
                        },
                        start_date: today,
                        due_date: result.issue.due_date,
                        
                      }, "0");
                      // console.log("issue is created in particular project");
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
      
                  this.reset();
                });
              }
  
              function __findBoardJSON(id) {
                var el = [];
                self.options.boards.map(function (board) {
                  if (board.id == id) {
                    return el.push(board);
                  }
                  
                });
                return el[0];
                
              }
             
              function __appendCustomProperties(element, parentObject) {
  
                for (var propertyName in parentObject) {
                  if (self._disallowedItemProperties.indexOf(propertyName) > -1) {
                    continue;
                  }
                  if (typeof parentObject[propertyName] === "string") {
                    element.setAttribute(
                      "data-" + propertyName,
                      parentObject[propertyName]
                    );
                  }
                  else {
                    for (var key in parentObject[propertyName]) {
                      element.setAttribute(
                        "data-" + propertyName,
                        parentObject[propertyName]["id"]
                      );
                    }
                  }
                }
              }
  
              function __updateBoardsOrder() {
                var index = 1;
                for (var i = 0; i < self.container.childNodes.length; i++) {
                  self.container.childNodes[i].dataset.order = index++;
                }
              }
  
              window.closeSubject=function(id)
              {
                 window.event.preventDefault();
                 setTimeout(()=>{
                  $("#error-div-subject").css("display","none");
                  let inputSubject=document.getElementById(`subj-parent${id}`);
                  let divSubject=document.getElementById(`subjectDiv${id}`);
                  inputSubject.style.display="none";
                  divSubject.style.display="flex";
                },100)
      
              }
  
              function validateData(value){
                  let errors={};
                  if(value.length==0)
                  {
                      $("#error-div-subject").css("display","flex");
                      $("#error-subject").html("Subject can not be blank*");
                      errors.subject="This field is required*";
                  }
                  else if(value.length > 255)
                  {
                    $("#error-div-subject").css("display","flex");
                    $("#error-subject").html("Only 255 characters allowed");
                    errors.subject="Only 255 characters allowed";
                  }
                  else
                   {
                    $("#error-div-subject").css("display","none");
                   }
             
                  if(Object.keys(errors).length)
                  {
                    return count=false;
                  }
                  else{
                    return count=true;
                  }
              }
                
              window.handleSubmit = function (id) {
                // console.log("yess");
                window.event.preventDefault();
                // if (window.event.keyCode == 13) {
                $(".show-error" + id).css("display", "none");
                let elem = document.getElementById("input-field" + id);
                 if(validateData(elem.value))
                 {
               
                  var content = {
                    subject: elem.value,
                  };
  
                  $.ajax({
                    type: "PUT",
                    url:
                      self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    async: false,
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      $("#error-div-subject").css("display","none");
                      $("#strong" + id).html(elem.value);
                      $(`#sub${id}`).html(elem.value);
                      // console.log( $("#issue_subject"),"issue ka subject")
                      // $("#issue_subject").html(elem.value);
                      $(".show-error" + id).css("display", "none");
                  
                      let div=document.getElementById(`subjectDiv${id}`);
                      div.innerHTML=elem.value;
                      setTimeout(()=>{
                        let inputSubject=document.getElementById(`subj-parent${id}`);
                        let divSubject=document.getElementById(`subjectDiv${id}`);
                        inputSubject.style.display="none";
                        divSubject.style.display="flex";
                        $("#subjectDiv"+id).attr("value",elem.value);
                      },100);
              
          
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;
                        toastr["error"](content);
                      } else {
                      }
                    },
                  });
                }
             
              // }
              };
              window.handleClose = function (id) {
                window.event.preventDefault();
                var card_elem = document.getElementById("subject" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("span-tag" + id);
                input.style.display = "none";
              };
  
              window.updateIssue = function (id) {
                let card_elem = document.getElementById("subject" + id);
                card_elem.style.display = "none";
                var span_div = document.getElementById("span-tag" + id);
                span_div.style.display = "block";
              };
  
              window.updateIssueP = function (id, priority_id) {
                var priority = document.getElementById("priority" + id);
                priority.style.display = "none";
                var div = document.getElementById("priority-tag" + id);
                div.style.display = "block";
                let select = document.getElementsByClassName(
                  "select-priority" + id
                );
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url:
                      self.url +
                      "/enumerations/issue_priorities.json?key=" +
                      api_key +
                      " ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      if (result.issue_priorities.length != 0) {
                        result.issue_priorities.forEach((p) => {
                          if (p.id == priority_id) {
                            $(".select-priority" + id).append(
                              `<option  selected value=${p.id}>${p.name}</option>`
                            );
  
                          } else {
                            $(".select-priority" + id).append(
                              `<option value=${p.id}>${p.name}</option>`
                            );
                          }
                        });
                      }
  
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              };
  
              window.handleSubmitP = function (id) {
                window.event.preventDefault();
                let priority_id = changePriority(id);
                let priority_name = getPriorityName(id);
  
                var content = {
                  priority_id: parseInt(priority_id),
                };
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
  
                    let select_elem = document.getElementById("prioritySelect" + id);
                    select_elem.style.display = "none";
                    select_elem.style.width = "250px";
                    let hide_elem = document.getElementById("hide-priority" + id);
                    hide_elem.style.display = "flex";
                    $(`.priority-name${id}`).html(priority_name);
                    $(`#agilePriority${id}`)[0].setAttribute("data-priority",priority_name.toLowerCase());
         
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
              window.handleCloseP = function (id) {
                window.event.preventDefault();
                var card_elem = document.getElementById("priority" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("priority-tag" + id);
                input.style.display = "none";
              };
              window.updateStartDate = function (id) {
                var date = document.getElementById("StartDate" + id);
                date.style.display = "none";
                var div = document.getElementById("date-tag" + id);
                div.style.display = "block";
                if (date.innerHTML == null) {
                  $("#start-date" + id).val(" ");
                } else {
                  var dt = date.innerHTML.split("-");
                  var date1 = dt[2] + "-" + dt[1] + "-" + dt[0];
                  $("#start-date" + id).val(date1);
                }
              };
              window.updateDueDate = function (id) {
                var date = document.getElementById("Duedate" + id);
                date.style.display = "none";
                var div = document.getElementById("Duedate-tag" + id);
                div.style.display = "block";
                if (date.innerHTML == null) {
                  $("#due-date" + id).val(" ");
                } else {
                  var dt = date.innerHTML.split("-");
                  var date1 = dt[2] + "-" + dt[1] + "-" + dt[0];
                  $("#due-date" + id).val(date1);
  
                }
              };
        
              window.finalsubmit = function (id) {
                window.event.preventDefault();
                $(".show-error" + id).css("display", "none");
        
                let start_date = $("#start-dates" + id).val();
                var change_date = changedateFormat(start_date);
                if (validateStartDate(start_date,id)) {
                if (start_date.length != 0) {
                  var content = {
                    start_date: start_date,
                  };
                  $.ajax({
                    type: "PUT",
                    url:
                      self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      var card_elem = document.getElementById("issue_data_" + id);
                      card_elem.style.display = "block";
                      var input = document.getElementById("editable_date_" + id);
                      input.style.display = "none";
                      $(".show-error" + id).css("display", "none");
                      $(".startDate" + id).html(change_date);
                      $("#Startdate" + id).html(change_date);
                      $("#issue_data_" + id).html(change_date);
                      $("#issue_data_" + id).attr("value",start_date);
                    },
  
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        $(".show-error" + id).css("display", "none");
                        let content = JSON.parse(xhr.responseText).errors;
                        toastr["error"](content);
                      } else {
                        // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                      }
                    },
                  });
                }
              }
              };
              function validateStartDate(value,id)
              {
               
                const errors = {};
                 if(($("#due-dates"+id).val().length!=0&&$("#due-dates"+id).val())<value&&value.length!=0)
                 {
                   $("#error-start"+id).css("display","flex");
                   $(".error-startDate"+id).html("Start date must be less than Due date");
                   errors.duedate="Start date must be less than Due date";
                 }
                 else{
                  $("#error-start"+id).css("display","none");
                 }
                 
                 if (Object.keys(errors).length) {
                   return false;
                 } else {
                   return true;
                 }
              }
              function validateDueDate(value,id)
               {
                
                 const errors = {};
        
                 if(($("#start-dates"+id).val().length!=0&&$("#start-dates"+id).val())>value&&value.length!=0)
                 {
                   $("#error-due"+id).css("display","flex");
                   $(".error-dueDate"+id).html("Due date must be greater than start date");
                   errors.duedate="Due date must be greater than start date";
                 }
                 else{
                  $("#error-due"+id).css("display","none");
                 }
                 
                 if (Object.keys(errors).length) {
                   return false;
                 } else {
                   return true;
                 }
   
               }
              window.finalsubmitDueDate=function(id)
              {
              
                window.event.preventDefault();
                let due_date = $("#due-dates" + id).val();
                var change_date = changedateFormat(due_date);
                
                if (validateDueDate(due_date,id)) {
                  if (due_date.length != 0) 
                  {
                  var content = {
                  due_date: due_date,
                  };
                  $.ajax({
                    type: "PUT",
                    url:
                      self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      var card_elem = document.getElementById("issue_data_due_" + id);
                      card_elem.style.display = "block";
                      var input = document.getElementById("editable_duedate_" + id);
                      input.style.display = "none";
                      $(".show-error" + id).css("display", "none");
                      $(".startDate" + id).html(change_date);
                      $("#Duedate" + id).html(change_date);
                      $("#issue_data_due_" + id).html(change_date); 
                      $("#issue_data_due_"+id).attr("value",due_date);
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        $(".show-error" + id).css("display", "none");
                        let content = JSON.parse(xhr.responseText).errors;
                        toastr["error"](content);
                      } else {
                        // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                      }
                    },
                  });
                }
                }
              }
              window.handleSubmitDueDate = function (id) {
                window.event.preventDefault();
                $(".show-error" + id).css("display", "none");
                // console.log(".show-error" + id);
                var card_elem = document.getElementById("Duedate" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("Duedate-tag" + id);
                input.style.display = "none";
                let due_date = $("#due-date" + id).val();
                var change_due_date = changedateFormat(due_date);
                if (due_date.length != 0) {
                  var content = {
                    due_date: due_date,
                  };
                  $.ajax({
                    type: "PUT",
                    url:
                      self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      $(".show-error" + id).css("display", "none");
                      $(".startDate" + id).html(change_due_date);
                      $("#Duedate" + id).html(change_due_date);
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        $(".show-error" + id).css("display", "none");
                        toastr.options = {
                          closeButton: true,
                          debug: false,
                          newestOnTop: false,
                          progressBar: true,
                          positionClass: "toast-top-right",
                          preventDuplicates: false,
                          onclick: null,
                          showDuration: "300",
                          hideDuration: "1000",
                          timeOut: "2000",
                          extendedTimeOut: "1000",
                          showEasing: "swing",
                          hideEasing: "linear",
                          showMethod: "fadeIn",
                          hideMethod: "fadeOut",
                        };
  
                        let content = JSON.parse(xhr.responseText).errors;
                        // console.log(content);
                        toastr["error"](content);
                        // $("#query_form").before(`<div class="show-error${id}" id='errorExplanation'><ul class="ul-time"></ul> </div>`);
                        // content.forEach(p=>{
                        //   $(".ul-time").append(`<li>${p}</li>`);
                        //   console.log(p)
                        // })
                      } else {
                        // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                      }
                    },
                  });
                }
              };
              window.handleCloseDate = function (id) {
              
                window.event.preventDefault();
                let start_date;
                var card_elem = document.getElementById("issue_data_" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("editable_date_" + id);
                input.style.display = "none";
                let errorDiv=document.getElementById("error-start"+id);
                if(errorDiv)
                errorDiv.style.display="none";
                // // $("#start-dates"+id).val("");
                $("#start-dates"+id).val(" ");
                $(".show-error").css("display", "none");
            
                 let Issue=getissueDetail(id);
                 if(Issue.start_date!=null)
                 {
                  start_date = Issue.start_date;
                 }
             
           
                $("#start-dates"+id).val(start_date);
              };
              // close function on click of due date cross
              window.handleCloseDueDate=function(id)
              {
                let due_date;
                window.event.preventDefault();
                let card_elem = document.getElementById("issue_data_due_" + id);
                let input = document.getElementById("editable_duedate_" + id);
                card_elem.style.display = "block";
                input.style.display = "none";
          
                let errorDiv=document.getElementById("error-due"+id);
                if(errorDiv)
                errorDiv.style.display="none";
                $("#due-dates"+id).val(" ");
                $(".show-error").css("display", "none");
                let Issue=getissueDetail(id);
                if(Issue.due_date!=null){
                  due_date = Issue.due_date;
                }
                $("#due-dates"+id).val(due_date)
              
              }
         
              window.closePopup = function (id) {
        
                window.event.preventDefault();
                $(".input-hour" + id).val(" ");
                $("#context-kanban" + id).css("display", "none");
                let back_div = document.getElementById("blur-div" + id);
                back_div.style.display = "none";
  
                // -----------
                $("#error-div-desc" + id).css("display", "none");
                // $("#desc-field"+id).val('');
                let text_elem = document.getElementById("textbox-div" + id);
                text_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-div" + id);
                hide_elem.style.display = "flex";
                // -------------
                if ($('.context-menu-popup').is(':visible')) {
                  $(":tabbable").attr("tabindex", -1);
                  $(".context-menu-popup [tabindex='-1']").attr("tabindex", 0);
                  
                } else {
                  $("[tabindex='-1']").attr("tabindex", 0);
                  $("html").css("overflow", "auto");
                }
                location.reload();
                // $('#new-attachments').hide();
                $('.new_attachment_' + id).css('display', 'none');
                $('#relation_form_container').hide();
  
              };
  
              function underline_convet(html) {
                if (!html.includes("<u>")) return html;
              
                // convert HTML striket words to Textile
                let textile = html.replace(/<u>/g, "<ins>").replace(/<\/u>/g, "</ins>");
                return textile;
              }
  
              window.saveDescription = function (id) {
                window.event.preventDefault();
                $(".scroll-card").removeClass("overflow-auto");
                // let elem=document.getElementById("desc-field"+id);
  
                var value = quill.root.innerHTML;
                var value_2 = underline_convet(value);
                //var d_value=value.replace( /(<([^>]+)>)/ig, '');
                var value_converted = toTextile(value_2);
  
  
                if (
                  typeof value === "string" &&
                  value.replace(/<(.|\n)*?>/g, "").trim().length === 0
                ) {
                  $("#error-div-desc" + id).css("display", "flex");
                  $("#error-text-desc" + id).html(
                    "Description can not be blank*"
                  );
                } else {
                  if (value.length > 1000) {
                    $(".scroll-card").addClass("overflow-auto");
                  } else {
                    $(".scroll-card").removeClass("overflow-auto");
                  }
                  var content = {
                    description: value_converted,
                  };
                  $.ajax({
                    // type: "POST",
                    type: "PUT",
                    url:
                      self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content,
                    }),
                    success: function (result, status, xhr) {
                      let text_elem = document.getElementById("textbox-div" + id);
                      text_elem.style.display = "none";
                      let hide_elem = document.getElementById("hide-div" + id);
                      hide_elem.style.display = "flex";
                      $("#show-desc" + id).html(value);
                      $("#error-div-desc" + id).css("display", "none");
                      // console.log(value, "value");
                      $("#setting-d" + id).html(value);
                      // elem.value=" ";
                      // $("#desc-field"+id).val('');
                    },
  
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              };
              window.closeWatcherDelete = function (id, user_id, user_name) {
                window.event.preventDefault();
                let remove_div = document.getElementById("remove-watcher" + id + "-" + user_id);
                remove_div.style.display = "none";
                $("#remove-watcher-backdrop" + id + "-" + user_id).css("display", "none");
                $('.context-menu-popup').css('z-index','9999');
                disableTabindex(".delete-watcher");
                disableTabindex(".context-menu-popup");
              };
  
              window.deleteWatcher=function(id, user_id, user_name){
                
                let object={
                  id:user_id,
                  name:user_name
                }
                $.ajax({
                  type: "DELETE",
                  url:`${self.url}/issues/${id}/watchers/${user_id}.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    const divToRemove = document.getElementById("watcher"+user_id);
                    $("#remove-watcher" + id + "-" + user_id).remove();
                    $("#remove-watcher-backdrop" + id + "-" + user_id).remove();
                    $('.context-menu-popup').css('z-index','9999');
                    disableTabindex(".delete-watcher");
                    disableTabindex(".context-menu-popup");
                    watcher_array =  watcher_array.filter(function(obj) {
                    return obj.id !== user_id; // Keep objects with a different ID
                    
                  });
                    if (divToRemove) {
                      divToRemove.remove();
                    }
                    toastr["success"]("Watcher removerd successfully");
                  },
                  error:function(error)
                  {
                    toastr["error"]("You don't have permission");
                  }
                })
               }
  
  
              window.openWatcherDelete = function (id, user_id, user_name) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let remove_div = document.getElementById(
                  "remove-watcher-backdrop" + id + "-" + user_id
                );
                let open_div = document.getElementById("remove-watcher" + id + "-" + user_id);
                if (remove_div) {
                  remove_div.style.display = "block";
                  open_div.style.display = "block";
                } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                //   let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                  let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                  if(self.options.element==="#version-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                  }
                  else if(self.options.element === "#sprint-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                  }
                  
                  let div = document.createElement("div");
                  div.className = "delete-watcher-backdrop";
                  div.id = "remove-watcher-backdrop" + id + "-" + user_id;
                  div.style.display = "block";
                  body_div[0].appendChild(div);
                  var context_menu = document.createElement("div" + id);
                  context_menu.className = "delete-watcher";
                  context_menu.id = "remove-watcher" + id + "-" + user_id;
                  context_menu.innerHTML = `
         <div>
         <h4  style="color:black; font-size:20px !important;  border-bottom:none; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important;" >Remove Watcher</h4>
         <p style="color:black; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important; font-size:inherit;"> You're about to remove this watcher <b>${user_name}</b>,
         If you're not sure, you can close this instead.</p>
         <div style="display:flex; justify-content:center; margin-top:26px;  cursor:pointer;" >
         <div style="display:flex; justify-content:space-between; cursor:pointer">
         <div  onclick="closeWatcherDelete(${id}, ${user_id}, '${user_name}')"  type="button" " style="display:flex; margin-right:15px;   cursor:pointer">
         <button style="cursor:pointer" class="button-close">Cancel
          </button>
          </div>
         <div  onclick="deleteWatcher(${id}, ${user_id}, '${user_name}')" style="display:flex;  cursor:pointer" >
         <button   style="cursor:pointer" class="button-save">Remove</button>
         </div>
  
      
        </div>
        </div>
         </div>`;
                  body_div[0].appendChild(context_menu);
                }
                disableTabindex(".delete-watcher");
              };
  
              window.deleteAttachment = function (issue_id , attachmentId){
                $.ajax({
                  type: "DELETE",
                  url: self.url + "/attachments/" + attachmentId + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    $('#attachments_' + attachmentId ).remove();
                    let ulElement = $('.attachment_ul'); 
                    if (ulElement.children().length === 0) {
                        ulElement.css('display', 'none');  
                    }
                    let removeDiv = document.getElementById("remove-attachment-dialog" + attachmentId);
                    removeDiv.style.display = "none";
                    $("#remove-attachment_dialog-backdrop" + attachmentId).css("display", "none");
                    $(".context-menu-popup").css("z-index", "9999");
                    disableTabindex(".delete-dialog");
                    disableTabindex(".context-menu-popup");
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
  
              }
  
              window.closeDialogDeleteAttachment = function (issue_id , attachmentId){
                window.event.preventDefault();
                let removeDiv = document.getElementById("remove-attachment-dialog" + attachmentId);
                removeDiv.style.display = "none";
                $("#remove-attachment_dialog-backdrop" + attachmentId).css("display", "none");
                $(".context-menu-popup").css("z-index", "9999");
                disableTabindex(".delete-dialog");
                disableTabindex(".context-menu-popup");
              }
  
              window.openDialogDeleteAttachment = function (issue_id , attachmentId) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let removeDiv = document.getElementById("remove-attachment_dialog-backdrop" + attachmentId);
                let openDiv = document.getElementById("remove-attachment-dialog" + attachmentId);
                
                if (removeDiv) {
                    removeDiv.style.display = "block";
                    openDiv.style.display = "block";
                } 
                else {
                    $(".context-menu-popup").css("zIndex", "1040");
                    let bodyDiv;
                    if (self.options.element === "#version-board") {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile_versions action-index");
                        console.log("not open");
                    } 
                    else if (self.options.element === "#sprint-board") {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile_versions action-sprints");
                        console.log("open");
                    } 
                    else {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile action-index");
                    }
  
  
                    let div = document.createElement("div");
                    div.className = "delete-dialog-backdrop";
                    div.id = "remove-attachment_dialog-backdrop" + attachmentId;
                    div.style.display = "block";
                    bodyDiv[0].appendChild(div);
            
                    var contextMenu = document.createElement("div");
                    contextMenu.className = "delete-dialog";
                    contextMenu.id = "remove-attachment-dialog" + attachmentId;
                    contextMenu.innerHTML = `
                        <div>
                            <h4 style="color:black; font-size:20px !important; border-bottom:none; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important;" >
                                Delete Attachment
                            </h4>
                            <p style="color:black; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important; font-size:inherit;">
                                You're about to permanently delete this attachment. Are you sure you want to proceed?
                            </p>
                            <div style="display:flex; justify-content:center; margin-top:26px; cursor:pointer;" >
                                <div style="display:flex; justify-content:space-between; cursor:pointer">
                                    <div onclick="closeDialogDeleteAttachment(${issue_id} , ${attachmentId} )" type="button" style="display:flex; margin-right:15px; cursor:pointer">
                                        <button style="cursor:pointer" class="button-close">Cancel</button>
                                    </div>
                                    <div onclick="deleteAttachment(${issue_id} , ${attachmentId} )" style="display:flex; cursor:pointer" >
                                        <button style="cursor:pointer" class="button-save">Delete</button>
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    bodyDiv[0].appendChild(contextMenu);
                }
                disableTabindex(".delete-dialog");
                disableTabindex(".context-menu-popup");
            };
  
            window.delete_relation  = function (relationId , id) {
              window.event.preventDefault();
              $(".context-menu-popup").css("zIndex", "1040");
              let removeDiv = document.getElementById("remove-relation-dialog-backdrop" + relationId);
              let openDiv = document.getElementById("remove-relation-dialog" + relationId);
              
              if (removeDiv) {
                  removeDiv.style.display = "block";
                  openDiv.style.display = "block";
              } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                  let bodyDiv;
                    if (self.options.element === "#version-board") {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile_versions action-index");
                        console.log("not open");
                    } 
                    else if (self.options.element === "#sprint-board") {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile_versions action-sprints");
                        console.log("works");
                    } 
                    else {
                        bodyDiv = document.getElementsByClassName("has-main-menu controller-agile action-index");
                    }
          
                  let div = document.createElement("div");
                  div.className = "delete-dialog-backdrop";
                  div.id = "remove-relation-dialog-backdrop" + relationId;
                  div.style.display = "block";
                  bodyDiv[0].appendChild(div);
          
                  var contextMenu = document.createElement("div");
                  contextMenu.className = "delete-dialog";
                  contextMenu.id = "remove-relation-dialog" + relationId;
                  contextMenu.innerHTML = `
                      <div>
                          <h4 style="color:black; font-size:20px !important; border-bottom:none; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important;" >
                              Delete Relation
                          </h4>
                          <p style="color:black; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important; font-size:inherit;">
                              You're about to permanently delete this relation. Are you sure you want to proceed?
                          </p>
                          <div style="display:flex; justify-content:center; margin-top:26px; cursor:pointer;" >
                              <div style="display:flex; justify-content:space-between; cursor:pointer">
                                  <div onclick="closeDialogDeleteRelation(${relationId})" type="button" style="display:flex; margin-right:15px; cursor:pointer">
                                      <button style="cursor:pointer" class="button-close">Cancel</button>
                                  </div>
                                  <div onclick="delete_relation_issue(${relationId} , ${id})" style="display:flex; cursor:pointer" >
                                      <button style="cursor:pointer" class="button-save">Delete</button>
                                  </div>
                              </div>
                          </div>
                      </div>`;
                  bodyDiv[0].appendChild(contextMenu);
              }
              disableTabindex(".delete-dialog");
          };
          
          window.closeDialogDeleteRelation = function (relationId) {
             
              let removeDiv = document.getElementById("remove-relation-dialog" + relationId);
              removeDiv.style.display = "none";
              $("#remove-relation-dialog-backdrop" + relationId).css("display", "none");
              $(".context-menu-popup").css("z-index", "9999");
              disableTabindex(".delete-relation-dialog");
              disableTabindex(".context-menu-popup");
          };
          
          window.delete_relation_issue = function (relationId , id) {
              $.ajax({
                  type: "DELETE",
                  url: self.url + "/relations/" + relationId + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                      $('#related_issue_' + relationId).remove();
                      let ulElement = $('.related_issue_ul'); 
                      if (ulElement.children().length === 0) {
                          ulElement.css('display', 'none');  
                      }
                      closeDialogDeleteRelation(relationId); // Close the dialog after successful deletion
                   // -----
                $.ajax({
                  type: "GET",
                  url:self.url + "/issues/" + id + ".json?include=relations&&key=" + api_key +  " ",
                  dataType: "json",
                  async: false,
                    contentType: "application/json",
                  success: function (result, status, xhr) {
          
                    let issue_detail=result;
                    let exiting_relation = issue_detail.issue.relations;
                    localStorage.setItem('exiting_relation', JSON.stringify(exiting_relation));
                  }
                });
                // ----
  
                  },
                  error: function (xhr, status, error) {
                      // Handle error if needed
                  },
              });
  
          }
          
            
  
              window.closeDialogDelete = function (id) {
                window.event.preventDefault();
                let remove_div = document.getElementById("remove-dialog" + id);
                remove_div.style.display = "none";
                $("#remove-dialog-backdrop" + id).css("display", "none");
                $('.context-menu-popup').css('z-index','9999');
                disableTabindex(".delete-dialog");
                disableTabindex(".context-menu-popup");
              };
              window.DeleteIssue = function (id) {
                $(".flash").css("display", "none");
                $.ajax({
                  type: "DELETE",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    $("#remove-dialog" + id).remove();
                    $("#context-kanban" + id).remove();
                    $("#remove-dialog-backdrop" + id).remove();
                    $("#blur-div" + id).remove();
                    disableTabindex(".delete-dialog");
                    // if(self.options.element!="#version-board")
                    // {
                      getIssueAPI();
                    // }
                  
                    self.removeElement(id);
                    $(".kanban-container").css("padding-top", "15px");
                    // $("#query_form").before(`<div id='flash_notice${id}' class='flash notice'>Issue deleted successfully</div>`)
                    toastr["success"]("Issue deleted successfully");
                  },
                  error: function (xhr, status, error) {
                    if (xhr.status == 403) {
                      // console.log("You don't have right permission");
                      toastr["error"]("You don't have permission");
     
                    }
                  },
                });
              };
              window.openDialogDelete = function (id) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let remove_div = document.getElementById(
                  "remove-dialog-backdrop" + id
                );
                let open_div = document.getElementById("remove-dialog" + id);
                if (remove_div) {
                  remove_div.style.display = "block";
                  open_div.style.display = "block";
                } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                //   let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                  let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                  if(self.options.element==="#version-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                  }
                  else if(self.options.element === "#sprint-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                  }
        
                  let div = document.createElement("div");
                  div.className = "delete-dialog-backdrop";
                  div.id = "remove-dialog-backdrop" + id;
                  div.style.display = "block";
                  body_div[0].appendChild(div);
                  var context_menu = document.createElement("div" + id);
                  context_menu.className = "delete-dialog";
                  context_menu.id = "remove-dialog" + id;
                  context_menu.innerHTML = `
         <div>
         <h4  style="color:black; font-size:20px !important;  border-bottom:none; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important;" >Delete Issue-${id}</h4>
         <p style="color:black; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important; font-size:inherit;"> You're about to permanently delete this issue,
         If you're not sure, you can resolve or close this issue instead.</p>
         <div style="display:flex; justify-content:center; margin-top:26px;  cursor:pointer;" >
         <div style="display:flex; justify-content:space-between; cursor:pointer">
         <div  onclick="closeDialogDelete(${id})"  type="button" " style="display:flex; margin-right:15px;   cursor:pointer">
         <button style="cursor:pointer" class="button-close">Cancel
          </button>
          </div>
         <div  onclick="DeleteIssue(${id})" style="display:flex;  cursor:pointer" >
         <button   style="cursor:pointer" class="button-save">Delete</button>
         </div>
  
      
        </div>
        </div>
         </div>`;
                  body_div[0].appendChild(context_menu);
                }
                disableTabindex(".delete-dialog");
  
              };
              window.validate = function (values, id) {
                const errors = {};
                var reg = /^[-+]?[0-9]+\.[0-9]+$/;
                var pattern = /^[0-9]+$/;
                if (typeof values === "string" && values.length === 0) {
                  $("#hour-div-flex").css("margin-bottom", "0px");
                  $("#error-div" + id).css("display", "flex");
                  $("#error-hour" + id).html("Hour can not be blank*");
                  errors.first_name = "First name is required*";
                } else if (!(reg.test(values) || pattern.test(values))) {
                  $("#hour-div-flex").css("margin-bottom", "0px");
                  $("#error-div" + id).css("display", "flex");
                  $("#error-hour" + id).html("Only Numbers allowed*");
                  errors.first_name = "First name is required*";
                }
                if (Object.keys(errors).length) {
                  return false;
                } else {
                  return true;
                }
              };
              window.CreateLogTime = function (id) {
                $(".context-menu-popup").css("zIndex", "1040");
                $(".show-error" + id).css("display", "none");
                $(".heading-time").css("margin-bottom", "26px");
                $(".flash").css("display", "none");
                let comment_value = $("#input-text" + id).val();
                let hours = $("#input-hour" + id).val();
                $("#hour-div-flex").css("margin-bottom", "12px");
                $("#error-div" + id).css("display", "none");
  
                let date = $("#input-date" + id).val();
                let elem = document.getElementsByClassName(
                  "select-activity" + id
                );
                let activity_id = elem[0].options[elem[0].selectedIndex].value;
  
                var content = {
                  issue_id: id,
                  hours: hours,
                  spent_on: date,
                  activity_id: activity_id,
                  comments: comment_value,
                };
                // $.ajax({
                //   type: "GET",
                //   url: self.url + "/agile_custom_fields.json?key=" + api_key + " ",
                //   dataType: "json",
                //   async: false,
                //   success: function (result, status, xhr) {
                //     let custom_field_array = [];
                //     result.custom_fields.forEach((data, index) => {
                //       if (data.customized_type == "time_entry")
                //         if (data.is_required == true) {
                //           if(data.field_format==="list"||data.field_format==="enumeration"||data.field_format==="date"||data.field_format==="float"||data.field_format==="int"||data.field_format==="link")
                //           {
                //             custom_field_array.push({
                //               value: data.default_value,
                //               id: data.id,
                //             });
                //           }
                //           else if(data.field_format==="user")
                //           {
                //             custom_field_array.push({
                //               value: user_id,
                //               id: data.id,
                //             });
                //           }
                //           else if(data.field_format==="version")
                //           {
                //             custom_field_array.push({
                //               value: "1",
                //               id: data.id,
                //             });
                //           }
                //           else{
                //             custom_field_array.push({
                //               value: data.name,
                //               id: data.id,
                //             });
                //           }
  
                //         }
                //     });
                //     content = {
                //       issue_id: id,
                //       hours: hours,
                //       spent_on: date,
                //       activity_id: activity_id,
                //       comments: comment_value,
                //       custom_fields: custom_field_array,
                //     };
                //   },
                //   error: function (xhr, status, error) {
                //     content = {
                //       issue_id: id,
                //       hours: hours,
                //       spent_on: date,
                //       activity_id: activity_id,
                //       comments: comment_value,
                //     };
                //     // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                //   },
                // });
                //  setTimeout(()=>{
                $.ajax({
                  type: "POST",
                  url: self.url + "/time_entries.json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    time_entry: content,
                  }),
                  success: function (result, status, xhr) {
                    $("#time-dialog-backdrop" + id).css("display", "none");
                    $("#logtime-dialog" + id).css("display", "none");
                    $("#input-hour" + id).val(" ");
                    $("#input-text" + id).val(" ");
                    $(".input-hour" + id).val(" ");
                    $("#context-kanban" + id).css("display", "none");
                    let back_div = document.getElementById("blur-div" + id);
                    back_div.style.display = "none";
                    $(".kanban-container").css("padding-top", "15px");
                    disableTabindex(".time-dialog");
                    // $("#query_form").before(`<div id='flash_notice${id}' class='flash notice'>Time logged successfully</div>`)
                    // let content=JSON.parse(xhr.responseText).success;
                    // toastr["success"]("Time logged successfully");
                    location.reload();
                  },
                  error: function (xhr, status, error) {
                    $(".context-menu-popup").css("zIndex", "1040");
                    $(".heading-time").css("margin-bottom", "8px");
                    $("#errorExplanation").css("margin-bottom", "15px");
                    if (xhr.status == 422) {
                      let content = JSON.parse(xhr.responseText).errors;
                      // console.log(content);
                      $(".heading-time").after(
                        `<div class="show-error${id}" id='errorExplanation'><ul class="ul-time"></ul> </div>`
                      );
                      content.forEach((p) => {
                        $(".ul-time").append(`<li>${p}</li>`);
                      });
                    } else {
                      $(".heading-time").css("margin-bottom", "26px");
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    }
                  },
                });
                // },500);
              };
  
              window.closeTimeTracking = function (id) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "9999");
                $("#errorExplanation").css("display", "none");
                $("#error-div" + id).css("display", "none");
                $("#hour-div-flex").css("margin-bottom", "12px");
                $(".heading-time").css("margin-bottom", "26px");
                $("#input-hour" + id).val(" ");
                $("#input-text" + id).val(" ");
                $("#time-dialog-backdrop" + id).css("display", "none");
                $("#logtime-dialog" + id).css("display", "none");
                $(".show-error" + id).css("display", "none");
                // $("[tabindex='-1']").attr("tabindex", 0);
                disableTabindex(".time-dialog");
                disableTabindex(".context-menu-popup");
              };
  
              window.openDialogTimeTracking = function (id , project_id) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let time_log_div = document.getElementById(
                  "time-dialog-backdrop" + id
                );
                let open_logtime_div = document.getElementById(
                  "logtime-dialog" + id
                );
                if (time_log_div) {
                  time_log_div.style.display = "block";
                  open_logtime_div.style.display = "block";
                } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                //   let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                  let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                  if(self.options.element==="#version-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                  }
                  else if(self.options.element === "#sprint-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                  }
            
                  let div = document.createElement("div");
                  div.id = "time-dialog-backdrop" + id;
                  div.className = "time-dialog-backdrop";
                  div.style.display = "block";
                  body_div[0].appendChild(div);
                  var menu = document.createElement("div" + id);
                  menu.className = "time-dialog";
                  menu.id = "logtime-dialog" + id;
                  menu.innerHTML = `
                    <div class="time-tracking-div${id}">
                    <h4 class="heading-time" style="color:black; font-size:20px !important; margin-bottom:26px; border-bottom:none; font-weight: normal !important; font-family:Roboto,Arial,sans-serif !important;" >Time Tracking</h4>
                    <div style="display:flex; margin-bottom:12px;  flex-direction:row; gap:30px;">
                    <div   style="display:flex; width:20% ;">
                    <span class="agile_popup_label" id="span_time"  >Date</span>
                    </div>
                    <div style="display:flex;">
                      <input class="common-input" id="input-date${id}" type="date">
                    </div>
                   </div>
  
                   <div id="hour-div-flex" style="display:flex; flex-direction:row; margin-bottom:12px; gap:30px;">
                   <div   style="display:flex; width:20% ;">
                   <span  class="agile_popup_label" id="span_time" >Hours</span>
                   <span class="text-asterik-agile" id="hour_astrik">*</span>
                   </div>
                   <div style="display:flex;">
                     <input  class="common-input" id="input-hour${id}" size="6" type="text">
                   </div>
                  </div>
                  <div   id="error-div${id}" style="display:none; justify-content:center">
                  <p    id="error-hour${id}" style="color:red; margin-left:17px; margin-top:7px !important;"><p>
                  </div>
  
                  <div  style="display:flex; margin-bottom:12px;  flex-direction:row; gap:30px;">
                  <div   style="display:flex; width: 20%;">
                  <span class="agile_popup_label" id="span_time" >Comment</span>
                  <span class="text-asterik-agile" id="comment_asterik_${id}" >*</span>
                  </div>
                  <div style="display:flex;">
                    <input  class="comment-input common-input"" id="input-text${id}"  type="text">
                  </div>
                 </div>
                 <div style="display:flex; margin-bottom:12px;  flex-direction:row; gap:30px;">
                 <div   style="display:flex; width:20% ;">
                 <span class="agile_popup_label" id="span_time" >Activity</span>
                 </div>
                 <div style="display:flex;">
                  <select id="select-time" class="select-activity${id}">
                  </select>
                 </div>
                  </div>
                    <div style="display:flex; justify-content:center; margin-top:40px; margin-bottom:10px;  cursor:pointer;" >
                    <div style="display:flex; justify-content:space-between; cursor:pointer">
                    <div  onclick="closeTimeTracking(${id})"  type="button"  style="display:flex; margin-right:15px; cursor:pointer">
                    <button style="cursor:pointer" class="button-close">Cancel
                     </button>
                     </div>
                    <div  onclick="CreateLogTime(${id})" style="display:flex;  cursor:pointer" >
                    <button   style="cursor:pointer" class="button-save">Save</button>
                    </div>
               
                 
                   </div>
                   </div>
                    </div>
                    `;
                  body_div[0].appendChild(menu);
                  disableTabindex(".time-dialog");
                }
                var today = new Date();
                var dd = String(today.getDate()).padStart(2, "0");
                var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
                var yyyy = today.getFullYear();
                today = yyyy + "-" + mm + "-" + dd;
  
                document.getElementById("input-date" + id).value = today;
  
                let select = document.getElementsByClassName(
                  "select-activity" + id
                );
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url: self.url +"/projects/"+ project_id +".json?include=time_entry_activities&key=" +api_key +" ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                    // console.log(result.project.time_entry_activities,"result.time_entry_activities");
                    if (result.project.time_entry_activities.length != 0) {
                      for ( const option of result.project.time_entry_activities ) {
                        const { name, id, selected } = option;
                        select[0].options.add(new Option(name, id, selected));
                      }
                    }
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
             
              var commentsAstricElement = document.getElementById("comment_asterik_" + id);
              if (comments === "true") {
                commentsAstricElement.style.display = "block";
               } else {
               commentsAstricElement.style.display = "none";
                }
  
              };
  
  // --------------add notes -----------
            var quill_notes;
  
              window.open_note_box = function (id) { 
                var popup = document.getElementById('context-kanban' + id);
                var popupWidth = popup.offsetWidth;
                let snowWidth = popupWidth - 65;
                $('.notes_issue').css('width',snowWidth + 'px');
                
                  $('#issue_notes_' + id ).css('display','block');
                  $('#add_notes').css('display','none');
                  $('.notes_button').css('display','block');
                  //  $(".ql-toolbar").css("display", "none");
                  $('div.notes_issue .ql-toolbar').css('display','none');
              
                 
                  quill_notes = new Quill("#issue_notes_" + id , {
                    modules: {
                      toolbar: [
                        [{ header: [1, 2, 3, 4, 5, 6, false] }],
                        ["bold", "italic", "underline"],
                        [{ list: "ordered" }, { list: "bullet" }],
                        ['blockquote', 'code-block'],
                        ['link'],
                        [{ indent: "-1" }, { indent: "+1" }],
                        [{ direction: "rtl" }],
                        [{ align: [] }],
                      ],
                    },
                    placeholder: "write notes here...",
                    theme: "snow", // or 'bubble'
                  });
  
                                // add tooltips in quill editor toolbar
                var toolbar = quill_notes.getModule('toolbar');
                var tooltipConfig = {
                    'ql-header': 'Header',
                    'ql-bold': 'Bold',
                    'ql-italic': 'Italic',
                    'ql-underline': 'Underline',
                    'ql-list': 'List',
                    'ql-blockquote': 'Blockquote',
                    'ql-code-block': 'Code Block',
                    'ql-link': 'Insert Link',
                    'ql-direction': 'Text Direction',
                    'ql-align': 'Text Align',
                    'ql-indent': 'Indent'
                };
            
                var toolbarButtons = toolbar.container.querySelectorAll('button, span[data-value]');
                toolbarButtons.forEach(button => {
                    var className = button.className.match(/ql-[a-z-]+/);
                    if (className && tooltipConfig[className[0]]) {
                        button.setAttribute('title', tooltipConfig[className[0]]);
                        // Optionally use Tippy.js for enhanced tooltips
                        tippy(button, {
                            content: tooltipConfig[className[0]],
                            placement: 'top'
                        });
                    }
                });
                
              }
              window.save_note = function (id) {
                var value = quill_notes.root.innerHTML;
                var value_2 = underline_convet(value);
                var value_converted = toTextile(value_2);
                // console.log(value,"value ");
                // console.log(user_id,"user_id");
                $('#issue_notes_' + id ).css('display','none');
                $('#add_notes').css('display','block');
                $('.notes_button').css('display','none');
                // $(".ql-toolbar").css("display", "none");
                $('div.notes_issue .ql-toolbar').css('display','none');
                $(".circle-loader").removeClass('load-complete');
                $(".circle-loader").show();
                $(".checkmark").hide();
              $('.context-menu-popup').css('z-index','1100');
  
  // Assuming you are using jQuery for AJAX requests
  $.ajax({
    url: '/issues/' + id + '.json?key=' + api_key ,
    type: 'PUT',
    contentType: 'application/json',
    data: JSON.stringify({
      issue: {
        notes: value_converted,
        user_id: user_id
      }
    }),
    success: function(response) {
      // Handle the success response
      // console.log('Note saved successfully:', response);
      // closePopup(id);
      $(".circle-loader").hide();
      openPopup(id);
    },
    error: function(error) {
      // Handle the error response
      console.error('Error saving note:', error);
    }
  });
  
  
  
              }
  
              window.cancel_note = function (id) {
                quill_notes.root.innerHTML = '';
                $('#issue_notes_' + id ).css('display','none');
                $('#add_notes').css('display','block');
                $('.notes_button').css('display','none');
                // $(".ql-toolbar").css("display", "none");
                $('div.notes_issue .ql-toolbar').css('display','none');
  
              }
  // ---------------------------------
              window.closetextBox = function (id) {
                $("#error-div-desc" + id).css("display", "none");
                // $("#desc-field"+id).val('');
                let text_elem = document.getElementById("textbox-div" + id);
                text_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-div" + id);
                hide_elem.style.display = "flex";
              };
              var quill;
              window.openTextbox = function (id) {
  
                var popup = document.getElementById('context-kanban' + id);
                var popupWidth = popup.offsetWidth;
                let snowWidth = popupWidth - 65;
                let desc_div = document.getElementById("textbox-div" + id);
                desc_div.style.width = snowWidth + "px";
                $('div.text-divv .ql-toolbar').css('display','none');
                let Issue=getissueDetail(id);
                if(Issue.description!=null)
                {
                  var value_text = textile.convert(Issue.description);
                  $("#show-desc" + id).html(value_text);
                  $("#desc-field" + id).html(value_text);
                }
            
                quill = new Quill("#desc-field" + id, {
                  modules: {
                    toolbar: [
                      [{ header: [1, 2, 3, 4, 5, 6, false] }],
                      ["bold", "italic", "underline"],
                      [{ list: "ordered" }, { list: "bullet" }],
                      ['blockquote', 'code-block'],
                      ['link'],
                      [{ indent: "-1" }, { indent: "+1" }],
                      [{ direction: "rtl" }],
                      [{ align: [] }],
                    ],
                  },
                  placeholder: "write description here...",
                  theme: "snow", // or 'bubble'
                });
                // console.log(quill);
  
                if (!($("#show-desc" + id).html() == "Add a description...")) {
  
                  //$("#desc-field" + id).val($("#show-desc" + id).html());
                } else {
                  //$("#desc-field" + id).val(" ");
                }
  
                let text_elem = document.getElementById("textbox-div" + id);
                text_elem.style.display = "flex";
                let hide_elem = document.getElementById("hide-div" + id);
                hide_elem.style.display = "none";
  
                // add tooltips in quill editor toolbar
                var toolbar = quill.getModule('toolbar');
                var tooltipConfig = {
                    'ql-header': 'Header',
                    'ql-bold': 'Bold',
                    'ql-italic': 'Italic',
                    'ql-underline': 'Underline',
                    'ql-list': 'List',
                    'ql-blockquote': 'Blockquote',
                    'ql-code-block': 'Code Block',
                    'ql-link': 'Insert Link',
                    'ql-direction': 'Text Direction',
                    'ql-align': 'Text Align',
                    'ql-indent': 'Indent'
                };
            
                var toolbarButtons = toolbar.container.querySelectorAll('button, span[data-value]');
                toolbarButtons.forEach(button => {
                    var className = button.className.match(/ql-[a-z-]+/);
                    if (className && tooltipConfig[className[0]]) {
                        button.setAttribute('title', tooltipConfig[className[0]]);
                        // Optionally use Tippy.js for enhanced tooltips
                        tippy(button, {
                            content: tooltipConfig[className[0]],
                            placement: 'top'
                        });
                    }
                });
              }; 
  
  
    // --------------categrory function ------------
  
              window.showCategroy = function (id, project_id ) {
              let select_elem = document.getElementById("CategroySelect" + id);
              select_elem.style.display = "flex";
              select_elem.style.width = "250px";
              let hide_elem = document.getElementById("hide-categroy" + id);
              hide_elem.style.display = "none";
  
              $(".categroy" + id).html(" ");
              var categroy_id;
              $(".show-error").css("display", "none");
              $.ajax({
                type: "GET",
                url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                dataType: "json",
                async: false,
                contentType: "application/json",
                success: function (result, status, xhr) {
                  if(result.issue.category!=null){
                  categroy_id = result.issue.category.id;
                  }
                },
  
                error: function (xhr, status, error) {
                  // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                },
              });
  
  
  
              let select = document.getElementsByClassName("categroy" + id);
              if (select[0].options.length == 0) {
              $.ajax({
                type: "GET",
                url: self.url + "/projects/" + project_id + "/issue_categories.json?key=" + api_key + " ",
                dataType: "json",
                async: false,
                contentType: "application/json",
                success: function (result, status, xhr) {
                  // console.log(result,"result");
                  if (result.issue_categories.length != 0) {
                  $(".categroy" + id).append( `<option selected value="" ></option>`)
                    result.issue_categories.forEach((c) => {
                      if (c.id == categroy_id) {
                        $(".categroy" + id).append(
                          `<option  selected value=${c.id}>${c.name}</option>`
                        );
  
                      } else {
                        $(".categroy" + id).append(
                          `<option value=${c.id}>${c.name}</option>`
                        );
                      }
                    });
                  }
                },
  
                error: function (xhr, status, error) {
                  // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                },
              });
            }       
              }
  
              window.closeCategory = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("CategroySelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-categroy" + id);
                hide_elem.style.display = "flex";
              };
  
              window.saveCategroy = function (id) {
               
                let select_elem = document.getElementById("CategroySelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-categroy" + id);
                hide_elem.style.display = "flex";
                let select = document.getElementsByClassName("categroy" + id);
                let categroy_id = select[0].options[select[0].selectedIndex].value;
                // let category_name = select[0].options[select[0].selectedIndex].text;
                let content = {
                  category_id: categroy_id ? parseInt(categroy_id):" ",
                }
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    "issue": content
                  }),
                  success: function (result, status, xhr) {
                    // $(".category_name_" + id).html(category_name);
                    let select = document.getElementsByClassName("categroy" + id);
  
                    if(categroy_id)
                    {
                      $(".category_name_" + id).html(
                        select[0].options[select[0].selectedIndex].innerHTML
                      );
                    }
                    else{
                      $(".category_name_" + id).html(
                        "-"
                      );
                    }
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
  
  
              window.showversion = function (id, project_id) {
                let select_elem = document.getElementById("VersionSelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-version" + id);
                hide_elem.style.display = "none";
                $(".version" + id).html(" ");
                var version_id;
                $(".show-error").css("display", "none");
                $.ajax({
                  type: "GET",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    if(result.issue.fixed_version!=null){
                    version_id = result.issue.fixed_version.id;
                  }
                },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
                let select = document.getElementsByClassName("version" + id);
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url: self.url + "/projects/" + project_id + "/versions.json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      if (result.versions.length != 0) {
                        result.versions.forEach((p) => {
                          if (p.id == version_id) {
                            $(".version" + id).append(
                              `<option  selected value=${p.id}>${p.name}</option>`
                            );
  
                          } else {
                            $(".version" + id).append(
                              `<option value=${p.id}>${p.name}</option>`
                            );
                          }
                        });
                      }
                    },
  
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              };
  
  
              window.closeVersion = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("VersionSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-version" + id);
                hide_elem.style.display = "flex";
              };
  
  
              window.saveVersion = function (id) {
                let select_elem = document.getElementById("VersionSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-version" + id);
                hide_elem.style.display = "flex";
                let select = document.getElementsByClassName("version" + id);
                let version_id = select[0].options[select[0].selectedIndex].value;
                let version_name = select[0].options[select[0].selectedIndex].text;
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: {
                      fixed_version_id: version_id,
                    },
                  }),
                  success: function (result, status, xhr) {
                    $(".version_name_" + id).html(version_name);
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
  
  
              window.showstatus = function (id) {
  
                let select_elem = document.getElementById("StatusSelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-status" + id);
                hide_elem.style.display = "none";
                $(".status" + id).html(" ");
                var status_id;
                $(".show-error").css("display", "none");
                $.ajax({
                  type: "GET",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    if(result.issue.status!=null){
                    status_id = result.issue.status.id;
                    }
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
                let select = document.getElementsByClassName("status" + id);
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url: self.url + "/issue_statuses.json?key=" + api_key + " ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      getWorkflow(id);
                      // console.log(result,"result");
                      // console.log(workflow_status,"workflow_status");
                      if (result.issue_statuses.length != 0) {
                        result.issue_statuses.forEach((s) => {
                          if (workflow_status.includes(s.id)) {
                          if (s.id == status_id) {
                            $(".status" + id).append(
                              `<option  selected value=${s.id}>${s.name}</option>`
                            );
  
                          } else {
                            $(".status" + id).append(
                              `<option value=${s.id}>${s.name}</option>`
                            );
                          }
                        }
                        });                 
                      }
                    },
  
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              };
  
              window.closeStatus = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("StatusSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-status" + id);
                hide_elem.style.display = "flex";
              };
  
              window.saveStatus = function (id) {
                let select_elem = document.getElementById("StatusSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-status" + id);
                hide_elem.style.display = "flex";
                let select = document.getElementsByClassName("status" + id);
                let status_id = select[0].options[select[0].selectedIndex].value;
                let status_name = select[0].options[select[0].selectedIndex].text;
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: {
                      status_id: status_id,
                    },
                  }),
                  success: function (result, status, xhr) {
                    $(".status_" + id).html(status_name);
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
  
              window.delete_sub_task = function (id) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let remove_div = document.getElementById("remove-subtask-backdrop" + id);
                let open_div = document.getElementById("remove-subtask" + id);
                if (remove_div) {
                  remove_div.style.display = "block";
                  open_div.style.display = "block";
                } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                //   let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                  let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                  if(self.options.element==="#version-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                  }
                  else if(self.options.element === "#sprint-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                  }
  
  
                  // dynamic message shown in popup
                  function checkSubtasks(id) {
                    let subTaskElement = document.getElementById("sub_task_" + id);
                    if (subTaskElement) {
                        if (subTaskElement.querySelector(".sub_task_ul")) {
                            return true;
                        }
                    }
                    return false;   
                  }
                  function countSubtasks(id) {
                    let subTaskElement = document.getElementById("sub_task_" + id);
                    if (subTaskElement) {
                        let subtasks = subTaskElement.querySelectorAll(".sub_task_ul .sub_task_li");
                        return subtasks.length;
                    }
                    return 0;
                  }
                  
                  let hasOwnSubtasks = checkSubtasks(id);
                  let subtaskCount = countSubtasks(id);
                  let message;
                  if (hasOwnSubtasks) {
                      message = `Deleting this subtask will also delete its (${subtaskCount}) subtasks. Are you sure you want to proceed?`;
                  } else {
                      message = "You're about to permanently delete this subtask. Are you sure you want to proceed?";
                  }
                   // dynamic message shown in popup end
                  
                  let div = document.createElement("div");
                  div.className = "delete-subtask-backdrop";
                  div.id = "remove-subtask-backdrop" + id;
                  div.style.display = "block";
                  body_div[0].appendChild(div);
                  var context_menu = document.createElement("div" + id);
                  context_menu.className = "delete-subtask";
                  context_menu.id = "remove-subtask" + id;
                  context_menu.innerHTML = `
         <div>
         <h4  style="color:black; font-size:20px !important;  border-bottom:none; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important;" >Delete Sub Task</h4>
         <p style="color:black; font-weight:normal !important; font-family:Roboto,Arial,sans-serif !important; font-size:inherit;">
         ${message}
          </p>
         <div style="display:flex; justify-content:center; margin-top:26px;  cursor:pointer;" >
         <div style="display:flex; justify-content:space-between; cursor:pointer">
         <div  onclick="closeDialogdeleteSubTask(${id})"  type="button" " style="display:flex; margin-right:15px;   cursor:pointer">
         <button style="cursor:pointer" class="button-close">Cancel
          </button>
          </div>
         <div  onclick="delete_sub_task_issue(${id})" style="display:flex;  cursor:pointer" >
         <button   style="cursor:pointer" class="button-save">Delete</button>
         </div>
  
      
        </div>
        </div>
         </div>`;
                  body_div[0].appendChild(context_menu);
                }
                disableTabindex(".delete-subtask");
              
        }
  
              window.closeDialogdeleteSubTask = function (id) {
                window.event.preventDefault();
                let removeDiv = document.getElementById("remove-subtask" + id);
                removeDiv.style.display = "none";
                $("#remove-subtask-backdrop" + id).css("display", "none");
                $(".context-menu-popup").css("z-index", "9999");
                disableTabindex(".delete-subtask");
                disableTabindex(".context-menu-popup");
            };
  
            window.delete_sub_task_issue = function (id) {
              $.ajax({
                type: "PUT",
                url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                  issue: {
                    parent_issue_id: null ,
                    no_flash: 1 ,
                  },
  
                }),
                success: function (result, status, xhr) {
                  const divToRemove = $('#sub_task_' + id );
                  $("#remove-subtask" + id).remove();
                  $("#remove-subtask-backdrop" + id).remove();
                  $('.context-menu-popup').css('z-index','9999');
                  disableTabindex(".delete-subtask");
                  disableTabindex(".context-menu-popup");
                  if (divToRemove) {
                    divToRemove.remove();
                  }
                  let ulElement = $('.sub_task_ul'); 
                  if (ulElement.children().length === 0) {
                      ulElement.css('display', 'none');  
                  }
                  
                  toastr["success"]("Sub task deleted successfully");
                },
                error: function (xhr, status, error) {
                  toastr["error"]("You don't have permission");
                },
              });
          }
  
  
  
              window.delete_attachment = function (id) {
                $.ajax({
                  type: "DELETE",
                  url: self.url + "/attachments/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    $('#attachments_' + id ).hide();
                  },
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              }
  
              window.add_attachment = function (id) {
              $('.new_attachment_' + id).css('display','flex');
              $('#error_attachment' + id ).hide();
              }
  
  
            // function handleFileSelect(event, id) {
            window.handleFileSelect = function(event, id){
  
               $(".circle-loader").removeClass('load-complete');
               $(".circle-loader").show();
               $(".checkmark").hide();
               $('.context-menu-popup').css('z-index','1100');
              const files = event.target.files;
              for (let i = 0; i < files.length; i++) {
                const file = files[i];
                uploadFile(file, function(error, token, filename) {
                  if (error) {
                    console.error(error);
                    alert('Failed to upload file');
                    return;
                  }
                  
                  // Replace `issueId` with the actual issue ID
                  const issueId = id;
                  const description = 'Optional file description'; // Customize as needed
                  attachFileToIssue(issueId, token, filename, description);
                });
              }
            }
  
            function uploadFile(file, callback) {
              const xhr = new XMLHttpRequest();
              const url = '/uploads.json?filename=' + encodeURIComponent(file.name) + '&key=' + api_key;
              
              xhr.open('POST', url, true);
              xhr.setRequestHeader('Content-Type', 'application/octet-stream');
              
              xhr.onload = function() {
                if (xhr.status === 201) {
                  const response = JSON.parse(xhr.responseText);
                  const token = response.upload.token;
                  callback(null, token, file.name);
                } else {
                  callback('Failed to upload file', null, null);
                }
              };
              
              xhr.onerror = function() {
                callback('An error occurred while uploading the file', null, null);
              };
              
              xhr.send(file);
            }
                      
  
            function attachFileToIssue(issueId, token, filename, description) {
              const xhr = new XMLHttpRequest();
              const url = `/issues/${issueId}.json?key=` + api_key;
              
              const issueData = {
                issue: {
                  uploads: [
                    {
                      token: token,
                      filename: filename,
                      description: description,
                      content_type: 'application/octet-stream'
                    }
                  ]
                }
              };
              
              xhr.open('PUT', url, true);
              xhr.setRequestHeader('Content-Type', 'application/json');
              
              xhr.onload = function() {
                $(".circle-loader").hide();
                $('#new-attachments').hide();
                openPopup(issueId);
              };
              
              xhr.onerror = function() {
                alert('An error occurred while attaching the file to the issue');
              };
              
              xhr.send(JSON.stringify(issueData));
            }
            
  
  
            //       },
            //       error: function (xhr, status, error) {
            //           // Handle error
            //           console.error('Error uploading file:', error);
            //             $(".circle-loader").hide();
            //             $('.new_attachment_' + id).css('display', 'none');
            //             $('#error_attachment' + id ).show();
            //       }
            //   });
            // }
  
            window.show_Story_points = function (id) {
              let select_elem = document.getElementById("Story_pointSelect" + id);
              select_elem.style.display = "flex";
              select_elem.style.width = "250px";
              let hide_elem = document.getElementById("hide_Story_points" + id);
              hide_elem.style.display = "none";
              $(".story-points" + id).html(" ");
              var story_points;
              $(".show-error").css("display", "none");
  
              $.ajax({
                type: "GET",
                url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                dataType: "json",
                async: false,
                contentType: "application/json",
                success: function (result, status, xhr) {
                  if(result.issue.story_points!=null){
                  story_points = result.issue.story_points;
                  }
                },
  
                error: function (xhr, status, error) {
                  // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                },
              });
  
              let select = document.getElementsByClassName("story_point" + id);
              // console.log(select,'select');
              // console.log(story_points_val,'story_points_value');
              
            let splitValues = [];
            splitValues = story_points_val.split(',').map(Number);
  
            // console.log(splitValues,'splitValues');
            if (select[0].options.length == 0) {
            for(let i = 0 ; i < splitValues.length ; i++){
            if( splitValues[i] == parseInt(story_points) ){
              $(".story_point" + id).append(`<option  selected value=${splitValues[i]}>${splitValues[i]}</option>`);
            } else {
              $(".story_point" + id).append(`<option value=${splitValues[i]}>${splitValues[i]}</option>`);
            }
            }
          }
  
            };
  
            window.close_story_point = function (id) {
              window.event.preventDefault();
              let select_elem = document.getElementById("Story_pointSelect" + id);
              select_elem.style.display = "none";
              let hide_elem = document.getElementById("hide_Story_points" + id);
              hide_elem.style.display = "flex";
            };
  
            window.save_story_point = function (id) {
              let select_elem = document.getElementById("Story_pointSelect" + id);
              select_elem.style.display = "none";
              let hide_elem = document.getElementById("hide_Story_points" + id);
              hide_elem.style.display = "flex";
              let select = document.getElementsByClassName("story_point" + id);
  
              let story_points = select[0].options[select[0].selectedIndex].value;
              $.ajax({
                type: "PUT",
                url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                  issue: {
                    story_points: story_points,
                  },
                }),
                success: function (result, status, xhr) {
                  $(".story_points_" + id).html(story_points);
                },
                error: function (xhr, status, error) {
                  // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                },
              });
            };
  
            window.deleted_relations = function (id) {
              $.ajax({
                type: "DELETE",
                url: self.url + "/relations/" + id + ".json?key=" + api_key + " ",
                dataType: "json",
                contentType: "application/json",
                success: function (result, status, xhr) {
                  $('#related_issue_' + id ).hide();
                },
                error: function (xhr, status, error) {
                  // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                },
              });
            }
            window.multipleAutocompleteField=function(fieldId, url, options) {
              // console.log("function calls...");
              function split(val) {
                return val.split(/,\s*/);
              }
            
              function extractLast(term) {
                return split(term).pop();
              }
            
              $(document).ready(function () {
                $('#' + fieldId).autocomplete($.extend({
                  source: function (request, response) {
                    $.getJSON(url, {
                      term: extractLast(request.term)
                    }, response);
                  },
                  minLength: 2,
                  position: {collision: "flipfit"},
                  search: function () {
                    $('#' + fieldId).addClass('ajax-loading');
                  },
                  response: function () {
                    $('#' + fieldId).removeClass('ajax-loading');
                  },
                  select: function (event, ui) {
                    var terms = split(this.value);
                    // remove the current input
                    terms.pop();
                    // add the selected item
                    terms.push(ui.item.value);
                    // add placeholder to get the comma-and-space at the end
                    terms.push("");
                    this.value = terms.join(", ");
                    return false;
                  }
                }, options));
                $('#' + fieldId).addClass('autocomplete');
              });
            }
  
           
            window.observeAutocompleteField=function(fieldId, url, options) {
              $(document).ready(function() {
                $('#'+fieldId).autocomplete($.extend({
                  source: url,
                  minLength: 2,
                  position: {collision: "flipfit"},
                  search: function(){$('#'+fieldId).addClass('ajax-loading');},
                  response: function(){$('#'+fieldId).removeClass('ajax-loading');}
                }, options));
                $('#'+fieldId).addClass('autocomplete');
              });
            }
  
            
            window.compareVersions=function(version1, version2){
              var v1 = version1.split('.').map(Number);
              var v2 = version2.split('.').map(Number);
          
              for (var i = 0; i < v1.length; i++) {
                  if (v1[i] < v2[i]) return -1;
                  if (v1[i] > v2[i]) return 1;
              }
          
              return 0;
          }
  
            window.setPredecessorFieldsVisibility=function() {
              var relationType = $('#relation_relation_type');
              if (relationType.val() == "precedes" || relationType.val() == "follows") {
                $('#predecessor_fields').show();
              } else {
                $('#predecessor_fields').hide();
              }
            }
            window.add_relation = function (id , get_project_id) {
              // console.log("add relation clicked");
              
              // console.log(redmineversionid,'redmine version');
              var formContainer = $('#relation_form_container');
              var form_field = $('.new_relation_form' + id);
              form_field.show();
              formContainer.show();
              // console.log(form_field,"form_field");
              form_field.html(`<form class="new_relation" id="new-relation-form" style="" action="/issues/${id}/relations" accept-charset="UTF-8" data-remote="true" name="new-relation-form-339acec7" method="post"><input name="utf8" type="hidden" value="✓" autocomplete="off">
              <p><select style="height: 28px;" onchange="setPredecessorFieldsVisibility();" name="relation[relation_type]" id="relation_relation_type"><option selected="selected" value="relates">Related to</option>
              <option value="duplicates">Is duplicate of</option>
              <option value="duplicated">Has duplicate</option>
              <option value="blocks">Blocks</option>
              <option value="blocked">Blocked by</option>
              <option value="precedes">Precedes</option>
              <option value="follows">Follows</option>
              <option value="copied_to">Copied to</option>
              <option value="copied_from">Copied from</option>
              <option value="start_to_start">start to start</option>
              <option value="start_to_finish">start to finish</option>
              <option value="finish_to_finish">finish to finish</option>
              <option value="finish_to_start">finish to start</option></select>
              Issue #<input value="" size="10" style="height: 28px;" type="text" name="relation[issue_to_id]" id="relation_issue_to_id" class="ui-autocomplete-input autocomplete" autocomplete="off">
              <span id="predecessor_fields" style="display:none;">
              Delay: <input size="3" type="text" name="relation[delay]" id="relation_delay"> days
              </span>
            <button class="add_relation_button" type="submit" name="commit" style="height: 28px;"  onclick="validateAndSubmitRelation(${id}, ${get_project_id})">
                    <i class="fa-solid fa-check right-icon-kanban"> </i>
            </button>
            <button style="height: 28px;"  class="relation_close_pop" onclick="$(&quot;.new_relation&quot;).hide(); $('.issue_relation_error_message').hide(); return false;" > <i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i> </button>
    
              </p>
              
              <script>
              //<![CDATA[
  
                if (compareVersions(redmineversionid, '4.1.1') <= 0) {
                  observeAutocompleteField('relation_issue_to_id', '/issues/auto_complete?issue_id=${id}&project_id=${get_project_id}');
              } else {
                  multipleAutocompleteField('relation_issue_to_id', '/issues/auto_complete?issue_id=${id}&project_id=${get_project_id}');
              }
              
              //]]>
              </script>
              
              <script>
              //<![CDATA[
              setPredecessorFieldsVisibility();
              //]]>
              </script>`);
  
  
            }
  
              window.validateAndSubmitRelation = function (id, get_project_id ) {
            
            //  console.log("validation function Runn");
  
              var exiting_relation_str = localStorage.getItem('exiting_relation');
              if (exiting_relation_str === "undefined") {
                var exiting_relation = [];
              } else {
                var exiting_relation = JSON.parse(exiting_relation_str) || [];
              }
              var issueIdField = $('#relation_issue_to_id');
              var issueIds = issueIdField.val().trim().split(',').map(id => id.trim()); 
              var relation_value = $('#relation_relation_type').val();
              var errorMessage = '';
  
              if (issueIdField.val().trim() === '') {
                  errorMessage += '<li>Please enter issue ID</li>';      
              }
  
              if (issueIdField.hasClass('ui-autocomplete-input')) {             
                var invalidIssueIds = [];
                issueIds.forEach(issueId => {
                    var term = issueId;
                    var url = window.location.origin + '/issues/auto_complete?issue_id=' + id + '&project_id=' + get_project_id + '&term=' + term;
                    if (term.length && !/^[a-z0-9]+$/i.test(term)) {
                      errorMessage += '<li>Please enter a valid issue ID </li>';
                    }
                    $.ajax({
                        url: url,
                        async: false, 
                        success: function (data) {
                            if (data.length === 0) {
                                invalidIssueIds.push(issueId);
                            }
                            else {
                              var existingRelations = exiting_relation.filter(relation => relation.issue_to_id == issueId);
                              existingRelations.forEach(existingRelation => {
                               if (existingRelation.relation_type === "duplicates" && relation_value === "duplicates") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "blocks" && relation_value === "blocks") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "precedes" && relation_value === "precedes") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "copied_to" && relation_value === "copied_to") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "start_to_start" && relation_value === "start_to_start") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "start_to_finish" && relation_value === "start_to_finish") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "finish_to_finish" && relation_value === "finish_to_finish") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "finish_to_start" && relation_value === "finish_to_start") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                              else if (existingRelation.relation_type === "relates" && relation_value === "relates"){
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                            });
  
                              var existingRelations_filter = exiting_relation.filter(relation => relation.issue_id == issueId );
                              existingRelations_filter.forEach(existingRelation => {
                               if (existingRelation.relation_type === "duplicates" && relation_value === "duplicated") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                              else if (existingRelation.relation_type === "relates" && relation_value === "relates") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              } else if (existingRelation.relation_type === "blocks" && relation_value === "blocked") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                              else if (existingRelation.relation_type === "precedes" && relation_value === "follows") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                              else if (existingRelation.relation_type === "copied_to" && relation_value === "copied_from") {
                                errorMessage += '<li>This issue ( '+ issueId +') is already exists in a related context </li>'
                              }
                             
                            });
  
                            
  
                            }
                        }
                    });
                });
        
                if (invalidIssueIds.length > 0) {
                    errorMessage += '<li> Issue ID is invalid: ' + invalidIssueIds.join(', ') + '</li>';
                  }
                }
  
                if (errorMessage !== '') {
                  $('#flash_error').html('<ul>' + errorMessage + '</ul>').show();
                  return false;
                }
                else {
                    submit_relation(id);
                }
            }
  
            window.submit_relation = function (id) {
              $(".circle-loader").removeClass('load-complete');         
              $(".checkmark").hide();
              $(".circle-loader").show();
              $('#relation_form_container').hide();
              $('.context-menu-popup').css('z-index','1100');
              $('.issue_relation_error_message').hide();
             
  
  
                setTimeout(() => {
                  openPopup(id);
                }, 500);
  
                setTimeout(() => {
                  $(".circle-loader").hide();
                  $('.context-menu-popup').css('z-index','9999');
                }, 1000);
  
               
   
            }
  
  
            
              window.showPriority=function(id)
              {
                let priority_id;
                let select_elem = document.getElementById("prioritySelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-priority" + id);
                hide_elem.style.display = "none";
                 let Issue=getissueDetail(id);
                $(".priority" + id).html(" ");
                if(Issue.priority!=null)
                {
                  priority_id=Issue.priority.id;
                }
                let select = document.getElementsByClassName(
                  "priority" + id
                );
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url:
                      self.url +
                      "/enumerations/issue_priorities.json?key=" +
                      api_key +
                      " ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      if (result.issue_priorities.length != 0) {
                        result.issue_priorities.forEach((p) => {
                          if (p.id == priority_id) {
                            $(".priority" + id).append(
                              `<option  selected value=${p.id}>${p.name}</option>`
                            );
  
                          } else {
                            $(".priority" + id).append(
                              `<option value=${p.id}>${p.name}</option>`
                            );
                          }
                        });
                      }
  
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              }
              window.closePriority=function(id)
              {
                let select_elem = document.getElementById("prioritySelect" + id);
                select_elem.style.display = "none";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-priority" + id);
                hide_elem.style.display = "flex";
              }
              window.showTracker=function(id,project_id)
              {
                let select_elem = document.getElementById("trackerSelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-tracker" + id);
                hide_elem.style.display = "none";
   
    
                $(".tracker" + id).html(" ");
                var tracker_ID;
                $(".show-error").css("display", "none");
                $.ajax({
                  type: "GET",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                    tracker_ID = result.issue.tracker.id;
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
                let select = document.getElementsByClassName(
                  "tracker" + id
                );
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url: `${self.url}/projects/${project_id}.json?key=${api_key}&&include=trackers`,
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      if (result.project.trackers.length != 0) {
                        let select_elem = document.getElementById("trackerSelect" + id);
                        select_elem.style.display = "flex";
                        select_elem.style.width = "250px";
                        let hide_elem = document.getElementById("hide-tracker" + id);
                        hide_elem.style.display = "none";
                        result.project.trackers.forEach((p) => {
                          if (p.id == tracker_ID) {
                            $(".tracker" + id).append(
                              `<option  selected value=${p.id}>${p.name}</option>`
                            );
                          } else {
                            $(".tracker" + id).append(
                              `<option value=${p.id}>${p.name}</option>`
                            );
                          }
                        });
                      } else {
                        $(".show-error").css("display", "block");
                        // $("#query_form").before(`<div class="show-error${id}" id='errorExplanation'><ul class="ul-time"><li>No tracker associated with  project please check your project setting</li></ul> </div>`);
                      }
                    },
  
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
              }
              window.closeTracker=function(id)
              {
                window.event.preventDefault();
                let select_elem = document.getElementById("trackerSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-tracker" + id);
                hide_elem.style.display = "flex";
              }
              
  
               function getissueDetail(id) {
                let Issue;
                $.ajax({
                  type: "GET",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
                      Issue = result.issue;
                  },
                  error: function (xhr, status, error) {
                  },
                });
                return Issue;
               }
              window.showAssignee = function (id,project_ID) {
                let assigned_to_id;
                let select_elem = document.getElementById("assineeSelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "250px";
                let hide_elem = document.getElementById("hide-assignee" + id);
                hide_elem.style.display = "none";
                $(".assignee" + id).html(" ");
                $(".show-error").css("display", "none");
                 let issueDetail=getissueDetail(id);
                  if(issueDetail.assigned_to!=null)
                  {
                    assigned_to_id=issueDetail.assigned_to.id;
                  }
                let select = document.getElementsByClassName("assignee" + id);
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url: self.url + "/projects/" + project_ID + "/actived_users.json?id="+ project_ID +"&&key=" + api_key + "",
                    dataType: "json",
                    async: false,
                    id : project_ID ,
                    success: function(result, status, xhr) {
                      all_watcher = result.active_users;
                      var contents = result.active_users;
                       $(".assignee" + id).append( `<option selected value=""></option>`)
                      if (contents.length != 0) {
                        contents.forEach((p) => {
                           if(p.id===assigned_to_id)
                            {
                              $(".assignee" + id).append( `<option selected value=${p.id} >${p.name}</option>`)
                            }
                            else{
                              $(".assignee" + id).append( `<option  value=${p.id} >${p.name}</option>`)
                            }
                        }
                        );
                      
                        }
                        // ---
                      }
                    
                  });
                  
                }
              };
              window.closeAssignee = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("assineeSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-assignee" + id);
                hide_elem.style.display = "flex";
              };
              window.saveAssignee = function (id) {
                let select_elem = document.getElementById("assineeSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-assignee" + id);
                hide_elem.style.display = "flex";
  
                var elem = document.getElementsByClassName("assignee" + id);
                var assigned_to_id = elem[0].options[elem[0].selectedIndex].value;
                var content = {
                  assigned_to_id:    assigned_to_id? parseInt(assigned_to_id):" ",
                };
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
  
                    var elem = document.getElementsByClassName("assignee" + id);
                    if(assigned_to_id)
                    {
                      $(".assignee-name" + id).html(
                        elem[0].options[elem[0].selectedIndex].innerHTML
                      );
                    }
                    else{
                      $(".assignee-name" + id).html(
                        "Unassigned"
                      );
                    }
                
                    var name_value =
                      elem[0].options[elem[0].selectedIndex].innerHTML.split(" ");
                    var firstname = name_value[0];
                    var lastname = name_value[1] ? name_value[1] : "";
                    var intials = firstname.charAt(0) + lastname.charAt(0);
                    $("#user-name" + id).html(intials);
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    if (xhr.status == 422) {
  
                      let content = JSON.parse(xhr.responseText).errors;
                      // console.log(content);
                      // console.log("You don't have right permission");
                      content.forEach((object) => {
                        if (object === "Assignee is invalid") {
                          toastr["error"]("Assignee is invalid");
                        }
                      })
  
                    }
                  },
                });
              };
  
       
              window.showPercent = function (id) {
                let done_ratio;
                let select_elem = document.getElementById("percentSelect" + id);
                select_elem.style.display = "flex";
                select_elem.style.width = "300px";
                let hide_elem = document.getElementById("hide-percent" + id);
                hide_elem.style.display = "none";
                $(".percent" + id).html(" ");
                $(".show-error").css("display", "none");
                 let issueDetail=getissueDetail(id);
                  if(issueDetail.done_ratio!=null)
                  {
                    done_ratio=issueDetail.done_ratio;
                  }
                let done_select = $(".percent" + id);
                if (done_select[0].options.length == 0) {
                  for (let i = 0; i <= 100; i++) {
                    if (i % 10 == 0) {
                      if (done_ratio == i) {
                        $(".percent" + id).append(
                          `<option selected value=${i}>${i}%</option>`
                        );
                      } else {
                        $(".percent" + id).append(
                          `<option value=${i}>${i}%</option>`
                        );
                      }
                    }
                  }
                }
              };
              window.closeDoneRatio = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("percentSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-percent" + id);
                hide_elem.style.display = "flex";
              };
              window.savePercent = function (id) {
                let select_elem = document.getElementById("percentSelect" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-percent" + id);
                hide_elem.style.display = "flex";
  
                var elem = document.getElementsByClassName("percent" + id);
                var done_ratio = elem[0].options[elem[0].selectedIndex].value;
                var unit = "%";
                var new_width = done_ratio + unit;
                var content = {
                  done_ratio: parseInt(done_ratio),
                };
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
                    var elem = document.getElementsByClassName("percent" + id);
                    $(".done-ratio" + id).html(
                      elem[0].options[elem[0].selectedIndex].innerHTML
                    );
                    $("#category_id" + id).html(
                      elem[0].options[elem[0].selectedIndex].innerHTML
                    );
  
                    $("#progress_show_" + id).html(
                      elem[0].options[elem[0].selectedIndex].innerHTML
                    );
  
                    $("#progress_" + id).css('width', new_width
                    );
  
                  },
  
                  error: function (xhr, status, error) {
                    //  console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
  
              window.changeStartData = function (id) {
                var date = document.getElementById("issue_data_" + id);
                date.style.display = "none";
                $("#start-dates"+id).val(date.getAttribute("value"));
                var div = document.getElementById("editable_date_" + id);
                div.style.display = "block";
                let errorDiv=document.getElementById("error-start"+id);
                if(errorDiv)
                errorDiv.style.display="none";
              }
  
              // add a function to open due due field 
              window.changeDueDate=function(id)
              {
                let date = document.getElementById("issue_data_due_" + id);
                let div = document.getElementById("editable_duedate_" + id);
                date.style.display = "none";
                div.style.display = "block";
                $("#due-dates"+id).val(date.getAttribute("value"))
                let errorDiv=document.getElementById("error-due"+id);
                if(errorDiv)
                errorDiv.style.display="none";
             
              }
  
  
              window.showHour = function (id) {
                var get_hour = $(".estimated-hour" + id).text(); 
                var updated_time = get_hour.replace(/h/g, '');
                $("#input-value" + id).val(updated_time);
                let select_elem = document.getElementById("Hour-div" + id);
                select_elem.style.display = "flex";
                let hide_elem = document.getElementById("hide-hour" + id);
                hide_elem.style.display = "none";
              };
  
              window.closeEstimatedHour = function (id) {
                window.event.preventDefault();
                let select_elem = document.getElementById("Hour-div" + id);
                select_elem.style.display = "none";
                let hide_elem = document.getElementById("hide-hour" + id);
                hide_elem.style.display = "flex";
                let errorDiv=document.getElementById("error-div-ehour");
                if( errorDiv)
                errorDiv.style.display="none";
              };
  
              //Coverted time decimal to hh:mm formate Function
              function convertToHHMM(info) {
                var hrs = parseInt(Number(info));
                var min = Math.round((Number(info) - hrs) * 60);
                return hrs + ":" + min;
              }
              var convertedTime;
              var watcher_array = [];
              var not_watcher = [];
              var all_watcher = [];
            
  
              function validateEstimation(value)
              {
                // console.log("function run of validation");
                  let errors={};
                  var reg = /^(?:\d+(\.\d+)?|\d+:\d+)$/;
                  var white_space = /^\s+$/;
  
                  if (typeof value === "string" && value.length == 0) {
                    $("#error-div-ehour").css("display", "flex");
                    $("#error-text-hour").html("Hour can not be blank*");
                    errors.estimation="Hour can not be blank*";
                  } else if (white_space.test(value)) {
                    $("#error-div-ehour").css("display", "flex");
                    $("#error-text-hour").html("Hour can not be blank*");
                    errors.estimation="Hour can not be blank*";
                  }
                   else if(!(reg.test(value)))
                  {
                  
                       $("#error-div-ehour").css("display", "flex");
                       $("#error-text-hour").html("Value must be a number*");
                       errors.estimation="Value must be a number";
                  }
                   else if(value.indexOf(".") !== -1)
                    {
                    
                        var pattern = /^\d{0,2}(\.\d{0,2})?h?$/;
                         if (!(pattern.test(value)))
                        {
                          $("#error-div-ehour").css("display", "flex");
                          $("#error-text-hour").html("Value should be in e.g. '12.38' format");
                          errors.estimation="Value should be in e.g. '12.38' format";
                        }
                    else{
                      $("#error-div-ehour").css("display", "none");
                    }
                    }
                  else {
                       if (/^\d+$/.test(value)&&value.length > 3)
                        {      
                          $("#error-div-ehour").css("display", "flex");
                          $("#error-text-hour").html("Only 3 digits allowed");
                          errors.estimation="Only 3 digits allowed";
                        }
                      else{
                      $("#error-div-ehour").css("display", "none");
                    }
                  }
                if(Object.keys(errors).length)
                {
                  return count=false;
                }
                else
                {
                  return count=true;
                }
              }
              function convertTimeToDecimal(time) {
                var timeArray = time.split(":");
                return parseFloat(timeArray[0]) + parseFloat(timeArray[1]) / 60;
              }
              window.saveHour = function (id) {
                // if (window.event.keyCode == 13) {
                  let estimated_hours = $("#input-value" + id).val();
                 if(validateEstimation(estimated_hours.trim()))
                  {
                    let Estimation=estimated_hours!=null?estimated_hours:0;         
                    if(timeFormat=="minutes")
                    {
                      if (typeof Estimation === 'string' && !Estimation.includes(':')) {
                        Estimation=convertToHHMM(Estimation)
                      }   
                    
                    }
                    else{
                      if(timeFormat=="decimal")
                      if (typeof Estimation === 'string' && Estimation.includes(':')) {
                        Estimation = convertTimeToDecimal(Estimation);
                        Estimation=Estimation.toFixed(2);
                      }
                     Estimation=Estimation;
            
                    }
                    var content = {
                      estimated_hours: Estimation,
                    };
                    $.ajax({
                      type: "PUT",
                      url:
                        self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                      dataType: "json",
                      async: false,
                      contentType: "application/json",
                      data: JSON.stringify({
                        issue: content,
                      }),
                      success: function (result, status, xhr) {
                        // $("#context-kanban" + id).css("display", "none");
                        // let back_div = document.getElementById("blur-div" + id);
                        // back_div.style.display = "none";
                        // location.reload();
                     
                        $("#Hour-div"+id).css("display", "none");
                        $("#hide-hour" + id).css("display", "flex");
  
                        $(".estimated-hour" + id).html(Estimation+"h");
                        $("#estimate-h" + id).html(Estimation+"h");
              
                      },
  
                      error: function (xhr, status, error) {
                        if (xhr.status == 422) {
                          $(".show-error" + id).css("display", "none");
  
                          let content = JSON.parse(xhr.responseText).errors;
                          // console.log(content);
                          toastr["error"](content);
  
                          //  console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                        }
                      },
                    });
                  }
              };
  
              window.closeWatchers = function (id) {
                $("#search-user-id" + id).val(" ");
                $("#watcher-div-dynamic" + id).html(" ");
                $(".context-menu-popup").css("zIndex", "9999");
                let watcher_div = document.getElementById(
                  "watcher-dialog-backdrop" + id
                );
                let open_Watchers_div = document.getElementById(
                  "Watchers-dialog" + id
                );
                watcher_div.style.display = "none";
                open_Watchers_div.style.display = "none";
                $("[tabindex='-1']").attr("tabindex", 0);
              };
  
              window.AddWatchers = function (id) {
                 var checkboxes = document.querySelectorAll('div.random-div > div:nth-child(1) > input#watchers-input');
                  var watcherboxids = [];
  
                 for (var i = 0; i < checkboxes.length; i++) {
                   if (checkboxes[i].checked ) {
                    watcherboxids.push({"id": checkboxes[i].value, "name": checkboxes[i].name});
                    
                   }             
                }
                watcherboxids.forEach((obj) => {
                  var found = watcher_array.some((item) => item.value === obj.value && item.name === obj.name);
                  if (!found) {
                    watcher_array.push(obj);
                  }
                });
               
  
                for (let i = 0; i < not_watcher.length; i++) {
                  for (let j = 0; j < watcherboxids.length; j++) {
                    if (not_watcher[i].value === watcherboxids[j].value && not_watcher[i].name === watcherboxids[j].name) {
                      not_watcher.splice(i, 1);
                      i--;
                      break;
                    }
                  }
                }
    
                $(".array-watchers").removeClass("overflow-auto");
                $(".context-menu-popup").css("zIndex", "9999");
                var checkedInputs = $("input[id='watchers-input']:checked");
                if (checkedInputs.length > 0) {
                $.each($("input[id='watchers-input']:checked"), function () {
                  $.ajax({
                    type: "POST",
                    url:
                      self.url +
                      "/issues/" +
                      id +
                      "/watchers.json?key=" +
                      api_key +
                      " ",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      user_id: parseInt($(this).val()),
                    }),
                    success: function (result, status, xhr) {
                      // console.log(user_id,'result for selected watcher');
                      let watcher_div = document.getElementById(
                        "watcher-dialog-backdrop" + id
                      );
                      let open_Watchers_div = document.getElementById(
                        "Watchers-dialog" + id
                      );
                      watcher_div.style.display = "none";
                      open_Watchers_div.style.display = "none";
                      $("#search-user-id" + id).val(" ");
  
                      $.ajax({
                        type: "GET",
                        url:
                          self.url +
                          "/issues/" +
                          id +
                          ".json?include=watchers&&key=" +
                          api_key +
                          " ",
                        dataType: "json",
                        contentType: "application/json",
                        success: function (result, status, xhr) {
                          $("#watcher-div-dynamic" + id).html(" ");
                          let div = $("#watcher-div" + id);
                          if (result.issue.watchers&&result.issue.watchers.length > 15) {
                            $(".array-watchers").addClass("overflow-auto");
                          } else {
                            $(".array-watchers").removeClass("overflow-auto");
                          }
                          if (result.issue.watchers) {
                            // $("#watcher-div" + id).css("display", "flex");
                            $("#watcher-div" + id).html(" ");
                            let content = result.issue.watchers;
                            
                            content.forEach((p) => {
                              $("#watcher-div" + id).append(`<div id="watcher${p.id}">
                               <ul class="member-tag-box">
                                <li class='members-tag'>
                                <span class='members-name'>${p.name}</span>
                                <span onclick="openWatcherDelete(${id},${p.id} ,'${p.name}')" style="${delete_issue_watchers?'display:flex':'display:none'}; margin-top: -1px; margin-left: 8px; cursor:pointer;" class="member-tag-close"><i  style="font-size:12px; color:gray; " class="fa-solid fa-xmark close-icon-kanban"></i></span>
                                </li>
                               </ul>
                               </div>`);
  
                                  //  for permission
                
                             
                            });
                          }
                          //closePopup(id);
                          openPopup(id);
                        },
                        error: function (xhr, status, error) {
                          // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                        },
                      });
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                });
              }
              else{
                $(".context-menu-popup").css("zIndex", "1040");
              }
              };
              window.SearchUser = function (id, project_data) {
                let query_string = $("#search-user-id" + id).val();
                const params = window.location.search;
                const parameters = new URLSearchParams(params);
                const project_id = parameters.get("project_id");
                if (query_string.length != 0) {
                  $.ajax({
                    type: "GET",
                    url: self.url + `/search_users.json?key=${api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: {
                      name: query_string.trim(),
                      issue_id:id
                    },
                    success: function (result, status, xhr) {
                      $("#watcher-div-dynamic" + id).html(" ");
                      if (Array.isArray(result) && result.length != 0) {
                        result.forEach((p) => {
                          $("#watcher-div-dynamic" + id)
                            .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
                      <div  style="display:flex;" >
                         <input class="watch-input" id="watchers-input"  name=${p.firstname + " " + p.lastname
                              } value=${p.id} type="checkbox"/>
                       </div>
                       <div style="display:flex;">
                         <span class="span-watcher">${p.firstname + " " + p.lastname
                              }</span>
                         </div>
                         </div> 
                         `);
                        });
                      } 
                    },
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                } else {
                  // $.ajax({
                  //   type: "GET",
                  //   url: self.url + "/projects/" + project_data + "/actived_users.json?id="+ project_data +"&&key=" + api_key + "",
                  //   dataType: "json",
                  //   // async: false,
                  //   id : project_data ,
                  //   success: function(result, status, xhr) {
      
                  //     content = result.active_users;
                  //     if (content.length != 0 && watcher_array.length == 0 && not_watcher == 0 ) {
  
                  //       content.forEach((p) => {
  
                  //         $("#watcher-div-dynamic" + id)
                  //         .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
                  //           <div  style="display:flex;" >
                  //           <input class="watch-input" id="watchers-input"  name="${p.name}" value="${p.id}" type="checkbox"/>
                  //           </div>
                  //           <div style="display:flex;">
                  //           <span class="span-watcher">${p.name}</span>
                  //           </div>
                  //           </div> 
                  //           `);
                  //       })
                  //     }
                  var not_watcher=[];
                   not_watcher = all_watcher.filter(function(user) {
                    // Filter out the students who passed the exam
                    return !watcher_array.some(function(watcher_id) {
                      return user.id === watcher_id.id;
                    });
                  }); 
              
                      $("#watcher-div-dynamic" + id).html(" ");
                    if (not_watcher.length != 0){
                      
                      not_watcher.forEach((p) => {
                  
                          $("#watcher-div-dynamic" + id)
                          .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
                          <div  style="display:flex;" >
                          <input class="watch-input"  id="watchers-input"  name="${p.name}" value="${p.id}" type="checkbox"/>
                          </div>
                          <div style="display:flex;">
                          <span class="span-watcher">${p.name}</span>
                          </div>
                          </div> 
                    `);
                        
              
                  })
                    }
                          
                  //   },
  
                  //   error: function (xhr, status, error) {
                  //     // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  //   },
                  // });
                }
  
             
              };
              window.showWatcher = function (id, project_data) {
                window.event.preventDefault();
                $(".context-menu-popup").css("zIndex", "1040");
                let watcher_div = document.getElementById(
                  "watcher-dialog-backdrop" + id
                );
                let open_Watchers_div = document.getElementById(
                  "Watchers-dialog" + id
                );
                if (watcher_div) {
                  watcher_div.style.display = "block";
                  open_Watchers_div.style.display = "block";
                } else {
                  $(".context-menu-popup").css("zIndex", "1040");
                //   let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                  let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                  if(self.options.element==="#version-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                  }
                  else if(self.options.element === "#sprint-board")
                  {
                    body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                  }
                  let div = document.createElement("div");
                  div.id = "watcher-dialog-backdrop" + id;
                  div.className = "watcher-dialog-backdrop";
                  div.style.display = "block";
                  body_div[0].appendChild(div);
                  var menu = document.createElement("div" + id);
                  menu.className = "Watch-dialog";
                  menu.id = "Watchers-dialog" + id;
                  menu.innerHTML = `
                  <div class="time-tracking-div${id}">
                  <h4 class="heading-time" style="color:black; font-size:20px !important; margin-bottom:20px; border-bottom:none; font-weight: normal !important; font-family:Roboto,Arial,sans-serif !important;" >Add Watchers</h4>
  
                  <div style="display:flex; flex-direction:column;">
                    <div  style="display:flex; margin-bottom:7px;">
                    <label style="font-weight: normal !important; font-family:Roboto,Arial,sans-serif !important;" >Search for user:</label>
                     </div>
                     <div  style="display:flex;">
                     <input id="search-user-id${id}" onkeyup="SearchUser(${id},${project_data})" class="search-user" style="width:100%; height:35px;"/>
                      </div>
                    </div>
                    <div  id="watcher-div-dynamic${id}"class="user-watcher" style=" margin-top:18px;">
             
                    </div>
  
                  <div style="display:flex; justify-content:center; margin-top:40px; margin-bottom:10px;  cursor:pointer;" >
                  <div style="display:flex; justify-content:space-between; cursor:pointer">
  
                  <div  onclick="closeWatchers(${id})"  type="button"  style="display:flex; margin-right:15px; cursor:pointer">
                  <button style="cursor:pointer" class="button-close">Cancel
                   </button>
                   </div>
                  <div  onclick="AddWatchers(${id})" style="display:flex;    cursor:pointer;" >
                  <button   style="cursor:pointer" class="button-save">Add</button>
                  </div>
               
                
                 </div>
                 </div>
                  </div>
  
                  `;
                  body_div[0].appendChild(menu);
                }
                let div = $("#watcher-div-dynamic" + id);
                if (div[0].children.length == 0) {
  
  // ----
                $.ajax({
                    type: "GET",
                    url: self.url + "/projects/" + project_data + "/actived_users.json?id="+ project_data +"&&key=" + api_key + "",
                    dataType: "json",
                    // async: false,
                    id : project_data ,
                    success: function(result, status, xhr) {
      
                      content = result.active_users;
                        if (content.length != 0 && watcher_array.length == 0 && not_watcher == 0 ) {
  
                          content.forEach((p) => {
  
                            $("#watcher-div-dynamic" + id)
                            .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
                    <div  style="display:flex;" >
                    <input class="watch-input" id="watchers-input"  name="${p.name}" value="${p.id}" type="checkbox"/>
                    </div>
                    <div style="display:flex;">
                    <span class="span-watcher">${p.name}</span>
                    </div>
                    </div> 
                    `);
                          })
                        }
               
                //   if (watcher_array.length != 0){
                    
                //     watcher_array.forEach((p) => {
                //       $("#watcher-div-dynamic" + id)
                //       .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
                // <div  style="display:flex;" >
                // <input class="watch-input" checked="checked" id="watchers-input"  name="${p.name}" value="${p.id}" type="checkbox"/>
                // </div>
                // <div style="display:flex;">
                // <span class="span-watcher">${p.name}</span>
                // </div>
                // </div> 
                // `);
                //     })
                //   }
      
                if (not_watcher.length != 0){
                  
                  not_watcher.forEach((p) => {
                    $("#watcher-div-dynamic" + id)
                    .append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
              <div  style="display:flex;" >
              <input class="watch-input"  id="watchers-input"  name="${p.name}" value="${p.id}" type="checkbox"/>
              </div>
              <div style="display:flex;">
              <span class="span-watcher">${p.name}</span>
              </div>
              </div> 
              `);
              })
                }
                }
              });
  
              var not_watcher = all_watcher.filter(function(user) {
                // Filter out the students who passed the exam
                return !watcher_array.some(function(watcher_id) {
                  return user.id === watcher_id.id;
                });
              });     
                }
              };
              let view_issues=true;
              let add_issues=true;
              let edit_issues=true;
              let edit_own_issues=true;
              let delete_issues=true;
              let view_issue_watchers=true;
              let add_issue_watchers=true;
              let delete_issue_watchers=true;
              let log_time=true;
              let userAssignable=true;
  
               window.openSubject=function(id)
               {
                let input=document.getElementById(`subj-parent${id}`);
                let div=document.getElementById(`subjectDiv${id}`);
                 $("#input-field"+id).val(div.getAttribute("value"));
                div.style.display="none";
                input.style.display="flex";
                 
               }
        
              window.openPopup = function (id) {
                $(".scroll-card").removeClass("overflow-auto");
                var project_ID;
                var assigned_to_id;
                var done_ratio;
                var description;
                var watchers_length;
                var issue_start_date;
                var issue_due_date;
                var change_format_issue_start_date;
                var change_format_issue_due_date;
                var subject;
                var priority_id;
                var issue_detail=[];
                var author_id=null;
                var showModal=false;
                let tracker_id=null;
                var exiting_relation=[];
                $("#error-div-ehour").css("display", "none");
                $("#hide-hour" + id).css("display", "flex");
                $("#Hour-div" + id).css("display", "none");
                $(`#subj-parent${id}`).css("display","none");
                $(`#trackerSelect${id}`).css("display","none");
                $(`#prioritySelect${id}`).css("display","none");
                $(`#assineeSelect${id}`).css("display","none");
                $(`#percentSelect${id}`).css("display","none");
                $(`#editable_date_${id}`).css("display","none");
                $(`#editable_duedate_${id}`).css("display","none");
                $(`#subjectDiv${id}`).css("display", "flex");
                $(`#hide-tracker${id}`).css("display", "flex");
                $(`#hide-priority${id}`).css("display", "flex");
                $(`#hide-assignee${id}`).css("display", "flex");
                $(`#hide-percent${id}`).css("display", "flex");
                $(`#issue_data_${id}`).css("display", "flex");
                $(`#issue_data_due_${id}`).css("display", "flex");
                $("#error-div-subject").css("display","none");
                $( "#error-due"+id).css("display","none");
                $( "#error-start"+id).css("display","none");
  
               
                
                
                  $.ajax({
                  type: "GET",
                  url:self.url + "/issues/" + id + ".json?include=watchers,attachments,journals,relations,children,changesets&&key=" + api_key +  " ",
                  dataType: "json",
                  async: false,
                  contentType: "application/json",
                  success: function (result, status, xhr) {
            
                    watcher_array = result.issue.watchers;
                    issue_detail=result;
                    exiting_relation = issue_detail.issue.relations;
                    localStorage.setItem('exiting_relation', JSON.stringify(exiting_relation));
                   
                    author_id=result.issue.author.id;
                    if (result.issue.assigned_to) {
                      assigned_to_id = result.issue.assigned_to.id;
                    }
                    if(result.issue.priority)
                    {
                      priority_id=result.issue.priority.id
                    }
                    if (result.issue.done_ratio != null) {
                      done_ratio = result.issue.done_ratio;
                    }
  
                    if (result.issue.description != null) {
                      description = result.issue.description;
                    } else {
                      description = " ";
                    }
                    if (result.issue.watchers&&result.issue.watchers.length != 0) {
                      watchers_length = result.issue.watchers.length;
                    }
                    if(result.issue.subject !=null)
                    {
                      subject=result.issue.subject;
                    }
                    project_ID = result.issue.project.id;
  
                      if(result.issue.tracker)
                      {
                        tracker_id=result.issue.tracker.id;
                      }
              
                    if (result.issue.start_date != null) {
                      issue_start_date = result.issue.start_date;
  
                      window.changedateFormat = function (date) {
                        var change_date = new Date(date);
                        var dd = String(change_date.getDate()).padStart(2, "0");
                        var mm = String(change_date.getMonth() + 1).padStart(2, "0"); //January is 0!
                        var yyyy = change_date.getFullYear();
                        return (change_date = dd + "-" + mm + "-" + yyyy);
                      };
  
                      change_format_issue_start_date = changedateFormat(issue_start_date);
  
                    } 
                    else {
                      change_format_issue_start_date = " No data ";
                    }
                    if(result.issue.due_date != null)
                    {
                      issue_due_date = result.issue.due_date;
                
  
                      window.changedateFormat = function (date) {
                        var change_date = new Date(date);
                        var dd = String(change_date.getDate()).padStart(2, "0");
                        var mm = String(change_date.getMonth() + 1).padStart(2, "0"); //January is 0!
                        var yyyy = change_date.getFullYear();
                        return (change_date = dd + "-" + mm + "-" + yyyy);
                      };
  
                      change_format_issue_due_date = changedateFormat(issue_due_date);   
                    }
                    else{
                      change_format_issue_due_date = " No data ";
                    }
                    
  
                
  
                     if(checkAdmin==="false")
                     {
                           
                         view_issues=false;
                         add_issues=false;
                         edit_issues=false;
                         edit_own_issues=false;
                         delete_issues=false;
                         view_issue_watchers=false;
                         add_issue_watchers=false;
                         delete_issue_watchers=false;
                         log_time=false;
                         userAssignable=false;
                      //call another API for permission to show and hide options
                      $.ajax({
                        type: "GET",
                        url: `${url}/get/users/permissions.json?key=${api_key}`,
                        dataType: "json",
                        async: false,
                        data:{
                        project_id:  project_ID 
                        },
                        contentType: "application/json",
                        success:function(result,status,xhr)
                        {
                        // Extract unique permissions
                        const uniquePermissions = new Set(result.flatMap(role => role.permissions));
                        // console.log(result,"uniquePermissionsArray");
                        const issueSetting =result.map((role) => role.settings);
                  
                        const checkAssignable=result.map((role) => role.assignable);
                
  
                         // Convert the set back to an array if needed
                        const uniquePermissionsArray = [...uniquePermissions];
    
                        // Display the unique permissions
                       if(checkAssignable.includes("true"))
                        {
                        userAssignable=true;
                        }
                        if(uniquePermissionsArray.includes("view_issue_watchers"))
                        {
                          view_issue_watchers=true;
                        }
                        if(uniquePermissionsArray.includes("add_issue_watchers"))
                        {
                          add_issue_watchers=true;
                        } 
                        if(uniquePermissionsArray.includes("delete_issue_watchers"))
                        {
                          delete_issue_watchers=true;
                        }
                        if(uniquePermissionsArray.includes("log_time"))
                        {
                          log_time=true;
                        }
                    
                        if(uniquePermissionsArray.includes("add_issues"))
                        {
                           const checkTrackers =issueSetting[0].permissions_tracker_ids.add_issues.some(res => res == tracker_id);
                          if(issueSetting[0].permissions_all_trackers.add_issues=="0"&&checkTrackers)
                          {
                            add_issues=true;
                          }
                          else if(issueSetting[0].permissions_all_trackers.add_issues =="1")
                          {
                            add_issues=true;
                          }
                        }
                        if(uniquePermissionsArray.includes("view_issues"))
                        {
                         
                          const checkTrackers =issueSetting[0].permissions_tracker_ids.view_issues.some(res => res == tracker_id);
                          if(issueSetting[0].permissions_all_trackers.view_issues=="0"&&checkTrackers)
                          {
                            view_issues=true;
                          }
                          else if(issueSetting[0].permissions_all_trackers.view_issues =="1")
                          {
                            view_issues=true;
                          }
                        }
                        if(uniquePermissionsArray.includes("edit_issues"))
                        {
                          const checkTrackers =issueSetting[0].permissions_tracker_ids.edit_issues.some(res => res == tracker_id);
                          if(issueSetting[0].permissions_all_trackers.edit_issues=="0"&&checkTrackers)
                          {
                            edit_issues=true;
                          }
                          else if(issueSetting[0].permissions_all_trackers.edit_issues=="1")
                          {
                            edit_issues=true;
                          }
                          
                        }
                        if(uniquePermissionsArray.includes("delete_issues"))
                        {
                          const checkTrackers =issueSetting[0].permissions_tracker_ids.delete_issues.some(res => res == tracker_id);
                          if(issueSetting[0].permissions_all_trackers.delete_issues=="0"&&checkTrackers)
                          {
                            delete_issues=true;
                          }
                          else if(issueSetting[0].permissions_all_trackers.delete_issues =="1")
                          {
                            delete_issues=true;
                          }
                          
                        }
                    
                        if(uniquePermissionsArray.includes("edit_own_issues"))
                        {
                          edit_own_issues=true;
                        }
                    
                      }
                        
                      })
                    }
               
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
       
                //  console.log(self.options.element,"self element")
                let open_div = document.getElementById("context-kanban" + id);
                var kanban = document.getElementsByClassName("fields" + id);
                // let body_div=document.getElementsByClassName( "has-main-menu controller-agile action-index");
                let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                if(self.options.element==="#version-board")
                {
                  body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-index");
                }
                else if(self.options.element === "#sprint-board")
                {
                  body_div=document.getElementsByClassName("has-main-menu controller-agile_versions  action-sprints");
                }
   
                  if(edit_issues===true&&(edit_own_issues===false||edit_own_issues===true))
                  {
                    showModal=true;
            
                  }
                 if(edit_issues===false&&edit_own_issues===true&&author_id==user_id)
                  {
                     showModal=true;
                  }
        
                    if(showModal==true)
                    {
                    let back_div = document.getElementById("blur-div" + id);
                   if (back_div) {
                  back_div.style.display = "block";
                  open_div.style.display = "block";
                  $(".array-watchers").removeClass("overflow-auto");
                  $(".scroll-card").removeClass("overflow-auto");
                  if (watchers_length > 15) {
                    $(".array-watchers").addClass("overflow-auto");
                  } else {
                    $(".array-watchers").removeClass("overflow-auto");
                  }
                  if (description.length > 1000) {
                    $(".scroll-card").addClass("overflow-auto");
                  } else {
                    $(".scroll-card").removeClass("overflow-auto");
                  }
                } else {
                  console.log(description,"description....")
                  let div = document.createElement("div");
                  div.className = "body-div";
                  div.style.display = "block";
                  div.id = "blur-div" + id;
                  body_div[0].appendChild(div);
                  var context_menu = document.createElement("div" + id);
                  context_menu.className = "context-menu-popup";
                  context_menu.id = "context-kanban" + id;
                  console.log(assigned_to_id,"description after");
                  context_menu.innerHTML = `
            <div>
             <div style="display:flex; justify-content:space-between">
               <div  style="display:flex">
               <h4  style="color:black; font-weight:normal !important;" class="heading-edit-issue" >Edit Issue-${id}</h4>
               </div>
               <div   style="display:flex; cursor:pointer; justify-content:space-between; gap:18px;"> 
  
               <div  type="button" data-toggle="tooltip" title="Log Time"  onclick="openDialogTimeTracking(${id} , ${project_ID})"  style="${log_time?'display:flex':'display:none'}; cursor:pointer;">
               <span><i  style="font-size:15px; color:gray; margin-top:5px; " class="fa-solid fa-clock close-icon-kanban"></i></span>
                 </div>
  
               <div   onclick="openDialogDelete(${id})" style="${delete_issues?'display:flex':'display:none'}; cursor:pointer;"   type="button"  data-toggle="tooltip" title="Delete">
               <span><i    style="font-size:14px; margin-top:5px; color:gray;"  class="fa-solid fa-trash close-icon-kanban"></i></span>
                </div>
  
                <div  type="button" data-toggle="tooltip" title="Close"  onclick="closePopup(${id})" style="display:flex; cursor:pointer;">
               <span><i  style="font-size:20px; color:gray; margin-top:2px; " class="fa-solid fa-xmark close-icon-kanban"></i></span>
                 </div>
                </div>
              </div>
       
              <div class="editDiv" style="display:flex; flex-direction:column;">
              <div  style="display:flex; flex-direction:column;">
                 <div style="display:flex;">
                 <label class="agile_popup_label"  style="margin-bottom:8px; margin-top:16px;" >Subject <span class="required">*</span></label>
                 
                </div>
                <div onclick="openSubject(${id})" style="display:flex;">
                 <div  id="subjectDiv${id}" value=${subject.split(" ").join("&nbsp;")}  class="subject-span">${subject.split(" ").join("&nbsp;")}</div>
                 </div>
                   <div id="subj-parent${id}" style="display:none; flex-direction:row; flex-grow:1; gap:5px;">
                   <div style="display:flex; flex-direction:column; flex-grow:1;">
                      <div style="display:flex;">
                      <input  class="input-sub input-kanban" type="text"  id="input-field${id}" value=${subject.split(" ").join("&nbsp;")} />
                      </div>
                     </div>
                     <div style="display:flex; justify-content:center; align-items:center;">
                         <a onclick="handleSubmit(${id})" id="handle-start-date"class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
                     </div>
                     <div style="display:flex; justify-content:center; align-items:center;">
                       <a  onclick="closeSubject(${id})" id="handle-subject" class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
                     </div>
                   </div>
                </div>
                <div id="error-div-subject" style="display:none;">
                <div style="margin-top:3px" class="error" id="error-subject" > </div>
              </div>
             
              <div style="display:flex">
              <label class="agile_popup_label"  style="margin-bottom:8px; margin-top:16px;" >Description</label>
              </div>
              <div id ="hide-div${id}" onclick="openTextbox(${id})" style="display:flex">
              <div  style="display:flex; align-items:center; background: aliceblue" class="hover-div-desc">
              <div class="card-array scroll-card" id="show-desc${id}" style="color:gray; font-weight: normal !important; font-family: Roboto,Arial,sans-serif !important;"> </div>
              </div>
              </div>
              <div id="textbox-div${id}" style="display:none; flex-direction:column">
              <div class = "text-divv">    
              <div id="desc-field${id}" class="text-des">${description}</div>
              </div>
              <div id="error-div-desc${id}" style="display:none;" >
                <p id="error-text-desc${id}" class="error" ></p>
              </div>
              <div style="display:flex; justify-content:start; margin-top:8px; cursor:pointer;" >
              <div style="display:flex; justify-content:space-between; cursor:pointer">
  
              <div type="button" onclick="closetextBox(${id})" style="display:flex; margin-right:15px;  cursor:pointer">
              <button style="cursor:pointer" class="button-close">Cancel
               </button>
               </div>
              <div style="display:flex; cursor:pointer;" >
              <button  onclick="saveDescription(${id})" style="cursor:pointer" class="button-save">Save</button>
              </div>
        
             </div>
              </div>
              </div>
             
  
                <div class="main_div" >
                <div class="first_split">
  
              <div class="first_split_div" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"   >Tracker</label>
              </div>
              <div onclick="showTracker(${id},${project_ID})" id="hide-tracker${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="tracker-name${id}" style="font-weight:normal; cursor: pointer; font-size:13px;">Tracker name</label>
              </div>
              <div id="trackerSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="assignee-block" style="display:flex; ">
              <select   class="tracker${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
               <a onclick="handleSubmitT(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
               </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closeTracker(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
              <div class="first_split_div" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"   >Priority</label>
              </div>
              <div onclick="showPriority(${id})" id="hide-priority${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="priority-name${id}" style="font-weight:normal; cursor: pointer; font-size:13px;">Pirority name</label>
              </div>
              <div id="prioritySelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="assignee-block" style="display:flex; ">
              <select   class="priority${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
              <a onclick="handleSubmitP(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
              </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closePriority(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
              <div class="first_split_div author_field" style="padding: 5px 5px 5px 0px;" > 
              <div  style="display:flex" >
              <label  class="agile_popup_label"   > Author </label>
              </div>
              <div style=" align-items:center; width:auto !important;">
               <label class="author_name_${id} hover-div" style="font-weight:normal; font-size:13px;">  </label> 
               </div>
              </div>
  
  
  
              <div class="first_split_div" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"  > Category </label>
              </div>
              <div onclick="showCategroy(${id},${project_ID})" id="hide-categroy${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="category_name_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label> 
              </div>
              <div id="CategroySelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="categroy-block" style="display:flex; ">
              <select   class="categroy${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
               <a onclick="saveCategroy(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
               </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closeCategory(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
              
              <div class="first_split_div" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"  > Target Version </label>
              </div>
              <div onclick="showversion(${id},${project_ID})" id="hide-version${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="version_name_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label> 
              </div>
              <div id="VersionSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="version-block" style="display:flex; ">
              <select   class="version${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
               <a onclick="saveVersion(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
               </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closeVersion(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
              <div class="first_split_div" style="display:none;" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"  > Status </label>
              </div>
              <div onclick="showstatus(${id},${project_ID})" id="hide-status${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="status_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label>  
              </div>
              <div id="StatusSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="status-block" style="display:flex; ">
              <select   class="status${id}"  style="width:100%; height:28px !important"  >
  
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
              <a onclick="saveStatus(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closeStatus(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
              </div>
              </div>
              </div>
  
  
  
  
              <div id="tag_div${id}" class="first_split_div tag_field_div" style="display:none;" > 
              <div  style="display:flex" >
              <label  class="agile_popup_label"  > Tags </label>
              </div>
              <div class="tags_value" >
               <label class="tags_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;"></label> 
               <button class="add-tag-button icon icon-add agile_button" onclick="openTagDialog(${id})">Add</button>
               </div>
               <div class='tag_edit${id}' style='display: none;' >  </div>
              </div>
  
  
  
  
              <div class="first_split_div attachment_field_div" >          
              <div  style="display:flex" >
              <label  class="agile_popup_label"   > Files </label>
              </div>           
              <div class="attachment_files" >
               <label class="files_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label> 
                <button  onclick="add_attachment(${id})" class="icon icon-add agile_button"> Add </button>
                </div>            
                </div>              
                <div id="new-attachments" class="new_attachment_${id}" style="display:none;" >        
                    <span class="attachments_form">
                      <span class="attachments_fields">
                      </span>
                      <span class="add_attachment" style="">
                           <input type="file" name="attachments[dummy][file]" class="agile_file file_selector filedrop" multiple="multiple" onchange="handleFileSelect(event, ${id});" data-max-number-of-files-message="This file cannot be uploaded because it exceeds the maximum number of files that can be attached simultaneously (10)" data-max-file-size="5242880" data-max-file-size-message="This file cannot be uploaded because it exceeds the maximum allowed file size (5 MB)" data-max-concurrent-uploads="2" data-upload-path="/uploads.js" data-param="attachments" data-description="true" data-description-placeholder="Optional description">
                      </span>
                    </span>        
                    </div>
  
                    <div class="err_attachment" id="error_attachment${id}" style="display:none; margin-top:2px; ">
                    <div class="error error_attachment_${id}"> <span> File exceeds maximum allowed size (5 MB)</span> </div>
                   </div>
        
              
  </div>
  
  <div class="second_split">
  
  
              <div class="story_points_field${id} second_split_div story_field_div"  > 
              <div  style="display:flex" >
              <label  class="agile_popup_label"  > Story Points </label>
              </div>
              <div onclick="show_Story_points(${id},${project_ID})" id="hide_Story_points${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="story_points_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;"> No value  </label> 
              </div>
              <div id="Story_pointSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="story_point_block" style="display:flex; ">
              <select   class="story_point${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
               <a onclick="save_story_point(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
               </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="close_story_point(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
  
              <div class="second_split_div assignee_field_div" > 
              <div  style="display:flex">
              <label  class="agile_popup_label"   >Assignee</label>
              </div>
              <div onclick="showAssignee(${id},${project_ID})" id="hide-assignee${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
              <label class="assignee-name${id}" style="font-weight:normal; cursor: pointer; font-size:13px;">Assignne name</label>
              </div>
              <div id="assineeSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="assignee-block" style="display:flex; ">
              <select   class="assignee${id}"  style="width:100%; height:28px !important"  >
           
              </select>
              </div>
  
              <div style="display:flex; justify-content:center; align-items:center;">
                 <a onclick="saveAssignee(${id})" id="handle-start-date" class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
                </div>
               <div style="display:flex; justify-content:center; align-items:center;">
                <a  onclick="closeAssignee(${id})" id="handle-start-date" class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
               </div>
            </div>
              </div>
  
           <div class="second_split_div done_field_div"> 
              <div style="display:flex">
              <label   class="agile_popup_label"  >Done(%)</label>
              </div>
              <div onclick="showPercent(${id})" id="hide-percent${id}" class="hover-div" style="display:flex; cursor: pointer;  align-items:center; width:auto !important; ">
              <div class="done-ratio${id}" style="font-weight:normal; font-size:13px;"></div>
              </div>
              <div id="percentSelect${id}" style="display:none; flex-direction:row; gap:5px;">
              <div class="assignee-block edit_block_done">
              <select   class="percent${id}"  style="width:100%; height:28px !important"  >
              </select>
              </div>
              <div style="display:flex; justify-content:center; align-items:center;">
              <a onclick="savePercent(${id})"  id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
             </div>
              <div style="display:flex; justify-content:center; align-items:center;">
              <a  onclick="closeDoneRatio(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
             </div>
            </div>
             </div>
             
  
             <div class="second_split_div start_date_field" id="sdate-agile"   >
             <div style="display:flex" >
             <label class="agile_popup_label" > Start date </label></div>
             <div style="font-size: 13px; cursor: pointer;">
             <div  id="issue_data_${id}" value=${issue_start_date}   onclick="changeStartData(${id})" style="margin:0px;">${change_format_issue_start_date} </div>
             <span    style="display:none ; margin-top: -4px;" class="edit_block_start_date" id="editable_date_${id}">
             <input   value=${issue_start_date}     id="start-dates${id}"  class="startDate${id} input-kanban start-date-input" size="10" type='date' style = "height:23px !important; margin-right: 5px;" > 
                   <a onclick="finalsubmit(${id})" id="handle-due-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
                  <a  style="margin-left:2px;"  onclick="handleCloseDate(${id})" id="handle-start-date"  class="btn btn-primary close-pop" aria-label="Validate the modification"><i   style="font-size:14px"  class="fa-solid fa-xmark close-icon-kanban"></i></a> 
             </span>
             </div></div>
  
             <div class="err-start" id="error-start${id}" style="display:none; margin-top:2px; ">
             <div class="error error-startDate${id}"></div>
            </div>
              
             <div id="ddate-agile" class="second_split_div due_date_field"  >
             <div style="display:flex" >
              <label class="agile_popup_label" > Due date </label>
             </div>
             <div style="display:flex; flex-direction:column; font-size: 13px; cursor: pointer;">
               <div style="display:flex;"  value=${issue_due_date} id="issue_data_due_${id}" onclick="changeDueDate(${id})" style="margin:0px;">${change_format_issue_due_date} </div>
            
                 <span    style="display:none ; margin-top: -4px;" id="editable_duedate_${id}" class="edit_block_due_date">
                   <input value=${issue_due_date}     id="due-dates${id}"  class="dueDate${id} input-kanban start-date-input" size="10" type='date' style = "height:23px !important; margin-right: 5px;"> 
                   <a onclick="finalsubmitDueDate(${id})" id="handle-due-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
                   <a style="margin-left:2px;" onclick="handleCloseDueDate(${id})" id="handle-start-date" class="btn btn-primary close-pop" aria-label="Validate the modification"><i   style="font-size:14px"  class="fa-solid fa-xmark close-icon-kanban"></i></a> 
                 </span>
          
              </div>
         </div>
                <div class="err-due" id="error-due${id}" style="display:none; margin-top:2px; ">
                 <div class="error error-dueDate${id}"></div>
                </div>
  
             <div class="estimated-div second_split_div" > 
             <div style="display:flex">
              <label class="agile_popup_label"  >Estimated Hours</label>
             </div>
             <div onclick="showHour(${id})" id="hide-hour${id}" class="hover-div" style="display:flex; cursor: pointer; align-items:center; width:auto !important;">
             <label class="estimated-hour${id}" style="font-weight:normal; cursor: pointer; font-size:12px;"></label>
             </div>
             <div id="Hour-div${id}" style="display:none; width:auto;   flex-direction:row; gap:5px;">
             <div style="display:flex;">
               <input id="input-value${id}" class="input-hour edit_estimated" style="height:23px"  size="9"/>
               </div>
  
               <div style="display:flex; justify-content:center; align-items:center;">
               <a onclick="saveHour(${id})" id="handle-start-date"  class="btn btn-primary validate" aria-label="Validate the modification"><i class="fa-solid fa-check right-icon-kanban"></i></a>
              </div>
               <div style="display:flex; justify-content:center; align-items:center;">
               <a  onclick="closeEstimatedHour(${id})" id="handle-start-date"   class="btn btn-primary close-pop" aria-label="Validate the modification"><i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i></a> 
              </div>
             </div>
            </div>
             <div  id="error-div-ehour" style="display:none;">
            <p  class="error" id="error-text-hour" style=" margin-left:139px; margin-bottom: 0px !important;"></p>
            </div>
  
            
            
  
            <div class="second_split_div sub_task_field_div" > 
            <div  style="display:flex" >
            <label  class="agile_popup_label"  > Sub Task </label>
            </div>
            <div class="sub_task_values">
            <label class="sub_task_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label> 
            <a href="/projects/${project_ID}/issues/new?issue[parent_issue_id]=${id}"> <button  class="icon icon-add agile_button"> Add </button></a>
            </div>
            </div>
  
  
  
  
  
              <div class="second_split_div related_div_field"  > 
              <div  style="display:flex" >
              <label  class="agile_popup_label"   > Related issues </label>
              </div>
              <div class="related_issue_values">
               <label class="releated_issues_${id} hover-div" style="font-weight:normal; cursor: pointer; font-size:13px;">  </label> 
               <div class="render_new_relation"> <button class="icon icon-add agile_button"  onclick="add_relation(${id} , ${project_ID})">Add</button></div>
              
               </div>
              </div>
              <div id="relation_form_container" class="new_relation_form${id}" style="display:none;"></div>
              <div class="flash error issue_relation_error_message" id="flash_error" style="display: none"></div>
  </div></div>
  
  
         <div style="${add_issue_watchers&&view_issue_watchers?'display:flex':'display:none'};  flex-direction:column;  margin-top:11px;"> 
          <div class="watcher-div" style="display:flex; flex-direction:row;  gap:28px;"> 
             <div style="${add_issue_watchers&&view_issue_watchers?'display:flex':'display:none'};">
             <label  class="agile_popup_label" >Watchers</label> 
  
            </div>
            <div   value=${project_ID} onclick="showWatcher(${id},${project_ID})" id="hide-watcher${id}"  style="display:flex; align-items:center; color:rgb(85,120,235); cursor:pointer;">
            <div id="plus-watcher-icon${id}" style="${add_issue_watchers?'display:flex':'display:none'}; font-weight:600; font-size:13px;"><i style="margin-top: 2px; margin-right:7px; color:rgb(85,120,235)" class="fa-solid fa-plus close-icon-kanban"></i><span>Search for watchers to add</span></div>
            
            </div>
               </div>
  
             
            </div>
                <div class="watcher-div" style="display:flex; flex-direction:row;  gap:28px; margin-top:9px;"> 
                <div style="${!add_issue_watchers&&view_issue_watchers?'display:flex':'display:none'}; align-items:center;">
                 <label  class="agile_popup_label">Watchers</label>
                </div>
            
                <div class="watcher-d array-watchers"  style="${add_issue_watchers||view_issue_watchers?'display:flex':'display:none'}; margin-top:-5px; flex-wrap:wrap;"  id="watcher-div${id}">
                </div>
          
            </div>
  
           </div>
  
           <div class="notes_and_comments_${id}">
  
           </div>
  
                </div>`;
                  body_div[0].appendChild(context_menu);
                  $(".array-watchers").removeClass("overflow-auto");
                  $(".scroll-card").removeClass("overflow-auto");
                  // console.log(description, "descitip");
                  if (description.length > 1000) {
                    $(".scroll-card").addClass("overflow-auto");
                  } else {
                    $(".scroll-card").removeClass("overflow-auto");
                  }
                  if (watchers_length > 15) {
                    $(".array-watchers").addClass("overflow-auto");
                  } else {
                    $(".array-watchers").removeClass("overflow-auto");
                  }
                  document
                    .querySelectorAll(".ui-dialog-titlebar")
                    .forEach((res) => {
                      res.setAttribute("id", "dialog-kanban");
                    });
                  document
                    .querySelectorAll(".ui-dialog .ui-dialog-content")
                    .forEach((res) => {
                      res.setAttribute("class", "dialog-body-kanban");
                    });
                  // back_div.style.display="block";
                }
                    }
              
          
              else{
                toastr["error"]("You don't have permissions to edit this issue");
              }
  
              
                //  API to show all watchers...
                $.ajax({
                  type: "GET",
                  url: self.url + "/projects/" + project_ID + "/actived_users.json?id="+ project_ID +"&&key=" + api_key + "",
                  dataType: "json",
                  async: false,
                  id : project_ID ,
                  success: function(result, status, xhr) {
                    all_watcher = result.active_users;
                  }
                  
                });
                
              
  
                // $.ajax({
                //   type: "GET",
                //   url:self.url + "/issues/" + id + ".json?include=watchers&&key=" + api_key + " ",
                //   dataType: "json",
                //   async: false,
                //   contentType: "application/json",
                //   success: function (result, status, xhr) {
               
                    let result=issue_detail;
                
                
                // -------------author name ---------------
  
                    var author_name = issue_detail.issue.author.name                 
                     $('.author_name_' + id).html(author_name);
                // --------------------category_name ---------------
  
                     var category_name = issue_detail.issue.category
                    //  console.log(category_name,"categories name");
                     if(category_name){
                      $('.category_name_' + id).html(category_name.name);
                     }
                     else {
                      $('.category_name_' + id).html("-");
                     }
                    //  ----------------target version-------------
                     var target_version = issue_detail.issue.fixed_version
                    //  console.log(target_version,"target version ");
                     if(target_version){
                      $('.version_name_' + id).html(target_version.name);
                     }
                     else {
                      $('.version_name_' + id).html("-");
                     }
                    //  -----------sub task ----------------
                    //  var sub_task = issue_detail.issue.children
                    // //  console.log(sub_task,"sub task ");
                    //  if(sub_task && sub_task.length > 0 ) {
                    //   var subTaskList = $('<ul class ="sub_task_ul">');
                    //   sub_task.forEach(function(task) {
                    //     var listItem = $('<li class="sub_task_li" id="sub_task_' + task.id + '" >').html('<div class="sub_task_issue"> <a href="/issues/' + task.id + '">' + task.tracker.name + ' #' + task.id + '</a> ' + task.subject + '</div> <div class="delete_sub_task icon-only icon-del" onclick="delete_sub_task(' + task.id + ')"> </div>'); 
                    //     subTaskList.append(listItem);
                        
                    // });
  
                    //   $('.sub_task_' + id).html(subTaskList);
                    //  }
                    //   else {
                    //   $('.sub_task_' + id).html("");
                    //   }
                    function generateSubTaskHTML(task) {
                      var listItem = $('<li class="sub_task_li" id="sub_task_' + task.id + '">').html('<div class = "div_subtasks"><div class="sub_task_issue"> <a href="/issues/' + task.id + '">' + ' #' + task.id + '</a> ' + task.subject + '</div> <div class="delete_sub_task icon-only icon-del" onclick="delete_sub_task(' + task.id + ')"> </div></div>');
                     
                      if (task.children && task.children.length > 0) {
                          var subTaskList = $('<ul class="sub_task_ul">');
                          task.children.forEach(function(subTask) {
                              var subTaskItem = generateSubTaskHTML(subTask);
                              subTaskList.append(subTaskItem);
                          });
                          listItem.append(subTaskList);
                      }
                     
                      return listItem;
                  }
                 
                  var sub_task = issue_detail.issue.children;
                 
                  if (sub_task && sub_task.length > 0) {
                      var subTaskList = $('<ul class="sub_task_ul">');
                      sub_task.forEach(function(task) {
                          var listItem = generateSubTaskHTML(task);
                          subTaskList.append(listItem);
                      });
                     
                      $('.sub_task_' + id).html(subTaskList);
                  } else {
                      $('.sub_task_' + id).html("");
                  }
                      // -----------------attechment div ---------------
  
                      var attachments = issue_detail.issue.attachments
                      // console.log(attachments,"attachments");
                      if(attachments && attachments.length > 0) {
                        var attachment_List = $('<ul class ="attachment_ul">');
                        attachments.forEach(function(file){
                        //  var attachment_item = $('<li class="attachment_li" id="attachments_'+ file.id + '" >  </li>').html(`<span class="icon icon-attachment attachment_file_name" >` + file.filename + `</span> <a class="icon-only icon-download" href="/attachments/download/`+ file.id +`/`+ file.filename +`" > </a> <a class="delete icon-only icon-del" onclick="delete_attachment(`+ file.id +`)" > </a> `);
                        var attachment_item = $('<li class="attachment_li" id="attachments_'+ file.id + '" >  </li>').html(`<span class="icon icon-attachment attachment_file_name" >` + file.filename + `</span> <a class="icon-only icon-download" href="/attachments/download/`+ file.id +`/`+ file.filename +`" > </a> <a class="delete icon-only icon-del" onclick="openDialogDeleteAttachment(`+ id + `,` + file.id + `)" > </a> `);
                          attachment_List.append(attachment_item);
                        });
                        $('.files_' + id).html(attachment_List);
                      } else {
                        $('.files_' + id).html("");
                      }
            // ------------tag div ----------------
            if(tagPluginExists){
            fetchtags();
            // console.log(issue_tag,"issue tag");
            let textInput_val = [];
            issue_tag.map((tag)=>{
              if(tag.taggable_id==id)
              {
                var tag_div = $('<div class="tag_list">');
                tag.tag_list.map((list)=>{
        
                textInput_val.push(list.name);
                if (list.background_color == " "){
                var tag_item = $(`<span class="tag-span" id="tag_${list.id}" style="border:1px solid #505050; color:black; ">${list.name}</span>`)
                } else {
                var tag_item = $(`<span class="tag-span" id="tag_${list.id}" style="background-color:${list.background_color}; color:#333; ">${list.name}</span>`);
                }
                tag_div.append(tag_item);
                });
                $('.tags_' + id).html(tag_div);
              } 
                  
            });
            $('#tag_div' + id).css('display','flex');
  
            var tagEditFieldset = $('<fieldset class="box tag_box">');
            var issueTagsDiv = $(`<div id="issue_tags_${id}" class="tags_edit_box"></div>`);
  
              var textInput = $('<input type="text" id="updateissue_tag_list_agile" width="100%" multiple="true" size="30" placeholder="+ add tag">');
            textInput.val(textInput_val);
            issueTagsDiv.append(textInput);
            var tagEditButtonDiv = $('<div class="tagedit_button" style="display: inline-flex; justify-content: space-around; gap: 4px;"></div>');
            var saveButtons = $('<input type="submit" name="save_tag" id="save_tag" onclick="save_tag('+ id +')" value="Save">');
            var cancelButtons = $('<input type="submit" name="cancel" id="cancel_tag" onclick="close_tag('+ id +')" value="Cancel">');
            var saveButton = $('<button style="height: 28px;" type="submit" class="add_tag_button" name="save_tag" id="save_tag" onclick="save_tag(' + id + ')"><i class="fa-solid fa-check right-icon-kanban"></i></button>');
            var cancelButton = $('<button style="height: 28px;" class="tag_close_pop" id="cancel_tag" onclick="close_tag('+ id +')" value="Cancel" > <i style="font-size:14px" class="fa-solid fa-xmark close-icon-kanban"></i> </button>');

            
            tagEditButtonDiv.append(cancelButton);
            tagEditButtonDiv.append(saveButton);    
            tagEditFieldset.append(issueTagsDiv);
            tagEditFieldset.append(tagEditButtonDiv);
            
     
            $('.tag_edit' + id).html(tagEditFieldset);
           
            }
  
            window.openTagDialog = function (id) {
            $('.add-tag-button').parent().css('display', 'none');
            $('.tag_edit' + id).css('display', 'flex');
             initializeTagits(project_ID);
            }
  
            window.close_tag = function (id) {
            $('.add-tag-button').parent().css('display', 'flex');
            $('.tag_edit' + id).css('display', 'none');
            // initializeTagits(project_ID);
            setTimeout(function(){
              openPopup(id);     
            }, 10);
            }
  
            window.save_tag = function (id) {
              var all_tags = $('#issue_tags_' + id + ' input').val();
              // console.log(all_tags,"all tags"); 
  
  
              $.ajax({
                type: "POST",
                url: `${self.url}/update_issue_tags.json?key=${api_key}`,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({
                  id: id,
                  tag_list: all_tags        
                }),                    
                success: function (result, status, xhr) {
                  // console.log('succes the tag')
                  $('.add-tag-button').parent().css('display', 'flex');
                  $('.tag_edit' + id).css('display', 'none');
                  fetchtags();
                  if (!all_tags.trim()) {
                    $('.tags_' + id).empty();
                  } else {
                  // console.log(issue_tag,"issue tag");
                  let textInput_val = [];
                  issue_tag.map((tag)=>{
                    if(tag.taggable_id==id)
                    {
                      var tag_div = $('<div class="tag_list">');
                      tag.tag_list.map((list)=>{
                      // console.log(list,"list");
                      textInput_val.push(list.name);
                      if (list.background_color ==" "){
                        // console.log("no color");
                        var tag_item = $(`<span class="tag-span" id="tag_${list.id}" style="border:1px solid #505050; color:black; ">${list.name}</span>`)
                      } else {
                        var tag_item = $(`<span class="tag-span" id="tag_${list.id}" style="background-color:${list.background_color}; color:#333; ">${list.name}</span>`);
                      }
                      // var tag_item = $(`<span class="tag-span" id="tag_${list.id}" style="background-color:${list.background_color}; color:white; ">${list.name}</span>`);
                      tag_div.append(tag_item);
                      });
                      $('.tags_' + id).html(tag_div);
                    } 
                  });
                }
                }
              });
              // initializeTagits(project_ID);
              setTimeout(function(){
                openPopup(id);
              }, 10);
            }
  
        window.initializeTagits = function(project_id) {
        
          $('#updateissue_tag_list_agile').tagit({
            // tagSource: function(search, showChoices) {
            //   var that = this;
            //   $.ajax({
            //     url: '#{escape_javascript (auto_complete_issue_tags_path(' + project_id + '))}',
            //     data: {q: search.term},
            //     // dataType: 'json',
            //     success: function(choices) {
            //       console.log('Received choices:', choices);
            //       console.log('that:', that);
            //       showChoices(that._subtractArray(jQuery.parseJSON(choices), that.assignedTags()));
                  
                  
            //       try {
            //         var data = JSON.parse(choices);
            //         console.log(data,"data");
            //         var parsedChoices = jQuery.parseJSON(choices);
            //         showChoices(that._subtractArray(parsedChoices, that.assignedTags()));
            //       }
            //       catch (e) {
            //         console.log('error', e);
            //       }
  
            //     }
            //   });
            // },
            allowSpaces: true,
            placeholderText: 'Add Tags',
            autocomplete: true,
            caseSensitive: true,
            removeConfirmation: true,
            showAutocompleteOnFocus: true,
            tagLimit: 30,
          });
        }
  
  
  
  
            // ========================== status ===================
            var status = issue_detail.issue.status.name 
            if(status){
              $('.status_' + id).html(status);
            }
  
            // ------------story_points----------------------
            var story_points = issue_detail.issue.story_points
            if (story_points.id != null && story_points_enabled === "1" ){
              $('.story_points_' + id).html(story_points.id);
            }
            else{
              $('.story_points_' + id).html("-");
            }
           
            // -----------------------related issues ---------------------
  
            var related_issues = issue_detail.issue.relations
            // console.log(related_issues,"related issues");
            if(related_issues && related_issues.length > 0) {
            var relatedIssueList = $('<ul class ="related_issue_ul">');
            related_issues.forEach(function(issue) {
              if ( issue.relation_type == "precedes" && issue.issue_id == id && issue.delay != '0') {
                //precedes
               issue_html ='<span class="relation_type"> Precedes (' + issue.delay + ' days ) <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span>';
              }
              else if ( issue.relation_type == "precedes" && issue.issue_id == id && issue.delay == '0') {
                issue_html = '<span class="relation_type"> Precedes to <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if (issue.relation_type == "precedes" && issue.issue_to_id == id && issue.delay != '0') {
                //follows
                issue_html = '<span class="relation_type"> Follows (' + issue.delay + ' days ) <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span>';
              }
              else if (issue.relation_type == "precedes" && issue.issue_to_id == id && issue.delay == '0') {
                //follows
                issue_html = '<span class="relation_type"> Follows  <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "finish_to_start" || issue.relation_type == "finish_to_finish" || issue.relation_type == "start_to_finish" || issue.relation_type == "start_to_start") {
                issue_html = '<span class="relation_type">' + issue.relation_type + ' to <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "copied_to" && issue.issue_id == id) {
              issue_html = '<span class="relation_type"> Copied to <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "copied_to" && issue.issue_to_id == id) {
              issue_html = '<span class="relation_type"> Copied from <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "duplicates" && issue.issue_id == id) {
              issue_html = '<span class="relation_type"> Is ' + issue.relation_type + ' to <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "duplicates" && issue.issue_to_id == id) {
              issue_html = '<span class="relation_type"> Has ' + issue.relation_type + ' <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "blocks" && issue.issue_id == id) {
              issue_html = '<span class="relation_type"> Blocks <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "blocks" && issue.issue_to_id == id) {
              issue_html = '<span class="relation_type"> Blocked by <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else if ( issue.relation_type == "relates" && issue.issue_id == id) {
                issue_html = '<span class="relation_type">' + issue.relation_type + ' to <a href="/issues/' + issue.issue_to_id + '"> #' + issue.issue_to_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
              else {
                issue_html = '<span class="relation_type">' + issue.relation_type + ' to <a href="/issues/' + issue.issue_id + '"> #' + issue.issue_id + '</a> </span> <span class="icon icon-del delete_issue_relation" onclick="delete_relation('+ issue.id +',' + id +')"> </span> ';
              }
  
              var listItem = $('<li class="related_issue_li" id="related_issue_' + issue.id + '" >').html(issue_html);
              relatedIssueList.append(listItem);
            })
            $('.releated_issues_' + id).html(relatedIssueList);
            
            } else {
             $('.releated_issues_' + id).html(""); 
            }
            // --------------------notes and comments ------------------
            
            var issue_notes = issue_detail.issue.journals
            let Issue_notes_List = $('<div class ="notes_issue">');
            let issue_notes_heading = $('<div class="notes_heading_div"><h3 class="notes_heading">Notes and comments </h3> <button onclick="open_note_box('+ id +')" class="icon icon-add agile_button" id="add_notes" > Add </button> </div>');
            let issue_note_textarea = $('<div  name="issue[notes]" id="issue_notes_'+ id +'" style="display:none;"></div> <div class="notes_button" style="display:none;"> <button class="cancel_note button-close" onclick="cancel_note('+ id +')"> cancel </button> <button class="save_note button-save" onclick="save_note('+ id +')"> save </button>   </div>');
            Issue_notes_List.append(issue_notes_heading);
            Issue_notes_List.append(issue_note_textarea);
  
        
            if (issue_notes && issue_notes.length > 0) {
              let notesListDiv = $('<div class="notes_list"></div>');
              issue_notes.forEach((journal) => {
                if (journal.notes) {             
                    let notesDiv = $(`
                        <div id="change-${journal.id}" class="journal has-notes" style="">
                            <div id="note-${journal.id}" class="note">
                              
                                <h4 class="note-header">                            
                                ${journal.user ? `Updated by <a class="user active" href="/users/${journal.user.id}">${journal.user.name}</a>` : 'Updated by Anonymous'}                        
                                    <a title="${journal.created_on}" href="/projects/flux-development/activity?from=${journal.created_on}"></a>
                                    <span id="journal-${journal.id}-private_notes" class=""></span>
                                </h4>
                                <div id="journal-${journal.id}-notes" class="wiki" style="">${journal.notes}</div>
                            </div>
                        </div>  `);
  
                        
                        let html = textile.convert(journal.notes);
                        notesDiv.find(`#journal-${journal.id}-notes`).html(html);
                        
                        // Issue_notes_List.append(notesDiv);
                        notesListDiv.append(notesDiv);
                    
            }
          });
          Issue_notes_List.append(notesListDiv);
        }
        $(`.notes_and_comments_` + id).html(Issue_notes_List);
                      // ------------watcher div------------
              
                    let div = $("#watcher-div" + id);
       
                    if (result.issue.watchers&&result.issue.watchers.length) {
                      if (div[0].children.length == 0) {
                        // $("#watcher-div" + id).css("display", "flex");
                        let content = result.issue.watchers;
                        // watcher_array = result.issue.watchers;
                        content.forEach((p) => {
                          $("#watcher-div" + id).append(`<div id="watcher${p.id}">
                   <ul  class="member-tag-box">
                    <li class='members-tag'>
                    <span class='members-name'>${p.name}</span>
                    <span onclick="openWatcherDelete(${id}, ${p.id} , '${p.name}')" style="${delete_issue_watchers?'display:flex':'display:none'}; margin-top: -1px; margin-left: 8px; cursor:pointer;" class="member-tag-close"><i  style="font-size:12px; color:gray; " class="fa-solid fa-xmark close-icon-kanban"></i></span>
                    </li>
                   </ul>
                   </div>`);
                    
                  //  for permission
          
          
                        });
                      }
                    }
                    if (result.issue.assigned_to) {
                      $(".assignee-name" + id).html(
                        result.issue.assigned_to.name
                      );
                    } else {
                      $(".assignee-name" + id).html("Unassigned");
                    }
                    if(result.issue.tracker)
                    {
                      $(".tracker-name" + id).html(
                        result.issue.tracker.name
                      );
                    }
                    else{
                      $(".tracker-name" + id).html("No data");
                    }
                    if(result.issue.priority)
                    {
                      $(".priority-name" + id).html(
                        result.issue.priority.name
                      );
                    }
                    else{
                      $(".priority-name" + id).html("No data");
                    }
  
  
                    if (result.issue.done_ratio) {
                      $(".done-ratio" + id).html(result.issue.done_ratio + "%");
                    } else {
                      $(".done-ratio" + id).html("%");
                    }
               
            
                      let Estimation=result.issue.estimated_hours !=null?result.issue.estimated_hours:0;
                      if(timeFormat=="minutes")
                      {
                        Estimation=convertToHHMM(Estimation)
                      }
                      else{
                        if(Number.isInteger(Estimation))
                        {
                          Estimation=Estimation;
                        }
                        else{
                          Estimation=Estimation.toFixed(2);
                        }
             
                      }
                      $(".estimated-hour" + id).html(Estimation + "h");
               
                    if (result.issue.description) {
                      var value_text = textile.convert(result.issue.description);
                      $("#show-desc" + id).html(value_text);
                      $("#desc-field" + id).html(value_text);
                    } else {
         
                    }
                //   },
  
                //   error: function (xhr, status, error) {
                //     // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                //   },
                // });
            
  
    
                if ($('.context-menu-popup').is(':visible')) {
                  $(":tabbable").attr("tabindex", -1);
                  $(".context-menu-popup [tabindex='-1']").attr("tabindex", 0);
                  $("html").css("overflow", "hidden");
                  
                } else {
                  $("[tabindex='-1']").attr("tabindex", 0);
                  $("html").css("overflow", "auto");
                }
                // --- story points field in popup --
       
                var tracker_data = issue_detail.issue.tracker.id; 
                setTimeout(() => {
                  if (story_points_enabled === "1" || story_points_tracker == "") {
                    if (story_points_tracker == tracker_data) {
                      $(".story_points_field" + id).css("display", "flex");
                    } else {
                      $(".story_points_field" + id).css("display", "none");
                    }
                  } else {
                    $(".story_points_field" + id).css("display", "none");
                  }
                }, 100);
                // ---
              };
  
              window.updateTracker = function (id, project_id) {
           
                
                // $(".tracker" + id).html(" ");
                // var tracker_ID;
                // $(".show-error").css("display", "none");
                // $.ajax({
                //   type: "GET",
                //   url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                //   dataType: "json",
                //   async: false,
                //   contentType: "application/json",
                //   success: function (result, status, xhr) {
                //     tracker_ID = result.issue.tracker.id;
                //   },
  
                //   error: function (xhr, status, error) {
                //     // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                //   },
                // });
                // let select = document.getElementsByClassName(
                //   "tracker" + id
                // );
                // if (select[0].options.length == 0) {
                //   $.ajax({
                //     type: "GET",
                //     url: `${self.url}/projects/${project_id}.json?key=${api_key}&&include=trackers`,
                //     dataType: "json",
                //     contentType: "application/json",
                //     success: function (result, status, xhr) {
                //       if (result.project.trackers.length != 0) {
                //         let select_elem = document.getElementById("trackerSelect" + id);
                //         select_elem.style.display = "flex";
                //         select_elem.style.width = "300px";
                //         let hide_elem = document.getElementById("hide-tracker" + id);
                //         hide_elem.style.display = "none";
                //         result.project.trackers.forEach((p) => {
                //           if (p.id == tracker_ID) {
                //             $(".tracker" + id).append(
                //               `<option  selected value=${p.id}>${p.name}</option>`
                //             );
                //           } else {
                //             $(".select-tracker" + id).append(
                //               `<option value=${p.id}>${p.name}</option>`
                //             );
                //           }
                //         });
                //       } else {
                //         $(".show-error").css("display", "block");
                //         // $("#query_form").before(`<div class="show-error${id}" id='errorExplanation'><ul class="ul-time"><li>No tracker associated with  project please check your project setting</li></ul> </div>`);
                //       }
                //     },
  
                //     error: function (xhr, status, error) {
                //       // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                //     },
                //   });
                // }
              };
         
              window.updateCategory = function (id) {
                window.event.preventDefault();
                let select = document.getElementsByClassName(
                  "select-category" + id
                );
                if (select[0].options.length == 0) {
                  $.ajax({
                    type: "GET",
                    url:
                      self.url +
                      "/enumerations/time_entry_activities.json?key=" +
                      api_key +
                      " ",
                    dataType: "json",
                    contentType: "application/json",
                    success: function (result, status, xhr) {
                      if (result.time_entry_activities.length != 0) {
                        for (const option of result.time_entry_activities) {
                          const { name, id, selected } = option;
                          select[0].options.add(new Option(name, id, selected));
                        }
                      }
                    },
  
                    error: function (xhr, status, error) {
                      // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                    },
                  });
                }
  
                var category = document.getElementById("category_id" + id);
                category.style.display = "none";
                var div = document.getElementById("category-tag" + id);
                div.style.display = "block";
              };
  
              window.handleSubmitT = function (id) {
                window.event.preventDefault();
           
                // var card_elem = document.getElementById("tracker" + id);
                // card_elem.style.display = "block";
                // var input = document.getElementById("tracker-tag" + id);
                // input.style.display = "none";
                let tracker_id = changeTracker(id);
                let tracker_name = getTrackerName(id);
        
  
                var content = {
                  tracker_id: parseInt(tracker_id),
                };
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
           
                    let select_elem = document.getElementById("trackerSelect" + id);
                    select_elem.style.display = "none";
                    let hide_elem = document.getElementById("hide-tracker" + id);
                    hide_elem.style.display = "flex";
                    let element=document.getElementsByClassName(`tracker-name${id}`);
                    let field=document.getElementById(`tracker-agile${id}`);
                    // console.log(field,"filed varha");
                    field.innerHTML=tracker_name;
                    // field.html(tracker_name)
                    element[0].innerHTML=tracker_name;
                //     var color
                // $.ajax({
                //   type: "GET",
                //   url:url+`/all_colors.json?key=${api_key}`,
                //   dataType: "json",
                //   async:false,
                //   success: function (result, status, xhr) {
                //     result.forEach((object,i)=>{
                //       if(object.color_value === true)
                //       color = object.color_name
                       
                //     })
                //   }
                // });
                    var color = localStorage.getItem("selected_color");
                    if (color === "Tracker") {
                      if (tracker_name == "Bug") {
                        // nodeItem.style.color = "#eb3b5a";
                        //nodeItem[0].style.border = "1px solid rgb(235 59 90 / 50%)";
                        //nodeItem[0].style.borderLeft = "5px solid #eb3b5a";
  
                      } else if (tracker_name == "Task") {
                        // nodeItem.style.color = "#00BBB2";
                        //nodeItem[0].style.border = "1px solid rgb(190, 239, 190)";
                        //nodeItem[0].style.borderLeft = "5px solid #00BBB2";
                      } else if (tracker_name == "Feature") {
                        // nodeItem.style.color = "#F27D3E";
                        //nodeItem[0].style.border = "1px solid rgb(255, 202, 105)";
                        //nodeItem[0].style.borderLeft = "5px solid #F27D3E";
                      } else if (tracker_name == "Test Case") {
                        // nodeItem.style.color = "rgb(128 164 205)";
                        // console.log("test case");
                        //nodeItem[0].style.border = "1px solid rgb(82 128 179 / 52%)";
                        //nodeItem[0].style.borderLeft = "5px solid rgb(128 164 205)";
                      }
                      else if (tracker_name == "Requirement") {
                        // nodeItem.style.color = "rgb(191 170 236)";
                        //nodeItem[0].style.border = "1px solid rgb(203 130 242 / 78%)";
                        //nodeItem[0].style.borderLeft = "5px solid rgb(191 170 236)";
                      }
                      else if (tracker_name == "Change Request") {
                        // nodeItem.style.color = "rgb(207 150 163)";
                        //nodeItem[0].style.border = "1px solid rgb(211 99 129 / 52%)";
                        //nodeItem[0].style.borderLeft = "5px solid rgb(207 150 163)";    
                      }
                      else if (tracker_name == "Improvement") {
                        // nodeItem.style.color = "rgb(142 203 185)";
                        //nodeItem[0].style.border = "1px solid rgb(61 194 128 / 52%) ";
                        //nodeItem[0].style.borderLeft = "5px solid  rgb(142 203 185)"; 
                      }
                      else {
                        // nodeItem.style.color = "#0094ff";
                        //nodeItem[0].style.border = "1px solid rgb(240 157 219 / 52%)";
                        //nodeItem[0].style.borderLeft = "5px solid rgb(225 170 215)";
  
                      }
                    }
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
  
              window.handleSubmitCategory = function (id) {
                window.event.preventDefault();
                var card_elem = document.getElementById("category_id" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("category-tag" + id);
                input.style.display = "none";
                let category_id = changeCategory(id);
                var content = {
                  category_id: parseInt(category_id),
                };
                $.ajax({
                  type: "PUT",
                  url: self.url + "/issues/" + id + ".json?key=" + api_key + " ",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
                    var elem = document.getElementsByClassName(
                      "select-category" + id
                    );
                    $("#category_id" + id).html(
                      elem[0].options[elem[0].selectedIndex].innerHTML +
                      " &nbsp;" +
                      "#" +
                      id
                    );
                  },
  
                  error: function (xhr, status, error) {
                    // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                  },
                });
              };
              window.handleCloseCategory = function (id) {
                window.event.preventDefault();
                var card_elem = document.getElementById("category_id" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("category-tag" + id);
                input.style.display = "none";
              };
              window.handleCloseT = function (id) {
                window.event.preventDefault();
                var card_elem = document.getElementById("tracker" + id);
                card_elem.style.display = "block";
                var input = document.getElementById("tracker-tag" + id);
                input.style.display = "none";
              };
              window.changeTracker = function (id) {
                window.event.preventDefault();
                var elem = document.getElementsByClassName("tracker" + id);
                return elem[0].options[elem[0].selectedIndex].value;
              };
              window.getTrackerName = function (id) {
                window.event.preventDefault();
                var elem = document.getElementsByClassName("tracker" + id);
                return elem[0].options[elem[0].selectedIndex].innerHTML;
              };
              window.changeCategory = function (id) {
                window.event.preventDefault();
                var elem = document.getElementsByClassName(
                  "select-category" + id
                );
                return elem[0].options[elem[0].selectedIndex].value;
              };
              window.changePriority = function (id) {
                var elem = document.getElementsByClassName(
                  "priority" + id
                );
                return elem[0].options[elem[0].selectedIndex].value;
              };
              window.getPriorityName = function (id) {
                var elem = document.getElementsByClassName(
                  "priority" + id
                );
                return elem[0].options[elem[0].selectedIndex].innerHTML;
              };
              window.updateSubject = function (id) {
                let elem = document.getElementById("input-field" + id);
              };
  
              window.changedateFormat = function (date) {
                var change_date = new Date(date);
                var dd = String(change_date.getDate()).padStart(2, "0");
                var mm = String(change_date.getMonth() + 1).padStart(2, "0"); //January is 0!
                var yyyy = change_date.getFullYear();
                return (change_date = dd + "-" + mm + "-" + yyyy);
              };
         
            // function generateSubtasksHTML(subtasks) {
            //   let html = '<ul>';
            
            //   subtasks.forEach(subtask => {
            //     html += `<li id="restrict-popup" ><a  target="_blank" class="sub_task_a" href="/issues/${subtask.id}">#${subtask.id}:&nbsp;${subtask.subject}</a>`;
            
            //     if (subtask.children) {
            //       html += generateSubtasksHTML(subtask.children);
            //     }
            
            //     html += '</li>';
            //   });
            
            //   html += '</ul>';
            //   return html;
            //  }
            
                       // Function to convert Textile image syntax to HTML image tag
                  function convertTextileImages(text,attachmentId) {
                    return text.replace(/!\[(.*?)\]\((.*?)\)/g, `<img class='description-image' src='/attachments/download/${attachmentId}/$2' alt='$1'>`);
                  }
            
              function __buildItemCard(item) {
                
                var change_start_date = changedateFormat(item.start_date);
                var change_due_date = changedateFormat(item.due_date);
                var sub = "subject" in item ? item.subject : "No data available";
                var tracker = "tracker" in item ? item.tracker.name : "Bug";
                var tracker_id = "tracker" in item ? item.tracker.id : "";
                var progress_ratio = returnInt(item.done_ratio);
                var start_date ="start_date" in item && item.start_date != null? change_start_date : "No data";
                var due_date ="due_date" in item && item.due_date != null? change_due_date : "No data";
                var assignee ="assigned_to" in item ? item.assigned_to.name : "Anonymous";
                var name_value = assignee.split(" ");
                var firstname = name_value[0];
                var lastname = name_value[1] ? name_value[1] : "";
                var intials = firstname.charAt(0) + lastname.charAt(0);
                var priority = "priority" in item ? item.priority.name : "Low";
                var priority_id = "priority" in item ? item.priority.id : "";
                var project_id = "project" in item ? item.project.id : "1";
                var story_points = "story_points" in item ? item.story_points : null;
                var fields = "";
                var story_points_Html = "";
                // additional card fields
                var author="author" in item ? item.author&&item.author.name : "No";
                var author_id="author" in item ? item.author&&item.author.id : "No";
                var description ="description" in item && item.description;
                var category = "category" in item && item.category && item.category.name
                var version_name="fixed_version" in item && item.fixed_version && item.fixed_version.name;
                var parent_task='parent' in item && item.parent && item.parent.id;
                var version_id="fixed_version" in item && item.fixed_version && item.fixed_version.id;
  
           
                var thumbnail = ""; 
  
                const params = window.location.search
                let  parameters = new URLSearchParams(params);
                const  project = parameters.get('project_id');
  
                function returnInt(value) {
                  if (value === "No data") {
                    return 0;
                  } else {
                    return parseInt(value, 10);
                  }
                }
  
  
  
              function generateSubtasksHTML(subtasks, count = { value: 0 }) {
                let html = '<ul>';
              
                subtasks.forEach(subtask => {
                  if (count.value < 5) {
                    html += `<li id="restrict-popup"><a target="_blank" class="sub_task_a" href="/issues/${subtask.id}">#${subtask.id}:&nbsp;${subtask.subject}</a>`;
                    count.value++;
              
                    if (subtask.children) {
                      html += generateSubtasksHTML(subtask.children, count);
                    }
              
                    html += '</li>';
                  } 
                  else if (!count.addedSeeMore) {
                    html += `</div><a target="_blank" href="${url}/issues/${item.id}" style="color: black;">See more</a>`;
                    count.addedSeeMore = true;
                  }
                });
              
                html += '</ul>';
              
                return html;
              }
              
                
              let Spent_time=item.total_spent_hours!=null?item.total_spent_hours:0;            
              if(timeFormat=="minutes")
              {
                Spent_time=convertToHHMM(Spent_time)
              }
              else{
                if(Number.isInteger(Spent_time))
                {
                  Spent_time=Spent_time;
                }
                else{
                  Spent_time=Spent_time.toFixed(2);
                }
              }
  
                if (project) {
  
                  if(self.options.element=="#version-board")
                  {
      
                       if (version_cards.includes("Story Points") && story_points_enabled === "1" ) {
                        if (story_points && (!story_points_tracker || item.tracker.id == story_points_tracker)) {
                          story_points_Html += ` <div class="zt-agile-story-points-div" style="display:flex;"> <div id="story-points${item.id}" class="story-points-agile">(${story_points}sp)</div> </div>`;
                        }  
                      }
            
                     fields +=`<div   class="first-div">
                                  <div class="zt-agile-subject-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                                     <div  class="zt-agile-su bject-div-child" style="display:flex;">
                                        <div id="sub${item.id}" class="subject-agile">${sub}</div>
                                      </div>
                                      ${story_points_Html}                                            
                                   </div>
                                    <div class="zt-agile-tracker-issue-id-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                                      <div  class="zt-agile-tracker-issue-id-div-child" style="display:flex; flex-direction:row; gap:4px;">
                                         <div class="zt-agile-tracker-div" style="display:flex; align-items:center">
                                           <p  id="tracker-agile${item.id}" class="tracker-agile ${tracker.toLowerCase()}">${tracker}</p>
                                         </div>
                                         <div class="zt-agile-issue-id-div" style="display:flex;">
                                           <a id="restrict-popup" class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${item.id}> <span>#${item.id}</span></a> 
                                         </div>
                                      </div>
                                      <div class="zt-agile-priority-user-div" style="display:flex; flex-direction:row; gap:3px;">
                                        <div class="zt-agile-priority-div" style="cursor:pointer;" style="display:flex;">
                                         <div  id="agilePriority${item.id}" data-priority=${priority.toLowerCase()} class="priority-agileBoard ${priority.toLowerCase()}"></div>
                                        </div>
                                       <div class="zt-agile-user-div round"  style="cursor:pointer;">
                                         <div id="user-name${item.id}" class="auth-name">${intials}</div>
                                        </div>
                                     </div>
                                  </div>
                            
                            </div>`;
                    
                     
                            if(!version_cards.includes("Project")&&version_cards.includes("Estimation"))
                            {
                              let Estimation=item.estimated_hours!=null?item.estimated_hours:0;            
                              if(timeFormat=="minutes")
                              {
                                Estimation=convertToHHMM(Estimation)
                              }
                              else{
                                if(Number.isInteger(Estimation))
                                {
                                  Estimation=Estimation;
                                }
                                else{
                                  Estimation=Estimation.toFixed(2);
                                }
                               
                              }
                              fields += `<p style="display:flex" class="card-sub "> <span>Estimated Time -&nbsp;</span><span   id="estimate-h${item.id}" class="cursor ehour-agile" >${Estimation+"h"}</span></p> `;
                            }
                         
                         if (version_cards && version_cards.length != 0) {
                          for (i = 0; i <version_cards.length; i++) {
                          if (
                            // item.hasOwnProperty(cards[i]) &&
                            version_cards[i] != "Priority" &&
                            version_cards[i] != "Tracker" &&
                            //cards[i] != "start_date" &&
                            version_cards[i] != "Assignee" &&
                            version_cards[i] != "Subject"
                          ) {
                           if (version_cards[i] == "% Done") {
                              fields += ` <div  class="zt-agile-progress-div" style="display:flex; justify-content:space-between; gap:10px;">
                                              <div class="progress-bar-div" style="display:flex; flex-grow:1;">
                                               <div class="progress-container" style="border-radius: 4px;width: 100%;height: 4px;background-color: #F1F1F1; margin-top: 7px;">
                                              <div class="progress-bar" id="progress_${item.id}" style="border-radius: 4px;background-color: rgba(72, 187, 153, 1);height: 4px; width: ${progress_ratio}%; "></div>
                                              </div>
                                              </div>
                                              <div class="progress-percent-div" style="display:flex;">
                                              <p  class="progress-agile" style=" margin: 0px" id="progress_show_${item.id}">${progress_ratio}% </p>         
                                              </div>
                                     </div>
                             </div>`;
                            }
                          }
                        }
                      }
                      if(version_cards.includes("Start Date")&&version_cards.includes("Due Date"))
                        {
                          fields += ` <div  class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                                  <div  class="zt-agile-start" style="display:flex;">
                                  <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                         </div>
                                            <div class="zt-agile-due"  style="display:flex;">
                                             <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                                       </div>
                             </div>`
                        }
                        else if(version_cards.includes("Start Date")&&!version_cards.includes("Due Date"))
                        {
                          fields += ` <div class="zt-agile-start-due-div" style="display:flex; justify-content:space-between; margin-top:8px;">
                          <div class="zt-agile-start"  style="display:flex;">
                          <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                 </div>
                                    <div  class="zt-agile-due"  style="display:none;">
                                     <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                               </div>
                     </div>`
                        }
                        else if(!version_cards.includes("Start Date")&&version_cards.includes("Due Date"))
                        {
                          fields += ` <div class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                          <div  class="zt-agile-start" style="display:none;">
                          <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                 </div>
                                    <div class="zt-agile-due"  style="display:flex;">
                                     <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                               </div>
                     </div>`
                        }
      
      
                        if(version_cards.includes("Tags"))
                        {
                          issue_tag.map((tag)=>{
                            if(tag.taggable_id == item.id) {
                              fields += `<div class="zt-agile-tag-div" style="display:flex; flex-direction:row; flex-wrap:wrap; gap:2px; margin-top:4px;">`
                              
                              let withColor = [];
                              let withoutColor = [];
                              
                              tag.tag_list.forEach((list) => {
                                if(list.background_color == " ") {
                                  withoutColor.push(`<div class="tag-agile-no-color"><span class="tag-text-no-color">${list.name}</span></div>`);
                                } else {
                                  withColor.push(`<span class="tag-agile" style="background-color: ${list.background_color}"><span class="tag-text">${list.name}</span></span>`);
                                }
                              });
                              
                              fields += withoutColor.join('') + withColor.join('');
                              fields += `</div>`;
                            }
                         })
                        }
        
                       
                 
                         // additional card fields code start 
                        if(version_cards.includes("Author")&&version_cards.includes("Spent Time"))
                        {
                          fields += `<div  class="zt-author-spent-div">
                                      <div  class="zt-spent"  style="display:flex;">
                                      <p  id="restrict-popup" class="m-p zt-p"><b class="label-field">Author</b>: <a   target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                                      </div>
                                    <div class="zt-author" style="display:flex;">
                                    <p   class="m-p zt-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                                  </div>
                              </div>`
                        }
                        else if(version_cards.includes("Author")&&!version_cards.includes("Spent Time"))
                        {
                          fields +=  `<p id="restrict-popup" class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>`
                        }
                        else if(!version_cards.includes("Author")&&version_cards.includes("Spent Time"))
                        {
                          fields += `<div  class="zt-author-spent-div">
                          <div  class="zt-spent"  style="display:none;">
                          <p class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                          </div>
                          <div class="zt-author" style="display:flex;">
                          <p class="m-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                        </div>
                          </div>`
                        }
                        if (version_cards.includes("Category")&&item.hasOwnProperty('category'))
                        {
                          fields += `<p  class="m-p categroy_card_p"><b class="label-field">Category</b>: <span class="agile-a"   >${category}</span></p>`
                        }
                        if(version_cards.includes("Target Version")&&item.hasOwnProperty('fixed_version'))
                        {
                          fields +=  `<p id="restrict-popup" class="m-p target_version_p"><b class="label-field">Target Version</b>: <a  class="agile-a" target="_blank" href=${url}/versions/${version_id} >${version_name}</a></p>`
                        }
                        if(version_cards.includes("Parent Task")&&item.hasOwnProperty("parent"))
                        {
                          fields +=  `<p class="m-p"><b class="label-field">Parent Task</b>: <a  id="restrict-popup"  class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${parent_task}> <span>#${parent_task}</span></a> </p>`
                        }
                        if(version_cards.includes("Description")&&description&&description.trim().length !== 0&&item.hasOwnProperty("description")&&description!="No data")
                        {
                          if(description.length>200)
                            {
                             description=description.substring(0,400)+'...';
                            }
                            var convertedDescription=description;
                            if (item.attachments&&item.attachments.length > 0) {
                             var lastIndex = item.attachments.length - 1;
                              convertedDescription = convertTextileImages(description,item.attachments[lastIndex].id);
                            }
                             fields+=`<div class="agile_description"><b class="label-field">Description:</b>${textile.convert(convertedDescription)}</div>`
                        }
                        if(version_cards.includes("Sub Tasks")&&item.hasOwnProperty("children"))
                        {
                          fields += `<div class="sub-issues">${generateSubtasksHTML(item.children)}</div>`;
                        }
                      // addition card fields code end 
  
                          if(version_cards.includes("Thumbnails"))
                          {
                            if (item.attachments&&item.attachments.length > 0) {
                              var lastIndex = item.attachments.length - 1;
                        
                              fields += `<div id="zt-thumnails" style="margin-top:10px;"><img class="zt-thumnail_image" src="/attachments/download/${item.attachments[lastIndex].id}/${item.attachments[lastIndex].filename}"></div>`;
                            }
                        }
                        if(version_cards.includes("Notes"))
                        {
                          console.log(notes,"noteshjkhjkh");
                          let count=0;
                            if(notes&&notes.length!=0)
                            {
                              notes.map((note)=>{
                                if(note.journalized_id==item.id&&note.notes!==""&&note.notes!=null)
                                {
                                  count++;
                                }
                              })
                              if(count>0)
                              {
                                fields +=`<div style="margin-top:4px;"><span style="margin-right:3px;">${count}</span><i class="far fa-comment"></i></div>`
                              }
                            }
                          }
            
                  }
                  else if(self.options.element=="#sprint-board")
                  {
            
                       if (sprint_cards.includes("Story Points") && story_points_enabled === "1" ) {
                        if (story_points && (!story_points_tracker || item.tracker.id == story_points_tracker)) {
                          story_points_Html += ` <div class="zt-agile-story-points-div" style="display:flex;"> <div id="story-points${item.id}" class="story-points-agile">(${story_points}sp)</div> </div>`;
                        }  
                        
                      }
            
                     fields +=`<div   class="first-div">
                                  <div class="zt-agile-subject-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                                     <div  class="zt-agile-su bject-div-child" style="display:flex;">
                                        <div id="sub${item.id}" class="subject-agile">${sub}</div>
                                      </div>
                                      ${story_points_Html}                                            
                                   </div>
                                    <div class="zt-agile-tracker-issue-id-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                                      <div  class="zt-agile-tracker-issue-id-div-child" style="display:flex; flex-direction:row; gap:4px;">
                                         <div class="zt-agile-tracker-div" style="display:flex; align-items:center">
                                           <p  id="tracker-agile${item.id}" class="tracker-agile ${tracker.toLowerCase()}">${tracker}</p>
                                         </div>
                                         <div class="zt-agile-issue-id-div" style="display:flex;">
                                           <a id="restrict-popup" class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${item.id}> <span>#${item.id}</span></a> 
                                         </div>
                                      </div>
                                      <div class="zt-agile-priority-user-div" style="display:flex; flex-direction:row; gap:3px;">
                                        <div class="zt-agile-priority-div" style="cursor:pointer;" style="display:flex;">
                                         <div  id="agilePriority${item.id}" data-priority=${priority.toLowerCase()} class="priority-agileBoard ${priority.toLowerCase()}"></div>
                                        </div>
                                       <div class="zt-agile-user-div round"  style="cursor:pointer;">
                                         <div id="user-name${item.id}" class="auth-name">${intials}</div>
                                        </div>
                                     </div>
                                  </div>
                            
                            </div>`;
                    
                     
                            if(!sprint_cards.includes("Project")&&sprint_cards.includes("Estimation"))
                            {
                              let Estimation=item.estimated_hours!=null?item.estimated_hours:0;            
                              if(timeFormat=="minutes")
                              {
                                Estimation=convertToHHMM(Estimation)
                              }
                              else{
                                if(Number.isInteger(Estimation))
                                {
                                  Estimation=Estimation;
                                }
                                else{
                                  Estimation=Estimation.toFixed(2);
                                }
                               
                              }
                              fields += `<p style="display:flex" class="card-sub "> <span>Estimated Time -&nbsp;</span><span   id="estimate-h${item.id}" class="cursor ehour-agile" >${Estimation+"h"}</span></p> `;
                            }
                         
                         if (sprint_cards && sprint_cards.length != 0) {
                          for (i = 0; i <sprint_cards.length; i++) {
                          if (
                            // item.hasOwnProperty(cards[i]) &&
                            sprint_cards[i] != "Priority" &&
                            sprint_cards[i] != "Tracker" &&
                            //cards[i] != "start_date" &&
                            sprint_cards[i] != "Assignee" &&
                            sprint_cards[i] != "Subject"
                          ) {
                           if (sprint_cards[i] == "% Done") {
                              fields += ` <div  class="zt-agile-progress-div" style="display:flex; justify-content:space-between; gap:10px;">
                                              <div class="progress-bar-div" style="display:flex; flex-grow:1;">
                                               <div class="progress-container" style="border-radius: 4px;width: 100%;height: 4px;background-color: #F1F1F1; margin-top: 7px;">
                                              <div class="progress-bar" id="progress_${item.id}" style="border-radius: 4px;background-color: rgba(72, 187, 153, 1);height: 4px; width: ${progress_ratio}%; "></div>
                                              </div>
                                              </div>
                                              <div class="progress-percent-div" style="display:flex;">
                                              <p  class="progress-agile" style=" margin: 0px" id="progress_show_${item.id}">${progress_ratio}% </p>         
                                              </div>
                                     </div>
                             </div>`;
                            }
                          }
                        }
                      }
                      if(sprint_cards.includes("Start Date")&&sprint_cards.includes("Due Date"))
                        {
                          fields += ` <div  class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                                  <div  class="zt-agile-start" style="display:flex;">
                                  <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                         </div>
                                            <div class="zt-agile-due"  style="display:flex;">
                                             <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                                       </div>
                             </div>`
                        }
                        else if(sprint_cards.includes("Start Date")&&!sprint_cards.includes("Due Date"))
                        {
                          fields += ` <div class="zt-agile-start-due-div" style="display:flex; justify-content:space-between; margin-top:8px;">
                          <div class="zt-agile-start"  style="display:flex;">
                          <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                 </div>
                                    <div  class="zt-agile-due"  style="display:none;">
                                     <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                               </div>
                     </div>`
                        }
                        else if(!sprint_cards.includes("Start Date")&&sprint_cards.includes("Due Date"))
                        {
                          fields += ` <div class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                          <div  class="zt-agile-start" style="display:none;">
                          <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                 </div>
                                    <div class="zt-agile-due"  style="display:flex;">
                                     <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                               </div>
                     </div>`
                        }
      
      
                        if(sprint_cards.includes("Tags"))
                        {
                          issue_tag.map((tag)=>{
                            if(tag.taggable_id == item.id) {
                              fields += `<div class="zt-agile-tag-div" style="display:flex; flex-direction:row; flex-wrap:wrap; gap:2px; margin-top:4px;">`
                              
                              let withColor = [];
                              let withoutColor = [];
                              
                              tag.tag_list.forEach((list) => {
                                if(list.background_color == " ") {
                                  withoutColor.push(`<div class="tag-agile-no-color"><span class="tag-text-no-color">${list.name}</span></div>`);
                                } else {
                                  withColor.push(`<span class="tag-agile" style="background-color: ${list.background_color}"><span class="tag-text">${list.name}</span></span>`);
                                }
                              });
                              
                              fields += withoutColor.join('') + withColor.join('');
                              fields += `</div>`;
                            }
                         })
                        }
        
                        
                 
                         // additional card fields code start 
                        if(sprint_cards.includes("Author")&&sprint_cards.includes("Spent Time"))
                        {
                          fields += `<div  class="zt-author-spent-div">
                                      <div  class="zt-spent"  style="display:flex;">
                                      <p  id="restrict-popup" class="m-p zt-p"><b class="label-field">Author</b>: <a   target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                                      </div>
                                    <div class="zt-author" style="display:flex;">
                                    <p   class="m-p zt-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                                  </div>
                              </div>`
                        }
                        else if(sprint_cards.includes("Author")&&!sprint_cards.includes("Spent Time"))
                        {
                          fields +=  `<p id="restrict-popup" class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>`
                        }
                        else if(!sprint_cards.includes("Author")&&sprint_cards.includes("Spent Time"))
                        {
                          fields += `<div  class="zt-author-spent-div">
                          <div  class="zt-spent"  style="display:none;">
                          <p class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                          </div>
                          <div class="zt-author" style="display:flex;">
                          <p class="m-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                        </div>
                          </div>`
                        }
                        if (sprint_cards.includes("Category")&&item.hasOwnProperty('category'))
                        {
                          fields += `<p  class="m-p categroy_card_p"><b class="label-field">Category</b>: <span class="agile-a"   >${category}</span></p>`
                        }
                        if(sprint_cards.includes("Target Version")&&item.hasOwnProperty('fixed_version'))
                        {
                          fields +=  `<p id="restrict-popup" class="m-p target_version_p"><b class="label-field">Target Version</b>: <a  class="agile-a" target="_blank" href=${url}/versions/${version_id} >${version_name}</a></p>`
                        }
                     
                        if(sprint_cards.includes("Parent Task")&&item.hasOwnProperty("parent"))
                        {
                          fields +=  `<p class="m-p"><b class="label-field">Parent Task</b>: <a  id="restrict-popup"  class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${parent_task}> <span>#${parent_task}</span></a> </p>`
                        }
                        if(sprint_cards.includes("Description")&&description&&description.trim().length !== 0&&item.hasOwnProperty("description")&&description!="No data")
                        {
                          if(description.length>200)
                            {
                             description=description.substring(0,400)+'...';
                            }
                            var convertedDescription=description;
                            if (item.attachments&&item.attachments.length > 0) {
                             var lastIndex = item.attachments.length - 1;
                              convertedDescription = convertTextileImages(description,item.attachments[lastIndex].id);
                            }
                             fields+=`<div class="agile_description"><b class="label-field">Description:</b> ${textile.convert(convertedDescription)}</div>`
                        }
                        if(sprint_cards.includes("Sub Tasks")&&item.hasOwnProperty("children"))
                        {
                          fields += `<div class="sub-issues">${generateSubtasksHTML(item.children)}</div>`;
                        }
                      // addition card fields code end 
  
                          if(sprint_cards.includes("Thumbnails"))
                          {
                            if (item.attachments&&item.attachments.length > 0) {
                              var lastIndex = item.attachments.length - 1;
                        
                              fields += `<div id="zt-thumnails" style="margin-top:10px;"><img class="zt-thumnail_image" src="/attachments/download/${item.attachments[lastIndex].id}/${item.attachments[lastIndex].filename}"></div>`;
                            }
                        }
                        if(sprint_cards.includes("Notes"))
                        {
                     
                          let count=0;
                            if(notes&&notes.length!=0)
                            {
                              notes.map((note)=>{
                                if(note.journalized_id==item.id&&note.notes!==""&&note.notes!=null)
                                {
                                  count++;
                                }
                              })
                              if(count>0)
                              {
                                fields +=`<div style="margin-top:4px;"><span style="margin-right:3px;">${count}</span><i class="far fa-comment"></i></div>`
                              }
                            }
                          }
                  }
                  else{
           
                  if ( project_cards.includes("Story Points") && story_points_enabled === "1" ) {
                    if (story_points && (!story_points_tracker || item.tracker.id == story_points_tracker)) {
                      story_points_Html += ` <div class="zt-agile-story-points-div" style="display:flex;"> <div id="story-points${item.id}" class="story-points-agile">(${story_points}sp)</div> </div>`;
                    }
                    
                  }
        
                  fields +=`<div   class="first-div">
                  <div class="zt-agile-subject-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                     <div  class="zt-agile-subject-div-child" style="display:flex;">
                         ${project_cards.includes("Subject") ? `<div id="sub${item.id}" class="subject-agile">${sub}</div>` : ''}
                      </div>
                      ${story_points_Html}                                            
                   </div>
                    <div class="zt-agile-tracker-issue-id-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                      <div  class="zt-agile-tracker-issue-id-div-child" style="display:flex; flex-direction:row; gap:4px;">
                     ${project_cards.includes("Tracker") ? `<div class="zt-agile-tracker-div" style="display:flex; align-items:center">
                        <p id="tracker-agile${item.id}" class="tracker-agile ${tracker.toLowerCase()}">${tracker}</p>
                      </div>` : ''}
                      ${project_cards.includes("Issue ID") ? `<div class="zt-agile-issue-id-div" style="display:flex;">
                        <a id="restrict-popup" class="link-agile ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${item.id}> <span>#${item.id}</span></a>
                      </div>` : ''}
                      </div>
                      <div class="zt-agile-priority-user-div" style="display:flex; flex-direction:row; gap:3px;">
                    ${project_cards.includes("Priority") ? `<div class="zt-agile-priority-div" style="cursor:pointer;" style="display:flex;">
                     <div id="agilePriority${item.id}" data-priority=${priority.toLowerCase()} class="priority-agileBoard ${priority.toLowerCase()}"></div>
                     </div>` : ''}
                     ${project_cards.includes("Assignee") ? `<div class="zt-agile-user-div round" style="cursor:pointer;">
                          <div id="user-name${item.id}" class="auth-name">${intials}</div>
                      </div>` : ''}
                     </div>
                  </div>
                    
            </div>`;
                
                       
                        if(!project_cards.includes("Project")&&project_cards.includes("Estimation"))
                        {
                          // var convertedTime = item.estimated_hours!=null ?convertToHHMM(item.estimated_hours): "0:0";
                          let Estimation=item.estimated_hours!=null?item.estimated_hours:0;            
                          if(timeFormat=="minutes")
                          {
                            Estimation=convertToHHMM(Estimation)
                          }
                          else{
                            if(Number.isInteger(Estimation))
                            {
                              Estimation=Estimation;
                            }
                            else{
                              Estimation=Estimation.toFixed(2);
                            }
                           
                          }
                          fields += `<p style="display:flex" class="card-sub"> <span>Estimated Time -&nbsp;</span><span id="estimate-h${item.id}" class="cursor ehour-agile" >${Estimation+"h"}</span></p> `;
                        }
                     
                     if (project_cards && project_cards.length != 0) {
                      for (i = 0; i < project_cards.length; i++) {
                      if (
                        // item.hasOwnProperty(cards[i]) &&
                        project_cards[i] != "Priority" &&
                        project_cards[i] != "Tracker" &&
                        //cards[i] != "start_date" &&
                        project_cards[i] != "Assignee" &&
                        project_cards[i] != "Subject"
                      ) {
                       if (project_cards[i] == "% Done") {
                          fields += ` <div  class="zt-agile-progress-div"   style="display:flex; justify-content:space-between; gap:10px;">
                                          <div class="progress-bar-div" style="display:flex; flex-grow:1;">
                                           <div class="progress-container" style="border-radius: 4px;width: 100%;height: 4px;background-color: #F1F1F1; margin-top: 7px;">
                                          <div class="progress-bar" id="progress_${item.id}" style="border-radius: 4px;background-color: rgba(72, 187, 153, 1);height: 4px; width: ${progress_ratio}%; "></div>
                                          </div>
                                          </div>
                                          <div class="progress-percent-div" style="display:flex;">
                                          <p  class="progress-agile" style=" margin: 0px" id="progress_show_${item.id}">${progress_ratio}% </p>         
                                          </div>
                                 </div>
                         </div>`;
                        }
                      }
                    }
                  }
                  if(project_cards.includes("Start Date")&&project_cards.includes("Due Date"))
                    {
                     
                      fields += ` <div  class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                              <div  class="zt-agile-start" style="display:flex;">
                              <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                     </div>
                                        <div class="zt-agile-due"  style="display:flex;">
                                         <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                                   </div>
                         </div>`
                    }
                    else if(project_cards.includes("Start Date")&&!project_cards.includes("Due Date"))
                    {
                      fields += ` <div class="zt-agile-start-due-div" style="display:flex; justify-content:space-between; margin-top:8px;">
                      <div class="zt-agile-start"  style="display:flex;">
                      <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                             </div>
                                <div  class="zt-agile-due"  style="display:none;">
                                 <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                           </div>
                 </div>`
                    }
                    else if(!project_cards.includes("Start Date")&&project_cards.includes("Due Date"))
                    {
                      fields += ` <div class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                      <div  class="zt-agile-start" style="display:none;">
                      <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                             </div>
                                <div class="zt-agile-due"  style="display:flex;">
                                 <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                           </div>
                 </div>`
                    }
  
  
                    if(project_cards.includes("Tags"))
                    {
                      issue_tag.map((tag)=>{
                        if(tag.taggable_id == item.id) {
                          fields += `<div class="zt-agile-tag-div" style="display:flex; flex-direction:row; flex-wrap:wrap; gap:2px; margin-top:4px;">`
                          
                          let withColor = [];
                          let withoutColor = [];
                          
                          tag.tag_list.forEach((list) => {
                            if(list.background_color == " ") {
                              withoutColor.push(`<div class="tag-agile-no-color"><span class="tag-text-no-color">${list.name}</span></div>`);
                          
                            } else {
                              withColor.push(`<span class="tag-agile" style="background-color: ${list.background_color}"><span class="tag-text">${list.name}</span></span>`);
                            }
                          });
                          
                          fields += withoutColor.join('') + withColor.join('');
                          fields += `</div>`;
                        }
                     })
                    }
    
                
                }
  
               // additional card fields code start 
              if(project_cards.includes("Author")&&project_cards.includes("Spent Time"))
              {
                fields += `<div  class="zt-author-spent-div">
                            <div  class="zt-spent"  style="display:flex;">
                            <p  id="restrict-popup" class="m-p zt-p"><b class="label-field">Author</b>: <a   target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                            </div>
                          <div class="zt-author" style="display:flex;">
                          <p   class="m-p zt-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                         </div>
                    </div>`
              }
              else if(project_cards.includes("Author")&&!project_cards.includes("Spent Time"))
              {
                fields +=  `<p id="restrict-popup" class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>`
              }
              else if(!project_cards.includes("Author")&&project_cards.includes("Spent Time"))
              {
                fields += `<div  class="zt-author-spent-div">
                <div  class="zt-spent"  style="display:none;">
                <p class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                </div>
                <div class="zt-author" style="display:flex;">
                 <p class="m-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
               </div>
                </div>`
              }
              if (project_cards.includes("Category")&&item.hasOwnProperty('category'))
              {
                fields += `<p  class="m-p categroy_card_p"><b class="label-field">Category</b>: <span class="agile-a"   >${category}</span></p>`
              }
              if(project_cards.includes("Target Version")&&item.hasOwnProperty('fixed_version'))
              {
                fields +=  `<p id="restrict-popup" class="m-p target_version_p"><b class="label-field">Target Version</b>: <a  class="agile-a" target="_blank" href=${url}/versions/${version_id} >${version_name}</a></p>`
              }
              if(project_cards.includes("Parent Task")&&item.hasOwnProperty("parent"))
              {
                fields +=  `<p class="m-p"><b class="label-field">Parent Task</b>: <a  id="restrict-popup"  class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${parent_task}> <span>#${parent_task}</span></a> </p>`
              }
              if(project_cards.includes("Description")&&description&&description.trim().length !== 0&&item.hasOwnProperty("description")&&description!="No data")
              {
                 if(description.length>200)
                 {
                  description=description.substring(0,400)+'...';
                 }
                 var convertedDescription=description;
                 if (item.attachments&&item.attachments.length > 0) {
                  var lastIndex = item.attachments.length - 1;
                   convertedDescription = convertTextileImages(description,item.attachments[lastIndex].id);
                 }
                  fields+=`<div class="agile_description"><b class="label-field">Description:</b> ${textile.convert(convertedDescription)}</div>`
              }
             
              if(project_cards.includes("Sub Tasks")&&item.hasOwnProperty("children"))
              {
                fields += `<div class="sub-issues">${generateSubtasksHTML(item.children)}</div>`;
                
              }
  
              if (project_cards.includes("Thumbnails")) 
                       {
                         if (item.attachments&&item.attachments.length > 0) {
                     var lastIndex = item.attachments.length - 1;
                     fields += `<div id="zt-thumnails" style="margin-top:10px;"><img class="zt-thumnail_image" src="/attachments/download/${item.attachments[lastIndex].id}/${item.attachments[lastIndex].filename}"></div>`;
                     
                    }
              }
  
              if(project_cards.includes("Notes"))
              {
                let count=0;
                  if(notes&&notes.length!=0)
                  {
                    notes.map((note)=>{
                      if(note.journalized_id==item.id&&note.notes!==""&&note.notes!=null)
                      {
                        count++;
                      }
                    })
                    if(count>0)
                    {
                      fields +=`<div style="margin-top:4px;"><span style="margin-right:3px;">${count}</span><i class="far fa-comment"></i></div>`
                    }
                  }
                }
  
            // addition card fields code end 
                  return fields
  
                }
       
              else {

                if(cards.includes("Project")&&cards.includes("Estimation"))
                {
                  // console.log(item.id,item.estimated_hours,"item estimatied hours");
                  let Estimation=item.estimated_hours!=null?item.estimated_hours:0;            
                  if(timeFormat=="minutes")
                  {
                    Estimation=convertToHHMM(Estimation)
                  }
                  else{
                    if(Number.isInteger(Estimation))
                    {
                      Estimation=Estimation;
                    }
                    else{
                      Estimation=Estimation.toFixed(2);
                    }
                   
                  }
                  fields += `<div class="zt-agile-project-estimation-div" style="display:flex; justify-content:space-between; gap:4px;">
                               <div class="zt-agile-project-div" style="display:flex;">
                                 <div class="project-detail">${item.project.name}</div>
                               </div>
                             <div class="zt-agile-estimation-div" style="display:flex;">
                               <div  id="estimate-h${item.id}" class="project-detail hour-agile">${Estimation+"h"}</div>
                              </div>
                             </div> `;
                }
  
                else if(cards.includes("Project")&&!cards.includes("Estimation"))
                {
                  if(!project)
                  {
                    fields += `<div class="project-detail">${item.project.name}</div> `;
                  }
               
                }
  
                if ( cards.includes("Story Points") && story_points_enabled === "1" ) {
                  if (story_points && (!story_points_tracker || item.tracker.id == story_points_tracker)) {
                    story_points_Html += ` <div class="zt-agile-story-points-div" style="display:flex;"> <div id="story-points${item.id}" class="story-points-agile">(${story_points}sp)</div> </div>`;
                  }
                }
              
                fields +=`<div   class="first-div">
                <div class="zt-agile-subject-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                   <div  class="zt-agile-subject-div-child" style="display:flex;">
                       ${cards.includes("Subject") ? `<div id="sub${item.id}" class="subject-agile">${sub}</div>` : ''}
                    </div>
                    ${story_points_Html}                                            
                 </div>
                  <div class="zt-agile-tracker-issue-id-div-parent" style="display:flex; justify-content:space-between; align-items:center;">
                    <div  class="zt-agile-tracker-issue-id-div-child" style="display:flex; flex-direction:row; gap:4px;">
                   ${cards.includes("Tracker") ? `<div class="zt-agile-tracker-div" style="display:flex; align-items:center">
                      <p id="tracker-agile${item.id}" class="tracker-agile ${tracker.toLowerCase()}">${tracker}</p>
                    </div>` : ''}
                    ${cards.includes("Issue ID") ? `<div class="zt-agile-issue-id-div" style="display:flex;">
                      <a id="restrict-popup" class="link-agile ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${item.id}> <span>#${item.id}</span></a>
                    </div>` : ''}
                    </div>
                    <div class="zt-agile-priority-user-div" style="display:flex; flex-direction:row; gap:3px;">
                  ${cards.includes("Priority") ? `<div class="zt-agile-priority-div" style="cursor:pointer;" style="display:flex;">
                   <div id="agilePriority${item.id}" data-priority=${priority.toLowerCase()} class="priority-agileBoard ${priority.toLowerCase()}"></div>
                   </div>` : ''}
                   ${cards.includes("Assignee") ? `<div class="zt-agile-user-div round" style="cursor:pointer;">
                        <div id="user-name${item.id}" class="auth-name">${intials}</div>
                    </div>` : ''}
                   </div>
                </div>
                  
          </div>`;
              
                     
                      if(!cards.includes("Project")&&cards.includes("Estimation"))
                      {
                        // var convertedTime = item.estimated_hours!=null ?convertToHHMM(item.estimated_hours): "0:0";
                        let Estimation=item.estimated_hours!=null?item.estimated_hours:0;            
                        if(timeFormat=="minutes")
                        {
                          Estimation=convertToHHMM(Estimation)
                        }
                        else{
                          if(Number.isInteger(Estimation))
                          {
                            Estimation=Estimation;
                          }
                          else{
                            Estimation=Estimation.toFixed(2);
                          }
                         
                        }
                        
                        fields += `<p style="display:flex" class="card-sub "> <span>Estimated Time -&nbsp;</span><span   id="estimate-h${item.id}" class="cursor ehour-agile" >${Estimation+"h"}</span></p> `;
                      }
                   
                   if (cards && cards.length != 0) {
                  for (i = 0; i < cards.length; i++) {
                    if (
                      // item.hasOwnProperty(cards[i]) &&
                      cards[i] != "Priority" &&
                      cards[i] != "Tracker" &&
                      //cards[i] != "start_date" &&
                      cards[i] != "Assignee" &&
                      cards[i] != "Subject"
                    ) {
                     if (cards[i] == "% Done") {
                        fields += ` <div class="zt-agile-progress-div"   style="display:flex; justify-content:space-between; gap:10px;">
                                        <div class="progress-bar-div" style="display:flex; flex-grow:1;">
                                        <div class="progress-container" style="border-radius: 4px;width: 100%;height: 4px;background-color: #F1F1F1; margin-top: 7px;">
                                        <div class="progress-bar" id="progress_${item.id}" style="border-radius: 4px;background-color: rgba(72, 187, 153, 1);height: 4px; width: ${progress_ratio}%; "></div>
                                        </div>
                                        </div>
                                        <div class="progress-percent-div" style="display:flex;">
                                        <p  class="progress-agile" style=" margin: 0px" id="progress_show_${item.id}">${progress_ratio}% </p>         
                                        </div>
                               </div>
                       </div>`;
                      }
                    }
                  }
                }
                if(cards.includes("Start Date")&&cards.includes("Due Date"))
                  {
                  
                    fields += ` <div  class="zt-agile-start-due-div" style="display:flex; justify-content:space-between; margin-top:8px;">
                                 <div  class="zt-agile-start" style="display:flex;">
                                    <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                                   </div>
                                      <div class="zt-agile-due"   style="display:flex;">
                                       <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                                 </div>
                       </div>`
                  }
                  else if(cards.includes("Start Date")&&!cards.includes("Due Date"))
                  {
                    fields += ` <div class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                    <div  class="zt-agile-start" style="display:flex;">
                    <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                           </div>
                              <div class="zt-agile-due" style="display:none;">
                               <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                         </div>
               </div>`
                  }
                  else if(!cards.includes("Start Date")&&cards.includes("Due Date"))
                  {
                    fields += ` <div  class="zt-agile-start-due-div"  style="display:flex; justify-content:space-between; margin-top:8px;">
                    <div  class="zt-agile-start"  style="display:none;">
                    <p style="display:flex" class="card-sub "><span>Start date</span><span class="cursor due-date-agile" id="Startdate${item.id}"  style="display: block;">${start_date}</span></p>
                           </div>
                              <div class="zt-agile-due" style="display:flex;">
                               <p style="display:flex" class="card-sub "> <span>Due date</span><span class="cursor due-date-agile" id="Duedate${item.id}"  style="display: block;">${due_date}</span></p>
                         </div>
                    </div>`
                  }
                  if(cards.includes("Tags"))
                  {
                    issue_tag.map((tag)=>{
                      if(tag.taggable_id == item.id) {
                        fields += `<div class="zt-agile-tag-div" style="display:flex; flex-direction:row; flex-wrap:wrap; gap:2px; margin-top:4px;">`
                        
                        let withColor = [];
                        let withoutColor = [];
                        
                        tag.tag_list.forEach((list) => {
                          if(list.background_color == " ") {
                            withoutColor.push(`<div class="tag-agile-no-color"><span class="tag-text-no-color">${list.name}</span></div>`);
                          } else {
                            withColor.push(`<span class="tag-agile" style="background-color: ${list.background_color}"><span class="tag-text">${list.name}</span></span>`);
                          }
                        });
                        
                        fields += withoutColor.join('') + withColor.join('');
                        fields += `</div>`;
                      }
                   })
                  }
                
              // additional card fields code start 
  
              if(cards.includes("Author")&&cards.includes("Spent Time"))
              {
                fields += `<div  class="zt-author-spent-div">
                            <div  class="zt-spent"  style="display:flex;">
                            <p  id="restrict-popup" class="m-p zt-p"><b class="label-field">Author</b>: <a   target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                            </div>
                          <div class="zt-author" style="display:flex;">
                          <p   class="m-p zt-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
                         </div>
                    </div>`
              }
              else if(cards.includes("Author")&&!cards.includes("Spent Time"))
              {
                fields +=  `<p id="restrict-popup" class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>`
              }
              else if(!cards.includes("Author")&&cards.includes("Spent Time"))
              {
                fields += `<div  class="zt-author-spent-div">
                <div  class="zt-spent"  style="display:none;">
                <p class="m-p"><b class="label-field">Author</b>: <a  target="_blank" class="agile-a" href=${url}/users/${author_id} >${author}</a></p>
                </div>
                <div class="zt-author" style="display:flex;">
                 <p class="m-p"><b class="label-field">Spent Time</b>: <span   class="agile-a" >${Spent_time+"h"}</span></p>
               </div>
                </div>`
              }
              if (cards.includes("Category")&&item.hasOwnProperty('category'))
              {
                fields += `<p  class="m-p categroy_card_p"><b class="label-field">Category</b>: <span class="agile-a"   >${category}</span></p>`
              }
              if(cards.includes("Target Version")&&item.hasOwnProperty('fixed_version'))
              {
                fields +=  `<p id="restrict-popup" class="m-p target_version_p"><b class="label-field">Target Version</b>: <a  class="agile-a" target="_blank" href=${url}/versions/${version_id} >${version_name}</a></p>`
              }
              if(cards.includes("Parent Task")&&item.hasOwnProperty("parent"))
              {
                fields +=  `<p class="m-p"><b class="label-field">Parent Task</b>: <a  id="restrict-popup"  class="link-agile  ${tracker.toLowerCase()}" target="_blank" href=${url}/issues/${parent_task}> <span>#${parent_task}</span></a> </p>`
              }
              if(cards.includes("Description")&&description&&description.trim().length !== 0&&item.hasOwnProperty("description")&&description!="No data")
              {
                if(description.length>200)
                  {
                   description=description.substring(0,400)+'...';
                  }
                  var convertedDescription=description;
                  if (item.attachments&&item.attachments.length > 0) {
                   var lastIndex = item.attachments.length - 1;
                    convertedDescription = convertTextileImages(description,item.attachments[lastIndex].id);
                  }
                   fields+=`<div class="agile_description"><b class="label-field">Description:</b> ${textile.convert(convertedDescription)}</div>`
              }
              if(cards.includes("Sub Tasks")&&item.hasOwnProperty("children"))
              {
                fields += `<div class="sub-issues">${generateSubtasksHTML(item.children)}</div>`;
              }
             // addition card fields code end 
  
       
  
               if(cards.includes("Thumbnails"))
               {
               if (item.attachments&&item.attachments.length > 0) {
                var lastIndex = item.attachments.length - 1;
          
                fields += `<div id="zt-thumnails" style="margin-top:10px;"><img class="zt-thumnail_image" src="/attachments/download/${item.attachments[lastIndex].id}/${item.attachments[lastIndex].filename}"></div>`;
               }
               }
  
               if(cards.includes("Notes"))
                {
                let count=0;
                if(notes&&notes.length!=0)
                {
          
                  notes.map((note)=>{
                    if(note.journalized_id==item.id&&note.notes!==""&&note.notes!=null)
                    {
             
                      count++;
                    }
                  })
                  if(count>0)
                  {
                    fields +=`<div style="margin-top:4px;"><span style="margin-right:3px;">${count}</span><i class="far fa-comment"></i></div>`
                  }
                }
              }
            
                return fields;
              }
              }
                 //init plugin
                 this.init();
               };
   
            
          })
          ();
        
          // *********************
        },
        { dragula: 9 },
      ],
      2: [
        function (require, module, exports) {
          module.exports = function atoa(a, n) {
            return Array.prototype.slice.call(a, n);
          };
        },
        {},
      ],
      3: [
        function (require, module, exports) {
          "use strict";
  
          var ticky = require("ticky");
  
          module.exports = function debounce(fn, args, ctx) {
            if (!fn) {
              return;
            }
            ticky(function run() {
              fn.apply(ctx || null, args || []);
            });
          };
        },
        { ticky: 11 },
      ],
      4: [
        function (require, module, exports) {
          "use strict";
  
          var atoa = require("atoa");
          var debounce = require("./debounce");
  
          module.exports = function emitter(thing, options) {
            var opts = options || {};
            var evt = {};
            if (thing === undefined) {
              thing = {};
            }
            thing.on = function (type, fn) {
              if (!evt[type]) {
                evt[type] = [fn];
              } else {
                evt[type].push(fn);
              }
              return thing;
            };
            thing.once = function (type, fn) {
              fn._once = true; // thing.off(fn) still works!
              thing.on(type, fn);
              return thing;
            };
            thing.off = function (type, fn) {
              var c = arguments.length;
              if (c === 1) {
                delete evt[type];
              } else if (c === 0) {
                evt = {};
              } else {
                var et = evt[type];
                if (!et) {
                  return thing;
                }
                et.splice(et.indexOf(fn), 1);
              }
              return thing;
            };
            thing.emit = function () {
              var args = atoa(arguments);
              return thing.emitterSnapshot(args.shift()).apply(this, args);
            };
            thing.emitterSnapshot = function (type) {
              var et = (evt[type] || []).slice(0);
              return function () {
                var args = atoa(arguments);
                var ctx = this || thing;
                if (type === "error" && opts.throws !== false && !et.length) {
                  throw args.length === 1 ? args[0] : args;
                }
                et.forEach(function emitter(listen) {
                  if (opts.async) {
                    debounce(listen, args, ctx);
                  } else {
                    listen.apply(ctx, args);
                  }
                  if (listen._once) {
                    thing.off(type, listen);
                  }
                });
                return thing;
              };
            };
            return thing;
          };
        },
        { "./debounce": 3, atoa: 2 },
      ],
      5: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              "use strict";
  
              var customEvent = require("custom-event");
              var eventmap = require("./eventmap");
              var doc = global.document;
              var addEvent = addEventEasy;
              var removeEvent = removeEventEasy;
              var hardCache = [];
  
              if (!global.addEventListener) {
                addEvent = addEventHard;
                removeEvent = removeEventHard;
              }
  
              module.exports = {
                add: addEvent,
                remove: removeEvent,
                fabricate: fabricateEvent,
              };
  
              function addEventEasy(el, type, fn, capturing) {
                return el.addEventListener(type, fn, capturing);
              }
  
              function addEventHard(el, type, fn) {
                return el.attachEvent("on" + type, wrap(el, type, fn));
              }
  
              function removeEventEasy(el, type, fn, capturing) {
                return el.removeEventListener(type, fn, capturing);
              }
  
              function removeEventHard(el, type, fn) {
                var listener = unwrap(el, type, fn);
                if (listener) {
                  return el.detachEvent("on" + type, listener);
                }
              }
  
              function fabricateEvent(el, type, model) {
                var e =
                  eventmap.indexOf(type) === -1
                    ? makeCustomEvent()
                    : makeClassicEvent();
                if (el.dispatchEvent) {
                  el.dispatchEvent(e);
                } else {
                  el.fireEvent("on" + type, e);
                }
                function makeClassicEvent() {
                  var e;
                  if (doc.createEvent) {
                    e = doc.createEvent("Event");
                    e.initEvent(type, true, true);
                  } else if (doc.createEventObject) {
                    e = doc.createEventObject();
                  }
                  return e;
                }
                function makeCustomEvent() {
                  return new customEvent(type, { detail: model });
                }
              }
  
              function wrapperFactory(el, type, fn) {
                return function wrapper(originalEvent) {
                  var e = originalEvent || global.event;
                  e.target = e.target || e.srcElement;
                  e.preventDefault =
                    e.preventDefault ||
                    function preventDefault() {
                      e.returnValue = false;
                    };
                  e.stopPropagation =
                    e.stopPropagation ||
                    function stopPropagation() {
                      e.cancelBubble = true;
                    };
                  e.which = e.which || e.keyCode;
                  fn.call(el, e);
                };
              }
  
              function wrap(el, type, fn) {
                var wrapper =
                  unwrap(el, type, fn) || wrapperFactory(el, type, fn);
                hardCache.push({
                  wrapper: wrapper,
                  element: el,
                  type: type,
                  fn: fn,
                });
                return wrapper;
              }
  
              function unwrap(el, type, fn) {
                var i = find(el, type, fn);
                if (i) {
                  var wrapper = hardCache[i].wrapper;
                  hardCache.splice(i, 1); // free up a tad of memory
                  return wrapper;
                }
              }
  
              function find(el, type, fn) {
                var i, item;
                for (i = 0; i < hardCache.length; i++) {
                  item = hardCache[i];
                  if (
                    item.element === el &&
                    item.type === type &&
                    item.fn === fn
                  ) {
                    return i;
                  }
                }
              }
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
                ? self
                : typeof window !== "undefined"
                  ? window
                  : {}
          ));
        },
        { "./eventmap": 6, "custom-event": 7 },
      ],
      6: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              "use strict";
  
              var eventmap = [];
              var eventname = "";
              var ron = /^on/;
  
              for (eventname in global) {
                if (ron.test(eventname)) {
                  eventmap.push(eventname.slice(2));
                }
              }
  
              module.exports = eventmap;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
                ? self
                : typeof window !== "undefined"
                  ? window
                  : {}
          ));
        },
        {},
      ],
      7: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              var NativeCustomEvent = global.CustomEvent;
  
              function useNative() {
                try {
                  var p = new NativeCustomEvent("cat", {
                    detail: { foo: "bar" },
                  });
                  return "cat" === p.type && "bar" === p.detail.foo;
                } catch (e) { }
                return false;
              }
  
              /**
               * Cross-browser `CustomEvent` constructor.
               *
               * https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent.CustomEvent
               *
               * @public
               */
  
              module.exports = useNative()
                ? NativeCustomEvent
                : // IE >= 9
                "undefined" !== typeof document &&
                  "function" === typeof document.createEvent
                  ? function CustomEvent(type, params) {
                    var e = document.createEvent("CustomEvent");
                    if (params) {
                      e.initCustomEvent(
                        type,
                        params.bubbles,
                        params.cancelable,
                        params.detail
                      );
                    } else {
                      e.initCustomEvent(type, false, false, void 0);
                    }
                    return e;
                  }
                  : // IE <= 8
                  function CustomEvent(type, params) {
                    var e = document.createEventObject();
                    e.type = type;
                    if (params) {
                      e.bubbles = Boolean(params.bubbles);
                      e.cancelable = Boolean(params.cancelable);
                      e.detail = params.detail;
                    } else {
                      e.bubbles = false;
                      e.cancelable = false;
                      e.detail = void 0;
                    }
                    return e;
                  };
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
                ? self
                : typeof window !== "undefined"
                  ? window
                  : {}
          ));
        },
        {},
      ],
      8: [
        function (require, module, exports) {
          "use strict";
  
          var cache = {};
          var start = "(?:^|\\s)";
          var end = "(?:\\s|$)";
  
          function lookupClass(className) {
            var cached = cache[className];
            if (cached) {
              cached.lastIndex = 0;
            } else {
              cache[className] = cached = new RegExp(
                start + className + end,
                "g"
              );
            }
            return cached;
          }
  
          function addClass(el, className) {
            var current = el.className;
            if (!current.length) {
              el.className = className;
            } else if (!lookupClass(className).test(current)) {
              el.className += " " + className;
            }
          }
  
          function rmClass(el, className) {
            el.className = el.className
              .replace(lookupClass(className), " ")
              .trim();
          }
  
          module.exports = {
            add: addClass,
            rm: rmClass,
          };
        },
        {},
      ],
      9: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              "use strict";
  
              var emitter = require("contra/emitter");
              var crossvent = require("crossvent");
              var classes = require("./classes");
              var doc = document;
              var documentElement = doc.documentElement;
  
              function dragula(initialContainers, options) {
                var len = arguments.length;
                if (len === 1 && Array.isArray(initialContainers) === false) {
                  options = initialContainers;
                  initialContainers = [];
                }
                var _mirror; // mirror image
                var _source; // source container
                var _item; // item being dragged
                var _offsetX; // reference x
                var _offsetY; // reference y
                var _moveX; // reference move x
                var _moveY; // reference move y
                var _initialSibling; // reference sibling when grabbed
                var _currentSibling; // reference sibling now
                var _copy; // item used for copying
                var _renderTimer; // timer for setTimeout renderMirrorImage
                var _lastDropTarget = null; // last container item was over
                var _grabbed; // holds mousedown context until first mousemove
  
                var o = options || {};
                if (o.moves === void 0) {
                  o.moves = always;
                }
                if (o.accepts === void 0) {
                  o.accepts = always;
                }
                if (o.invalid === void 0) {
                  o.invalid = invalidTarget;
                }
                if (o.containers === void 0) {
                  o.containers = initialContainers || [];
                }
                if (o.isContainer === void 0) {
                  o.isContainer = never;
                }
                if (o.copy === void 0) {
                  o.copy = false;
                }
                if (o.copySortSource === void 0) {
                  o.copySortSource = false;
                }
                if (o.revertOnSpill === void 0) {
                  o.revertOnSpill = false;
                }
                if (o.removeOnSpill === void 0) {
                  o.removeOnSpill = false;
                }
                if (o.direction === void 0) {
                  o.direction = "vertical";
                }
                if (o.ignoreInputTextSelection === void 0) {
                  o.ignoreInputTextSelection = true;
                }
                if (o.mirrorContainer === void 0) {
                  o.mirrorContainer = doc.body;
                }
  
                var drake = emitter({
                  containers: o.containers,
                  start: manualStart,
                  end: end,
                  cancel: cancel,
                  remove: remove,
                  destroy: destroy,
                  canMove: canMove,
                  dragging: false,
                });
  
                if (o.removeOnSpill === true) {
                  drake.on("over", spillOver).on("out", spillOut);
                }
  
                events();
  
                return drake;
  
                function isContainer(el) {
                  return drake.containers.indexOf(el) !== -1 || o.isContainer(el);
                }
  
                function events(remove) {
                  var op = remove ? "remove" : "add";
                  touchy(documentElement, op, "mousedown", grab);
                  touchy(documentElement, op, "mouseup", release);
                }
  
                function eventualMovements(remove) {
                  var op = remove ? "remove" : "add";
                  touchy(
                    documentElement,
                    op,
                    "mousemove",
                    startBecauseMouseMoved
                  );
                }
  
                function movements(remove) {
                  var op = remove ? "remove" : "add";
                  crossvent[op](documentElement, "selectstart", preventGrabbed); // IE8
                  crossvent[op](documentElement, "click", preventGrabbed);
                }
  
                function destroy() {
                  events(true);
                  release({});
                }
  
                function preventGrabbed(e) {
                  if (_grabbed) {
                    e.preventDefault();
                  }
                }
  
                function grab(e) {
                  _moveX = e.clientX;
                  _moveY = e.clientY;
  
                  var ignore =
                    whichMouseButton(e) !== 1 || e.metaKey || e.ctrlKey;
                  if (ignore) {
                    return; // we only care about honest-to-god left clicks and touch events
                  }
                  var item = e.target;
                  var context = canStart(item);
                  if (!context) {
                    return;
                  }
                  _grabbed = context;
                  eventualMovements();
                  if (e.type === "mousedown") {
                    if (isInput(item)) {
                      // see also: https://github.com/bevacqua/dragula/issues/208
                      item.focus(); // fixes https://github.com/bevacqua/dragula/issues/176
                    } else {
                      e.preventDefault(); // fixes https://github.com/bevacqua/dragula/issues/155
                    }
                  }
                }
  
                function startBecauseMouseMoved(e) {
                  if (!_grabbed) {
                    return;
                  }
                  if (whichMouseButton(e) === 0) {
                    release({});
                    return; // when text is selected on an input and then dragged, mouseup doesn't fire. this is our only hope
                  }
  
                  // truthy check fixes #239, equality fixes #207, fixes #501
                  if (
                    e.clientX !== void 0 &&
                    Math.abs(e.clientX - _moveX) <= (o.slideFactorX || 0) &&
                    e.clientY !== void 0 &&
                    Math.abs(e.clientY - _moveY) <= (o.slideFactorY || 0)
                  ) {
                    return;
                  }
  
                  if (o.ignoreInputTextSelection) {
                    var clientX = getCoord("clientX", e) || 0;
                    var clientY = getCoord("clientY", e) || 0;
                    var elementBehindCursor = doc.elementFromPoint(
                      clientX,
                      clientY
                    );
                    if (isInput(elementBehindCursor)) {
                      return;
                    }
                  }
  
                  var grabbed = _grabbed; // call to end() unsets _grabbed
                  eventualMovements(true);
                  movements();
                  end();
                  start(grabbed);
  
                  var offset = getOffset(_item);
                  _offsetX = getCoord("pageX", e) - offset.left;
                  _offsetY = getCoord("pageY", e) - offset.top;
  
                  classes.add(_copy || _item, "gu-transit");
                  renderMirrorImage();
                  drag(e);
                }
  
                function canStart(item) {
                  if (drake.dragging && _mirror) {
                    return;
                  }
                  if (isContainer(item)) {
                    return; // don't drag container itself
                  }
                  var handle = item;
                  while (
                    getParent(item) &&
                    isContainer(getParent(item)) === false
                  ) {
                    if (o.invalid(item, handle)) {
                      return;
                    }
                    item = getParent(item); // drag target should be a top element
                    if (!item) {
                      return;
                    }
                  }
                  var source = getParent(item);
                  if (!source) {
                    return;
                  }
                  if (o.invalid(item, handle)) {
                    return;
                  }
  
                  var movable = o.moves(item, source, handle, nextEl(item));
                  if (!movable) {
                    return;
                  }
  
                  return {
                    item: item,
                    source: source,
                  };
                }
  
                function canMove(item) {
                  return !!canStart(item);
                }
  
                function manualStart(item) {
                  var context = canStart(item);
                  if (context) {
                    start(context);
                  }
                }
  
                function start(context) {
                  if (isCopy(context.item, context.source)) {
                    _copy = context.item.cloneNode(true);
                    drake.emit("cloned", _copy, context.item, "copy");
                  }
  
                  _source = context.source;
                  _item = context.item;
                  _initialSibling = _currentSibling = nextEl(context.item);
  
                  drake.dragging = true;
                  drake.emit("drag", _item, _source);
                }
  
                function invalidTarget() {
                  return false;
                }
  
                function end() {
                  if (!drake.dragging) {
                    return;
                  }
                  var item = _copy || _item;
                  drop(item, getParent(item));
                }
  
                function ungrab() {
                  _grabbed = false;
                  eventualMovements(true);
                  movements(true);
                }
  
                function release(e) {
                  ungrab();
  
                  if (!drake.dragging) {
                    return;
                  }
                  var item = _copy || _item;
                  var clientX = getCoord("clientX", e) || 0;
                  var clientY = getCoord("clientY", e) || 0;
                  var elementBehindCursor = getElementBehindPoint(
                    _mirror,
                    clientX,
                    clientY
                  );
                  var dropTarget = findDropTarget(
                    elementBehindCursor,
                    clientX,
                    clientY
                  );
                  if (
                    dropTarget &&
                    ((_copy && o.copySortSource) ||
                      !_copy ||
                      dropTarget !== _source)
                  ) {
                    drop(item, dropTarget);
                  } else if (o.removeOnSpill) {
                    remove();
                  } else {
                    cancel();
                  }
                }
  
                function drop(item, target) {
                  var parent = getParent(item);
                  if (_copy && o.copySortSource && target === _source) {
                    parent.removeChild(_item);
                  }
                  if (isInitialPlacement(target)) {
                    drake.emit("cancel", item, _source, _source);
                  } else {
                    drake.emit("drop", item, target, _source, _currentSibling);
                  }
                  cleanup();
                }
  
                function remove() {
                  if (!drake.dragging) {
                    return;
                  }
                  var item = _copy || _item;
                  var parent = getParent(item);
                  if (parent) {
                    parent.removeChild(item);
                  }
                  drake.emit(_copy ? "cancel" : "remove", item, parent, _source);
                  cleanup();
                }
  
                function cancel(revert) {
                  if (!drake.dragging) {
                    return;
                  }
                  var reverts = arguments.length > 0 ? revert : o.revertOnSpill;
                  var item = _copy || _item;
                  var parent = getParent(item);
                  var initial = isInitialPlacement(parent);
                  if (initial === false && reverts) {
                    if (_copy) {
                      if (parent) {
                        parent.removeChild(_copy);
                      }
                    } else {
                      _source.insertBefore(item, _initialSibling);
                    }
                  }
                  if (initial || reverts) {
                    drake.emit("cancel", item, _source, _source);
                  } else {
                    drake.emit("drop", item, parent, _source, _currentSibling);
                  }
                  cleanup();
                }
  
                function cleanup() {
                  var item = _copy || _item;
                  ungrab();
                  removeMirrorImage();
                  if (item) {
                    classes.rm(item, "gu-transit");
                  }
                  if (_renderTimer) {
                    clearTimeout(_renderTimer);
                  }
                  drake.dragging = false;
                  if (_lastDropTarget) {
                    drake.emit("out", item, _lastDropTarget, _source);
                  }
                  drake.emit("dragend", item);
                  _source =
                    _item =
                    _copy =
                    _initialSibling =
                    _currentSibling =
                    _renderTimer =
                    _lastDropTarget =
                    null;
                }
  
                function isInitialPlacement(target, s) {
                  var sibling;
                  if (s !== void 0) {
                    sibling = s;
                  } else if (_mirror) {
                    sibling = _currentSibling;
                  } else {
                    sibling = nextEl(_copy || _item);
                  }
                  return target === _source && sibling === _initialSibling;
                }
  
                function findDropTarget(elementBehindCursor, clientX, clientY) {
                  var target = elementBehindCursor;
                  while (target && !accepted()) {
                    target = getParent(target);
                  }
                  return target;
  
                  function accepted() {
                    var droppable = isContainer(target);
                    if (droppable === false) {
                      return false;
                    }
  
                    var immediate = getImmediateChild(
                      target,
                      elementBehindCursor
                    );
                    var reference = getReference(
                      target,
                      immediate,
                      clientX,
                      clientY
                    );
                    var initial = isInitialPlacement(target, reference);
                    if (initial) {
                      return true; // should always be able to drop it right back where it was
                    }
                    return o.accepts(_item, target, _source, reference);
                  }
                }
  
                function drag(e) {
                  if (!_mirror) {
                    return;
                  }
                  // e.preventDefault();
  
                  var clientX = getCoord("clientX", e) || 0;
                  var clientY = getCoord("clientY", e) || 0;
                  var x = clientX - _offsetX;
                  var y = clientY - _offsetY;
  
                  _mirror.style.left = x + "px";
                  _mirror.style.top = y + "px";
  
                  var item = _copy || _item;
                  var elementBehindCursor = getElementBehindPoint(
                    _mirror,
                    clientX,
                    clientY
                  );
                  var dropTarget = findDropTarget(
                    elementBehindCursor,
                    clientX,
                    clientY
                  );
                  var changed =
                    dropTarget !== null && dropTarget !== _lastDropTarget;
                  if (changed || dropTarget === null) {
                    out();
                    _lastDropTarget = dropTarget;
                    over();
                  }
                  var parent = getParent(item);
                  if (dropTarget === _source && _copy && !o.copySortSource) {
                    if (parent) {
                      parent.removeChild(item);
                    }
                    return;
                  }
                  var reference;
                  var immediate = getImmediateChild(
                    dropTarget,
                    elementBehindCursor
                  );
                  if (immediate !== null) {
                    reference = getReference(
                      dropTarget,
                      immediate,
                      clientX,
                      clientY
                    );
                  } else if (o.revertOnSpill === true && !_copy) {
                    reference = _initialSibling;
                    dropTarget = _source;
                  } else {
                    if (_copy && parent) {
                      parent.removeChild(item);
                    }
                    return;
                  }
                  if (
                    (reference === null && changed) ||
                    (reference !== item && reference !== nextEl(item))
                  ) {
                    _currentSibling = reference;
                    dropTarget.insertBefore(item, reference);
                    drake.emit("shadow", item, dropTarget, _source);
                  }
                  function moved(type) {
                    drake.emit(type, item, _lastDropTarget, _source);
                  }
                  function over() {
                    if (changed) {
                      moved("over");
                    }
                  }
                  function out() {
                    if (_lastDropTarget) {
                      moved("out");
                    }
                  }
                }
  
                function spillOver(el) {
                  classes.rm(el, "gu-hide");
                }
  
                function spillOut(el) {
                  if (drake.dragging) {
                    classes.add(el, "gu-hide");
                  }
                }
  
                function renderMirrorImage() {
                  if (_mirror) {
                    return;
                  }
                  var rect = _item.getBoundingClientRect();
                  _mirror = _item.cloneNode(true);
                  _mirror.style.width = getRectWidth(rect) + "px";
                  _mirror.style.height = getRectHeight(rect) + "px";
                  classes.rm(_mirror, "gu-transit");
                  classes.add(_mirror, "gu-mirror");
                  o.mirrorContainer.appendChild(_mirror);
                  touchy(documentElement, "add", "mousemove", drag);
                  classes.add(o.mirrorContainer, "gu-unselectable");
                  drake.emit("cloned", _mirror, _item, "mirror");
                }
  
                function removeMirrorImage() {
                  if (_mirror) {
                    classes.rm(o.mirrorContainer, "gu-unselectable");
                    touchy(documentElement, "remove", "mousemove", drag);
                    getParent(_mirror).removeChild(_mirror);
                    _mirror = null;
                  }
                }
  
                function getImmediateChild(dropTarget, target) {
                  var immediate = target;
                  while (
                    immediate !== dropTarget &&
                    getParent(immediate) !== dropTarget
                  ) {
                    immediate = getParent(immediate);
                  }
                  if (immediate === documentElement) {
                    return null;
                  }
                  return immediate;
                }
  
                function getReference(dropTarget, target, x, y) {
                  var horizontal = o.direction === "horizontal";
                  var reference = target !== dropTarget ? inside() : outside();
                  return reference;
  
                  function outside() {
                    // slower, but able to figure out any position
                    var len = dropTarget.children.length;
                    var i;
                    var el;
                    var rect;
                    for (i = 0; i < len; i++) {
                      el = dropTarget.children[i];
                      rect = el.getBoundingClientRect();
                      if (horizontal && rect.left + rect.width / 2 > x) {
                        return el;
                      }
                      if (!horizontal && rect.top + rect.height / 2 > y) {
                        return el;
                      }
                    }
                    return null;
                  }
  
                  function inside() {
                    // faster, but only available if dropped inside a child element
                    var rect = target.getBoundingClientRect();
                    if (horizontal) {
                      return resolve(x > rect.left + getRectWidth(rect) / 2);
                    }
                    return resolve(y > rect.top + getRectHeight(rect) / 2);
                  }
  
                  function resolve(after) {
                    return after ? nextEl(target) : target;
                  }
                }
  
                function isCopy(item, container) {
                  return typeof o.copy === "boolean"
                    ? o.copy
                    : o.copy(item, container);
                }
              }
  
              function touchy(el, op, type, fn) {
                var touch = {
                  mouseup: "touchend",
                  mousedown: "touchstart",
                  mousemove: "touchmove",
                };
                var pointers = {
                  mouseup: "pointerup",
                  mousedown: "pointerdown",
                  mousemove: "pointermove",
                };
                var microsoft = {
                  mouseup: "MSPointerUp",
                  mousedown: "MSPointerDown",
                  mousemove: "MSPointerMove",
                };
                if (global.navigator.pointerEnabled) {
                  crossvent[op](el, pointers[type], fn);
                } else if (global.navigator.msPointerEnabled) {
                  crossvent[op](el, microsoft[type], fn);
                } else {
                  crossvent[op](el, touch[type], fn);
                  crossvent[op](el, type, fn);
                }
              }
  
              function whichMouseButton(e) {
                if (e.touches !== void 0) {
                  return e.touches.length;
                }
                if (e.which !== void 0 && e.which !== 0) {
                  return e.which;
                } // see https://github.com/bevacqua/dragula/issues/261
                if (e.buttons !== void 0) {
                  return e.buttons;
                }
                var button = e.button;
                if (button !== void 0) {
                  // see https://github.com/jquery/jquery/blob/99e8ff1baa7ae341e94bb89c3e84570c7c3ad9ea/src/event.js#L573-L575
                  return button & 1 ? 1 : button & 2 ? 3 : button & 4 ? 2 : 0;
                }
              }
  
              function getOffset(el) {
                var rect = el.getBoundingClientRect();
                return {
                  left: rect.left + getScroll("scrollLeft", "pageXOffset"),
                  top: rect.top + getScroll("scrollTop", "pageYOffset"),
                };
              }
  
              function getScroll(scrollProp, offsetProp) {
                if (typeof global[offsetProp] !== "undefined") {
                  return global[offsetProp];
                }
                if (documentElement.clientHeight) {
                  return documentElement[scrollProp];
                }
                return doc.body[scrollProp];
              }
  
              function getElementBehindPoint(point, x, y) {
                point = point || {};
                var state = point.className || "";
                var el;
                point.className += " gu-hide";
                el = doc.elementFromPoint(x, y);
                point.className = state;
                return el;
              }
  
              function never() {
                return false;
              }
              function always() {
                return true;
              }
              function getRectWidth(rect) {
                return rect.width || rect.right - rect.left;
              }
              function getRectHeight(rect) {
                return rect.height || rect.bottom - rect.top;
              }
              function getParent(el) {
                return el.parentNode == doc ? null : el.parentNode;
              }
              function isInput(el) {
                return (
                  el.tagName === "INPUT" ||
                  el.tagName === "TEXTAREA" ||
                  el.tagName === "SELECT" ||
                  isEditable(el)
                );
              }
              function isEditable(el) {
                if (!el) {
                  return false;
                } // no parents were editable
                if (el.contentEditable === "false") {
                  return false;
                } // stop the lookup
                if (el.contentEditable === "true") {
                  return true;
                } // found a contentEditable element in the chain
                return isEditable(getParent(el)); // contentEditable is set to 'inherit'
              }
  
              function nextEl(el) {
                return el.nextElementSibling || manually();
                function manually() {
                  var sibling = el;
                  do {
                    sibling = sibling.nextSibling;
                  } while (sibling && sibling.nodeType !== 1);
                  return sibling;
                }
              }
  
              function getEventHost(e) {
                // on touchend event, we have to use `e.changedTouches`
                if (e.targetTouches && e.targetTouches.length) {
                  return e.targetTouches[0];
                }
                if (e.changedTouches && e.changedTouches.length) {
                  return e.changedTouches[0];
                }
                return e;
              }
  
              function getCoord(coord, e) {
                var host = getEventHost(e);
                var missMap = {
                  pageX: "clientX", // IE8
                  pageY: "clientY", // IE8
                };
                if (
                  coord in missMap &&
                  !(coord in host) &&
                  missMap[coord] in host
                ) {
                  coord = missMap[coord];
                }
                return host[coord];
              }
  
              module.exports = dragula;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
                ? self
                : typeof window !== "undefined"
                  ? window
                  : {}
          ));
        },
        { "./classes": 8, "contra/emitter": 4, crossvent: 5 },
      ],
      10: [
        function (require, module, exports) {
          // shim for using process in browser
          var process = (module.exports = {});
  
          // cached from whatever global is present so that test runners that stub it
          // don't break things.  But we need to wrap it in a try catch in case it is
          // wrapped in strict mode code which doesn't define any globals.  It's inside a
          // function because try/catches deoptimize in certain engines.
  
          var cachedSetTimeout;
          var cachedClearTimeout;
  
          function defaultSetTimout() {
            throw new Error("setTimeout has not been defined");
          }
          function defaultClearTimeout() {
            throw new Error("clearTimeout has not been defined");
          }
          (function () {
            try {
              if (typeof setTimeout === "function") {
                cachedSetTimeout = setTimeout;
              } else {
                cachedSetTimeout = defaultSetTimout;
              }
            } catch (e) {
              cachedSetTimeout = defaultSetTimout;
            }
            try {
              if (typeof clearTimeout === "function") {
                cachedClearTimeout = clearTimeout;
              } else {
                cachedClearTimeout = defaultClearTimeout;
              }
            } catch (e) {
              cachedClearTimeout = defaultClearTimeout;
            }
          })();
          function runTimeout(fun) {
            if (cachedSetTimeout === setTimeout) {
              //normal enviroments in sane situations
              return setTimeout(fun, 0);
            }
            // if setTimeout wasn't available but was latter defined
            if (
              (cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) &&
              setTimeout
            ) {
              cachedSetTimeout = setTimeout;
              return setTimeout(fun, 0);
            }
            try {
              // when when somebody has screwed with setTimeout but no I.E. maddness
              return cachedSetTimeout(fun, 0);
            } catch (e) {
              try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
                return cachedSetTimeout.call(null, fun, 0);
              } catch (e) {
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
                return cachedSetTimeout.call(this, fun, 0);
              }
            }
          }
          function runClearTimeout(marker) {
            if (cachedClearTimeout === clearTimeout) {
              //normal enviroments in sane situations
              return clearTimeout(marker);
            }
            // if clearTimeout wasn't available but was latter defined
            if (
              (cachedClearTimeout === defaultClearTimeout ||
                !cachedClearTimeout) &&
              clearTimeout
            ) {
              cachedClearTimeout = clearTimeout;
              return clearTimeout(marker);
            }
            try {
              // when when somebody has screwed with setTimeout but no I.E. maddness
              return cachedClearTimeout(marker);
            } catch (e) {
              try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
                return cachedClearTimeout.call(null, marker);
              } catch (e) {
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
                // Some versions of I.E. have different rules for clearTimeout vs setTimeout
                return cachedClearTimeout.call(this, marker);
              }
            }
          }
          var queue = [];
          var draining = false;
          var currentQueue;
          var queueIndex = -1;
  
          function cleanUpNextTick() {
            if (!draining || !currentQueue) {
              return;
            }
            draining = false;
            if (currentQueue.length) {
              queue = currentQueue.concat(queue);
            } else {
              queueIndex = -1;
            }
            if (queue.length) {
              drainQueue();
            }
          }
  
          function drainQueue() {
            if (draining) {
              return;
            }
            var timeout = runTimeout(cleanUpNextTick);
            draining = true;
  
            var len = queue.length;
            while (len) {
              currentQueue = queue;
              queue = [];
              while (++queueIndex < len) {
                if (currentQueue) {
                  currentQueue[queueIndex].run();
                }
              }
              queueIndex = -1;
              len = queue.length;
            }
            currentQueue = null;
            draining = false;
            runClearTimeout(timeout);
          }
  
          process.nextTick = function (fun) {
            var args = new Array(arguments.length - 1);
            if (arguments.length > 1) {
              for (var i = 1; i < arguments.length; i++) {
                args[i - 1] = arguments[i];
              }
            }
            queue.push(new Item(fun, args));
            if (queue.length === 1 && !draining) {
              runTimeout(drainQueue);
            }
          };
  
          // v8 likes predictible objects
          function Item(fun, array) {
            this.fun = fun;
            this.array = array;
          }
          Item.prototype.run = function () {
            this.fun.apply(null, this.array);
          };
          process.title = "browser";
          process.browser = true;
          process.env = {};
          process.argv = [];
          process.version = ""; // empty string to avoid regexp issues
          process.versions = {};
  
          function noop() { }
  
          process.on = noop;
          process.addListener = noop;
          process.once = noop;
          process.off = noop;
          process.removeListener = noop;
          process.removeAllListeners = noop;
          process.emit = noop;
          process.prependListener = noop;
          process.prependOnceListener = noop;
  
          process.listeners = function (name) {
            return [];
          };
  
          process.binding = function (name) {
            throw new Error("process.binding is not supported");
          };
  
          process.cwd = function () {
            return "/";
          };
          process.chdir = function (dir) {
            throw new Error("process.chdir is not supported");
          };
          process.umask = function () {
            return 0;
          };
        },
        {},
      ],
      11: [
        function (require, module, exports) {
          (function (setImmediate) {
            (function () {
              var si = typeof setImmediate === "function",
                tick;
              if (si) {
                tick = function (fn) {
                  setImmediate(fn);
                };
              } else {
                tick = function (fn) {
                  setTimeout(fn, 0);
                };
              }
  
              module.exports = tick;
            }.call(this));
          }.call(this, require("timers").setImmediate));
        },
        { timers: 12 },
      ],
      12: [
        function (require, module, exports) {
          (function (setImmediate, clearImmediate) {
            (function () {
              var nextTick = require("process/browser.js").nextTick;
              var apply = Function.prototype.apply;
              var slice = Array.prototype.slice;
              var immediateIds = {};
              var nextImmediateId = 0;
  
              // DOM APIs, for completeness
  
              exports.setTimeout = function () {
                return new Timeout(
                  apply.call(setTimeout, window, arguments),
                  clearTimeout
                );
              };
              exports.setInterval = function () {
                return new Timeout(
                  apply.call(setInterval, window, arguments),
                  clearInterval
                );
              };
              exports.clearTimeout = exports.clearInterval = function (timeout) {
                timeout.close();
              };
  
              function Timeout(id, clearFn) {
                this._id = id;
                this._clearFn = clearFn;
              }
              Timeout.prototype.unref = Timeout.prototype.ref = function () { };
              Timeout.prototype.close = function () {
                this._clearFn.call(window, this._id);
              };
  
              // Does not start the time, just sets up the members needed.
              exports.enroll = function (item, msecs) {
                clearTimeout(item._idleTimeoutId);
                item._idleTimeout = msecs;
              };
  
              exports.unenroll = function (item) {
                clearTimeout(item._idleTimeoutId);
                item._idleTimeout = -1;
              };
  
              exports._unrefActive = exports.active = function (item) {
                clearTimeout(item._idleTimeoutId);
  
                var msecs = item._idleTimeout;
                if (msecs >= 0) {
                  item._idleTimeoutId = setTimeout(function onTimeout() {
                    if (item._onTimeout) item._onTimeout();
                  }, msecs);
                }
              };
  
              // That's not how node.js implements it but the exposed api is the same.
              exports.setImmediate =
                typeof setImmediate === "function"
                  ? setImmediate
                  : function (fn) {
                    var id = nextImmediateId++;
                    var args =
                      arguments.length < 2 ? false : slice.call(arguments, 1);
  
                    immediateIds[id] = true;
  
                    nextTick(function onNextTick() {
                      if (immediateIds[id]) {
                        // fn.call() is faster so we optimize for the common use-case
                        // @see http://jsperf.com/call-apply-segu
                        if (args) {
                          fn.apply(null, args);
                        } else {
                          fn.call(null);
                        }
                        // Prevent ids from leaking
                        exports.clearImmediate(id);
                      }
                    });
  
                    return id;
                  };
  
              exports.clearImmediate =
                typeof clearImmediate === "function"
                  ? clearImmediate
                  : function (id) {
                    delete immediateIds[id];
                  };
            }.call(this));
          }.call(
            this,
            require("timers").setImmediate,
            require("timers").clearImmediate
          ));
        },
        { "process/browser.js": 10, timers: 12 },
      ],
    },
    {},
    [1]
  );
  
  
  $(function() {
    // Function to initialize tooltips
    function initializeTooltips() {
      $('[data-toggle="tooltip"]').tooltip(); 
      $(".status-name").tooltip({
        position: {
          my: "bottom",
          at: "top"
        }
      });
    }
    var checkExist = setInterval(function() {
      if ($('[data-toggle="tooltip"]').length && $(".status-name").length) {
        clearInterval(checkExist); 
        initializeTooltips();
      }
    }, 100);
  });
  
  window.disableTabindex=function(modalSelector){
    if ($(modalSelector).is(':visible')) {
      $(":tabbable").attr("tabindex", -1);
      $(modalSelector + " [tabindex='-1']").attr("tabindex", 0);
      $("html").css("overflow", "hidden");
    } else {
      $("[tabindex]").removeAttr("tabindex");
      $("html").css("overflow", "auto");
    }
  }
  
  
  
  
  
  
  
  