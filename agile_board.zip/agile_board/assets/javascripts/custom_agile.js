function toggleGroup(el)
{

  var tr = $(el).parents('div').first();
  attrValue=$(el).attr('value');
  tr.toggleClass('open');
  $(el).toggleClass('icon-expended icon-collapsed');
  let div=document.getElementById(`group-${attrValue}`);
  div.classList.toggle('open-agile-container');
}

$(document).ready(function () {

    var url=window.location.origin
     
      // variable for all project issue in agile board to store in localstorage
    var card_array=[{name:"Issue ID", value:"id" }, {name:"Tracker", value:"tracker"}, {name:"Priority", value:"priority"},{name:"Assignee", value:"assigned_to"}, {name:"Subject",value:"subject"}, {name:"Start date", value:"start_date"},{name:"Due date", value:"due_date"}, {name:"Project", value:"project"}, {name:"Created", value:"created_on"}, {name:"Updated",value:"updated_on"},{name:"Estimated time",value:"estimated_hours"},{name:"% Done",  value:"done_ratio"}]
    // var total_hour=" ";
    var total_hour=0.00;
    var card_field=["id","tracker","priority","assigned_to","start_date","due_date","subject"];
    // var boards_array=[];
   
    var total_spent_time=0;
    var total_spent_time_project =0;
    var total_story_points =0;
    var total_issues;
    var total_time=[{name:"Estimated Time",value:"estimated_time"},{name:"Spent Time",value:"spent_time"}];
   
    // $(".buttons").css("display","none");
    let currentPage = 1;
    let limit = 25;
    let total = 0;

    // console.log(card_ids.length,"length");

    if (board_ids.length > 0) {
        board_ids = JSON.parse(board_ids);
        board_ids = board_ids.map(Number);
        project_boards_values = board_ids
     }
    
     if (card_ids.length > 0) {
        card_ids = JSON.parse(card_ids);
        card_ids = card_ids.map(Number);
     }

     if (time_ids.length > 0) {
        time_ids = JSON.parse(time_ids);
        time_ids = time_ids.map(Number);
     }

    
    $.ajax({
      type: "GET",
      url:url+`/card_fields.json?key=${api_key}`,
      dataType: "json",
      async:false,
      success: function (result, status, xhr) {

      var filteredFields = result.filter(field => card_ids.includes(field.id));
      var fieldNames = filteredFields.map(field => field.field_name);
      // console.log(fieldNames, 'field names =>');

      cards = fieldNames;
      project_cards = fieldNames;
        result.forEach((object,i)=>{
          card_fields.push(object);
        //   if (object.field_value === true ){
        //     cards.push(object.field_name);           
        //   }

        //   // project 
        //   if (object.project_field_value === true ){
        //       project_cards.push(object.field_name);                        
        //     }         
        })

        // console.log(card_ids ,'card_ids -->>');
        
        // -------project ---------
   
      }
    
    })
    // console.log(project_cards,"project cards");
    // console.log(cards,"cards ");
    // console.log(card_fields,"card_fields");
        
    

    window.fetchtags=function(){
      $.ajax({
        type: "GET",
        url:`${url}/show/tags.json?key=${api_key}`,
        dataType: "json",
        async:false,
        success: function (result, status, xhr) {
          // console.log(result,"result");
         return  issue_tag=result;
        }
      
      })
    }



   window.fetchnotes=function(){

      notes=[];
      
      let issue_ids=agile_issues.map((issue)=>{
        return issue.id;
      })
      $.ajax({
        type: "GET",
        url:`${url}/notes/count.json?key=${api_key}`,
        dataType: "json",
        async:false,
        data:{
          issue_ids:issue_ids
        },
        success: function (result, status, xhr) {
        //  return  issue_tag=result;
        // result=notes;
        notes=result;
        }
      
      })
    }



    $.ajax({
      type: "GET",
      url:url+`/total_time.json?key=${api_key}`,
      dataType: "json",
      async:false,
      success: function (result, status, xhr) {
        Total_time=result;
    }
    })

    // .......on scroll function 
    

    window.hasMoreData = function (page, limit, total) {
      const startIndex = (page - 1) * limit + 1;
      return total === 0 || startIndex < total;
    };

    // height check function 
    function increaseDynamicHeight() {
      //console.log('the function is run');
      var maxHeight = Math.max.apply(
        null,
        $(" .kanban-drag")
          .map(function () {
            return $(this).height();
          })
          .get()
      );

      $(".kanban-drag").css("min-height", maxHeight);
      $(".kanban-drag").css("padding", "0px 10px");
      // $(".kanban-drag").addClass('padding');
    }
    callscrollFunction();
    function callscrollFunction() {
      // console.log(  $("#myKanban").height(),"kaban height");
      // $("#query_form").before(
      //   `<div style="display:none" class="show-error" id='errorExplanation'><ul class="ul-time"><li>No tracker associated with  project please check your project setting</li></ul> </div>`
      // );

      $(document).on("scroll", function (e) {
        increaseDynamicHeight();
         if( ( $(window).scrollTop() + $(window).height() + 1) >= $(document).height() && hasMoreData(currentPage, limit, total)) {
          increaseDynamicHeight();
          // ajax call get data from server and append to the div
          currentPage++;
          loadData(currentPage, limit);
          // setTimeout(()=>{
          //   var boardElements = document.querySelectorAll('div.kanban-board');
          //   var allExpanded = Array.from(boardElements).every(function(element) {
          //           return element.classList.contains('expanded');
          //         });
          //         // If all elements have the class "expanded", add a minimum height to them
          //         if (allExpanded) {
          //           Array.from(boardElements).forEach(function(element) {
          //            element.style.minHeight = '79vh'; // Change this value to your desired minimum height
          //           });
          //         }
          //         else{
          //           Array.from(boardElements).forEach(function(element) {
          //             element.style.minHeight = '0px'; // Change this value to your desired minimum height
          //           });  
          //         }
          //    },500);
        }
      });
    }

    // when user scroll end function

    window.hideColumn = function (value) {
      // console.log(boardId.target.getAttribute("value"),"board IDD");
      let boardId=value.target.getAttribute("id");
      let mainEle=value.target.getAttribute("value");
     
      function toggleColumnExpansion(columnId) {
        const column = document.getElementById(columnId);
        if (column.classList.contains("expanded")) {
            localStorage.setItem(columnId, "expanded");
        } else {
            localStorage.setItem(columnId, "collapsed");
        }
    }
      const columns = document.querySelectorAll(".kanban-board");

      columns.forEach(column => {
          const columnId = column.id;
          column.addEventListener("click", function () {
              toggleColumnExpansion(columnId);
          });
      
          // Restore the state when the page loads
          // const initialState = localStorage.getItem(columnId);
          // console.log(columnId,"columns ID")
          // if (initialState === "collapsed") {
          //     toggleColumnExpansion(columnId);
          // }
     
      });

       const cards = document.querySelectorAll('.kanban-board');
     
      // Define a function to handle the click event
      function clickHandler() {
          // Increase the width of the clicked card by a certain amount (e.g., 50px)
            if(this.getAttribute("data-id")==boardId)
            {
              this.classList.toggle('expanded'); 
            } 
          
          // Toggle a class on elements with the class "header-back" when the card is expanded
          const headerBackElements = this.querySelectorAll('.header-back');
          headerBackElements.forEach(element => {
            if(this.getAttribute("data-id")==boardId)
            {
             element.classList.toggle('expanded-header-back');
           }  
          });
        // Toggle the visibility of the specified element when the card is expanded
     
        const footerElement = document.querySelector(`#${mainEle} > div.kanban-container > div.kanban-board.board${boardId} > footer`);
        const kanbanContent=  document.querySelector(`#${mainEle} > div.kanban-container > div.kanban-board.board${boardId} > main `);
        if (kanbanContent || footerElement ) {
            if(this.getAttribute("data-id")===boardId)
            {
              kanbanContent.classList.toggle('hidden'); 
              if(footerElement)
              {
                footerElement.classList.toggle('hidden');
              }
          
           }
        }
      // Remove the click event listener after it has been executed once
      this.removeEventListener('click', clickHandler);
      }
      // Add a click event listener to each card
         cards.forEach(card => {
           card.addEventListener('click', clickHandler);
        });
            // Get all the div elements with the class "kanban-board"
          var boardElements = document.querySelectorAll('div.kanban-board');
          // Check if all of them have the class "expanded"
      //     setTimeout(()=>{
      //       var allExpanded = Array.from(boardElements).every(function(element) {
      //         return element.classList.contains('expanded');
      //       });
      //       // If all elements have the class "expanded", add a minimum height to them
      //       if (allExpanded) {
      //         Array.from(boardElements).forEach(function(element) {
      //          element.style.minHeight = '79vh'; // Change this value to your desired minimum height
      //         });
      //       }
      //       else{
      //         Array.from(boardElements).forEach(function(element) {
      //           element.style.minHeight = '0px'; // Change this value to your desired minimum height
      //         });  
      //       }
      // })
  }
  

        window.toggleSet= function (el) {
 
                $("input[name='input-check']:checked").attr("checked","checked");
               $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                dataType: "json",
                success: function (result, status, xhr) {
              $(".table-div-board").html(" ");
                   let content=result.issue_statuses;
                   let board_data=JSON.parse(localStorage.getItem("boards"))
                   
                  content.forEach((object,i)=>{
                      if(i<4)
                      {
                        $(".table-div-board").append(`
                    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                   <div style="display:flex;">
                     <input checked  disabled name="input-board"  value=${object.id} class="board-checkbox" type="checkbox">
                   </div>
                  <div style="display:flex;">
                     <span  class="board-name">${object.name}</span>
                      </div>
                 </div>
                     `);
                      }
                      else if(board_data&&board_data.includes(object.id))
                      {
                        $(".table-div-board").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                        <div style="display:flex;">
                          <input checked  name="input-board"  value=${object.id} class="board-checkbox"   type="checkbox">
                        </div>
                       <div style="display:flex;">
                          <span  class="board-name">${object.name}</span>
                           </div>
                      </div>`);
                      }
                      else{
                           $(".table-div-board").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
                           <div style="display:flex;">
                             <input  name="input-board"  value=${object.id} class="board-checkbox"   type="checkbox">
                           </div>
                          <div style="display:flex;">
                             <span  class="board-name">${object.name}</span>
                              </div>
                        </div>`);
                      }
                   })
               
                },
                  error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
               })
               var fieldset = $(el).parents('fieldset').first();
               fieldset.toggleClass('collapsed');
               fieldset.children('legend').toggleClass('icon-collapsed icon-setting');
               fieldset.children('div').toggle();
             }
             window.toggleBoard=function (el)
             {
              var fieldset = $(el).parents('fieldset').first();
              fieldset.toggleClass('collapsed');
             fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
             fieldset.children('div').toggle();
             }
                    window.toggleCards=function (el)
             {
               var fieldset = $(el).parents('fieldset').first();
               fieldset.toggleClass('collapsed');
               fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
               fieldset.children('div').toggle();
             }
             window.clearOptions=function(){
              // localStorage.clear();      
              // location.reload();
              window.event.preventDefault();
              $(".context-menu-popup-main").css("display", "none");
               $(".setting-div").css("display", "none");
               $("[tabindex='-1']").attr("tabindex", 0);
               $("html").css("overflow", "auto");
             }
             
      function removeAjaxIndicator() {
  
          $(document).bind('ajaxSend', function(event, xhr, settings) {
            if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
            $('#ajax-indicator').hide();   
            }
          });
          $(document).bind('ajaxStop', function() {
            $('#ajax-indicator').hide(); 
          });
        }
     
       
          
          function getSpentTime(project_Id){
          
              $.ajax({
              type: "GET",
              url: self.url+`/time_entries.json?key=${api_key}`,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              success: function (result, status, xhr) {
              result.time_entries.reduce(function(sum, current) {
  
               return total_spent_time= sum + current.hours;
                 
            }, 0);

            // updateKanbanContainerStatus();

            // ----- call wip function ----
            
            // setTimeout(() => {
            //   updateWipLimits();
            //   }, 1000);

            //   setTimeout(() => {
            //     updateKanbanContainerStatus();
            //     }, 500);

// --------------particular projects spent time -------

            if(project_Id){
              $.ajax({
              type: "GET",
              url: self.url+`/time_entries.json?project_id=${project_Id}&key=${api_key}`,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              success: function (result, status, xhr) {
      
                // console.log(result,'this is particular projects spent time');
                // --------
                const params = window.location.search
                let  parameters = new URLSearchParams(params);
                var sprintId = parameters.get('sprint_craft');
                
                if (params.includes('sprint_craft')) {
                  result.time_entries = result.time_entries.filter(entry => entry.sprint_craft !== null && entry.sprint_craft == sprintId);
                }
                
                total_spent_time_project = result.time_entries.reduce(function(sum, current) {
                  return sum + current.hours;
                }, 0);
              

             
              },
              error: function(xhr, status, error) {
                // console.log("Error:", error);
              }

              
            });

            //  updateKanbanContainerStatus();

            // setTimeout(() => {
            //   updateWipLimits();
            //   }, 1000);
  
            //   setTimeout(() => {
            //     updateKanbanContainerStatus();
            //     }, 500);

            }

            if(project_Id){

              var url=window.location.origin
              const path = window.location.pathname;
              const pathSegments1 = path.split('/');
              var project_id1 = pathSegments1[2];
              const params1 = redirect_path.split('?')[1];
              // console.log(path,project_id1,pathSegments1,'dummyeikfk')
              $.ajax({
                type: "GET",
                          url: project_id1? url+`/projects/${project_id1}/issues.json?key=${api_key}&${params1}` :url+`/issues.json?key=${api_key}&${params1}` ,
                          dataType: "json",
                          success: function (res, status, xhr) {
                                var totalEstimatedHours = res.issues.reduce((sum, issue) => {
                                  return sum + (issue.estimated_hours || 0);
                                }, 0);
                                var totalSpentHours = res.issues.reduce((sum, issue) => {
                                  return sum + (issue.spent_hours || 0);
                                }, 0);
                                var totalStoryPoints = res.issues.reduce((sum, issue) => {
                                  return sum + (issue.story_points || 0);
                                }, 0);
                                // console.log(totalEstimatedHours, "EstimatedHours")
                                // console.log(totalSpentHours,"totalSpentHours")
                                // console.log(totalStoryPoints,"totalStoryPoints")
                                Total_time.forEach((object,i)=>{
                                  if (object.time_field === "Story Points" && view_story_point === true && time_ids.includes(object.id) ) {                                                              
                                     $("#query-id").css("display","flex");
                                     $(".total-for-story-point").css("display","flex");
                                     totalStoryPoints = parseFloat(totalStoryPoints).toFixed(2);
                                     $(".value-story-points").html(totalStoryPoints);
                                  }
                                  if (object.time_field === "Spent Time" && time_ids.includes(object.id) && view_spent_time === true){
                                    $("#query-id").css("display","flex");
                                    $(".total-for-spent-hours").css("display","flex");
                                    totalSpentHours=parseFloat(totalSpentHours).toFixed(2);
                                    $(".value-spent-time").html(totalSpentHours);
                                  }
              
                                  if (object.time_field === "Estimated Time" && time_ids.includes(object.id) && view_estimated_time === true) {
                                    $("#query-id").css("display", "flex");
                                    $(".total-for-estimated-hours").css("display", "flex");
                                    totalEstimatedHours = isNaN(totalEstimatedHours) ? "0.00" : parseFloat(totalEstimatedHours).toFixed(2);
                                    $(".value-estimated-time").html(totalEstimatedHours);
                                }
                                
                              
                              });
                            },
                            error: function(xhr, status, error) {
                            }
              });
 

                }


              //   if(project_Id){
              //       Total_time.forEach((object,i)=>{
                    
              //         if (object.id === 2 && time_ids.includes(object.id) && view_spent_time === true){
              //           $("#query-id").css("display","flex");
              //           $(".total-for-spent-hours").css("display","flex");
              //                if(project_Id)
              //                 {

              //                    total_spent_time_project=parseFloat(total_spent_time_project).toFixed(2);
              //               $(".value-spent-time").html(total_spent_time_project);
                            
                         
              //                }
              //                else{
              //                total_spent_time=parseFloat(total_spent_time).toFixed(2);
              //              $(".value-spent-time").html(total_spent_time);
                           
              //       }
              //     }
              //   })
              // } 
                    
            //       }
            //     })
            //   }
            // })
                  //})
              },
      
              error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
            })
          }
          
        function showSettings(){

           $(` <!--  <div  id="query_form_with_buttons" class="hide-when-print setting-agile outside">
             <div id="query_form_content">
               <fieldset  class="collapsible collapsed">
               <legend onclick="toggleSet(this)" class="icon icon-collapsed">Settings</legend>
                 <div class="table-div" style="display:none">
                    <table >
                    <tbody>
                    <tr>
                    <td colspan="2">
                    <fieldset   style="margin-bottom:13px;"   class="collapsible collapsed">
                      <legend  id="legend-setting" onclick="toggleBoard(this)" class="icon icon-boards">Board columns</legend>
                          <div class="table-div-board" style="display:flex; flex-wrap:wrap;">
                            
                          </div>
                    </fieldset>
                    </td>
                    </tr>
                         <tr>
                    <td colspan="2">
                    <fieldset  style="margin-bottom:13px;" class="collapsible collapsed">
                      <legend onclick="toggleCards(this)" class="icon icon-boards">Card fields</legend>
                          <div class="table-div-cardfields" style="display:flex; flex-wrap:wrap;" >
                          </div>
                    </fieldset>
                    </td>
                    </tr>
                        <tr>
                    <td colspan="2">
                    <div style="display:flex;  flex-direction:column; gap:6px; margin-bottom:13px;">
                       <div style="display:flex; flex-direction:row; margin-bottom:0.25rem; gap:20px;">
                       <div  style="display:flex; justify-content:center; align-items:center;">
                       <div   style="display:flex; ">
                          <label class="agile_options_label">
                           Colored by
                           </label>
                           </div>
                           </div>
                           <div style="display:flex;">
                             <select name="color_base" id="color_base">
                               <option value="none">No colors</option>
                               <option  value="tracker">Tracker</option>
                               <option value="priority">Priority</option>
                               <option  value="user">Assignee</option>
                         </select>  
                         </div> 
                         </div>
                     
                    </td>
                    </tr>
                   <tr>
                      <td colspan="2">
                    <div style="display:flex; flex-direction:row;  gap:22px;">
                      <div  style="display:flex;">
                      <label  class="agile_options_label">Totals</label>
                      </div>
                      <div   style="display:flex;" class="total_time">
                      </div>
                  </div>
                      </td>
                    </tr>
                    </tbody>
                    </table>
                    </div>
             </div>
            <p   style="margin-bottom:32px !important"; id="setting-button" class="buttons">
            <a  style="cursor:pointer"  onclick="updateOptions()"  class="icon icon-checked"">Apply</a>
            <a   style="cursor:pointer"  onclick="clearOptions()"  class="icon icon-reload" >Clear</a>
               
            </p>
          </div>
          --> `).insertAfter("#query_form");
            let time=JSON.parse(localStorage.getItem("total_time"));
            // console.log(time,"time");
           total_time.forEach((list,i)=>{
            if(time&&time.includes(list.value))
            {
             $(".total_time").append(`
             <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input checked name="time-check" value=${list.value} class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
            else{
             $(".total_time").append(`  <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input  name="time-check" value=${list.value} class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
            })
          let card_data=JSON.parse(localStorage.getItem("card_fields"))
          // console.log(card_data,"card data");
           card_array.forEach((list,i)=>{
            if((list.value==="id")||(list.value==="tracker")||(list.value==="priority")||(list.value==="assigned_to")||(list.value==="start_date")||(list.value==="due_date")||(list.value==="subject"))
            {
             $(".table-div-cardfields").append(` <label class="floating">
             <input name="input-check"  disabled checked value=${list.value}  class="board-checkbox"  type="checkbox" >
                 ${list.name}
            </label>`)
            }
            else if(card_data&&card_data.includes(list.value))
            {
              $(".table-div-cardfields").append(`
              <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
              <div style="display:flex;">
              <input name="input-check"   checked value=${list.value}  class="board-checkbox"  type="checkbox" >
              </div>
             <div style="display:flex;">
                <span  class="board-name"> ${list.name}</span>
                 </div>
             </div>
            `)
            }
            else{
             $(".table-div-cardfields").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
             <div style="display:flex;">
             <input name="input-check"    value=${list.value}  class="board-checkbox"  type="checkbox" >
             </div>
            <div style="display:flex;">
               <span  class="board-name"> ${list.name}</span>
                </div>
            </div>`)
            }
        })
        }
       
        
      
        window.getWorkflow=function(id){
           // var workflow_status;
               $.ajax({
              type: "GET",
              url: `${self.url}/tracker_workflow_status.json?key=${api_key}` ,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              data:  {
                issue_id:parseInt(id)
              },
              success: function (result, status, xhr) {
                 workflow_status= result;
              },
              error: function (xhr, status, error) {
                // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
            })
            
            return workflow_status;
        }
        window.getRedmineWorkflow=function(){
          var workflow;
          $.ajax({
         type: "GET",
         url: `${self.url}/workflow/transitions.json?role_id=3&tracker_id=6&key=${api_key}` ,
         dataType: "json",
         async:false,
         contentType: 'application/json',
     
         success: function (result, status, xhr) {
          // console.log(result.transitions,"result of workflow transitions ")
           workflow= result.transitions;
         },
         error: function (xhr, status, error) {
           // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
          }
       })
       //console.log(workflow,"worflow Satus ");
       return workflow;
 
 
 
 
      }
// ------------------------------------------------------------my code ------------------------------------

$(document).ready(function () {

    // console.log(board_ids.length,"length");
    


    
//   $.ajax({
//     type: "GET",
//     url:url+`/agile_issue_statuses.json?key=${api_key}`,
//     dataType: "json",
//     async:false,
//     success: function (result, status, xhr) {
//       var boards_result = result.Issue_statuses ;

//       boards_result.forEach((object,i)=>{
//          if (object.agile_boards === true ){     
//           boardss.push(object.id);
      
//         }
//       })

//     //   --------perticular - project ---------
//       boards_result.forEach((object,i)=>{
//         if (object.agile_project_status === true ){     
//           project_boards_values.push(object.id);
     
//        }
//      })
   
//     }})






// -------------------------------------------------------------------------------------------------------------------
  
        //  $("#options").css("display","none"); 
        $("#list-definition > tbody > tr:nth-child(1)").css("display","none");
        $("#list-definition > tbody > tr:nth-child(3)").css("display","none");
        $("#list-definition > tbody > tr:nth-child(4)").css("display","none");
        // $("fieldset#options > div.hidden").css("display","block");
        // $("fieldset#options > legend").css("display","none");
        // $("fieldset#options").css("border","none");
              showSettings();
              removeAjaxIndicator();
                const params =window.location.search
                const parameters = new URLSearchParams(params);
                if(window.location.href===`${url}/agile_board`)
                {
                    // console.log("this 1");
                    
               $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,                
                dataType: "json",
                success: function (result, status, xhr) {

                const params =window.location.search
                 let  parameters = new URLSearchParams(params);
                const  project_id = parameters.get('project_id');
                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&&include=trackers`:url+`/issues.json?key=${api_key}&include=journals`,
                dataType: "json",
                beforeSend: function(){
                let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                let div=document.createElement("div");
                div.className="unknown-div";
                div.style.display="block";
                body_div[0].appendChild(div);
                 $('.circle-loader').show();
               },
                success: function (res, status, xhr) {
                 // console.log("running 1");
                  total_issues= res.total_count;
                  //console.log(total_issues,"toal issues");
                if(res.issues.length==0)
                {
                  $(".nodata").css("display","none");
                  $("#myKanban").css("display","block");
                  // $("#myKanban").css("display","none");
                  // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                }
                else{
                    
                      agile_issues=res.issues;
                       $(".nodata").css("display","none");
                       $("#myKanban").css("display","block");
                }
                
                 getSpentTime(project_id);
                  $('.circle-loader').toggleClass('load-complete');
                 $('.checkmark').toggle();
                  setTimeout(() => { 
                  $(".unknown-div").css("display","none");
                  $('.circle-loader').hide();
                  }, 300);
            
                  result.issue_statuses.forEach(object => {
                    
                            object.item= []
                            
                  });
        
                  //  code to call tag and note API 
                  if(cards.includes("Tags")&&tagPluginExists)
                  {
                   fetchtags();
              
                  }
                  if(project_id)
                  {
                    if(project_cards.includes("Notes"))
                    {
                     
                     fetchnotes();
                    }
                  }
                  else{
                    if(cards.includes("Notes"))
                    {
                     fetchnotes();
                    }
                  }
               
                // console.log(getWorkflow(),"getworloadflow")
                  res.issues.forEach(object => {
                     result.issue_statuses.forEach(option=>{
                    
                       if(object.status.name==option.name)
                        {
                         option.item.push(object)
                          }
                        });
                     });           
                 
                   const  array_item=[];
                    result.issue_statuses.forEach(object => {
                   
                            array_item.push(''+object.id)    
                  });
                
                   result.issue_statuses.forEach((object,i)=> {
                    
                     if(i<6)
                        {
                           boards_array.push(object)
                          
                         }
            
                        else if(boardss){
                          boardss.forEach((list)=>{
                           if(list==object.id)
                           {
                             boards_array.push(object)
                            //  console.log(boards_array,'condition of only 4');
                            //  console.log(object,'condition of only 4 object');
                             
                           }
                          })
                        }

                            object.id=''+object.id
                            object.dragTo=array_item
                            object.issueCount=object.item.length
                            object.total_issue_count=total_issues
                           
                        });
                      
                   
                  
                 //if(JSON.parse(localStorage.getItem("boards")))
                 //{
                  let local_data= boardss
                  
                   //let local_data_2= JSON.parse(localStorage.getItem("boards"))
                   //console.log(local_data,'boards valueeessss');
                       result.issue_statuses.forEach((object,i)=> {
                            if(local_data.includes(object.id))
                            {
                               boards_array.push(object)
                            }
                            
                       })
                //}
                //console.log(boards_array,"boards array after local stoarge")
                // ----
                   if(res.issues.length!=0)
                  {
                  res.issues.reduce(function(sum, current) {
                    //  console.log(current.estimated_hours,"current esitmeatd hour");
                     return total_hour= sum + current.estimated_hours;
                    
                      }, 0); 
                    }
                    else{
                      total_hour=0.00;
                    }
                     
// --------------------------------
                    if(res.issues.length!=0)
                    {
                    res.issues.reduce(function(sum, current) {
                      //  console.log(current.estimated_hours,"current esitmeatd hour");
                      return total_story_points=total_story_points +current.story_points;
                      
                        }, 0); 
                      }
                      else{
                        total_story_points=0.00;
                      }
                // console.log(total_story_points,">>>>>>>")

                        //  if(!localStorage.getItem("total_time"))
                        //   {
                        //     localStorage.setItem("total_time",JSON.stringify(total_time))
                        //    }
                        
// ----
                         //if(JSON.parse(localStorage.getItem("total_time")))
                         //{   
                         //JSON.parse(localStorage.getItem("total_time")).forEach((object,i)=>{

                        //if(object==="estimated_time")
                        // console.log(Total_time,"toa time")
                        //Total_time.forEach((object,i)=> {
                                // console.log(object,"object")
    
                        //   if (object.id === 1 && object.time_value === true && view_estimated_time === true)
                        //   {
                        //     if(total_hour!=NaN)
                        //     {
                        //     $("#query-id").css("display","flex");
                        //     $(".total-for-estimated-hours").css("display","flex");
                        //      total_hour=parseFloat(total_hour).toFixed(2);
                        //     $(".value-estimated-time").html(total_hour);
                        //     }
                        //     else{
                        //        $(".value-estimated-time").html("0.00");
                        //     }
                        //   }
                        //   if (object.id === 2 && object.time_value === true && view_spent_time === true)
                        //   {
                        //     $("#query-id").css("display","flex");
                        //     $(".total-for-spent-hours").css("display","flex");
                           
                        //          total_spent_time=parseFloat(total_spent_time).toFixed(2);
                        //        $(".value-spent-time").html(total_spent_time);
                        //         // console.log("this is  outside project");
                        //   }
                    //       if (object.timefield === "Story Points" && object.time_value === true && view_story_point === true) {
                    //         $("#query-id").css("display", "flex");
                    //         $(".total-for-story-point").css("display", "flex");
                    //         total_story_points = parseFloat(total_story_points).toFixed(2);
                    //         $(".value-story-points").html(total_story_points);
                    //   }
                         // })

                               // --------
      // if(project_id){
      //   Total_time.forEach((object,i)=>{
      //     if (object.time_field === "Story Points" && time_ids.includes(object.id) && view_story_point === true ){

          

        
      //     $("#query-id").css("display","flex");
      //       $(".total-for-story-point").css("display","flex");
      //           if(project_id)
      //             {
      //               total_story_points=parseFloat(total_story_points).toFixed(2);
      //           $(".value-story-points").html(total_story_points);
                
            
      //           }
      //           else{
      //             total_story_points=parseFloat(total_story_points).toFixed(2);
      //         $(".value-story-points").html(total_story_points);
              
      //   }
      // }
      // })
      // }
    //    else {
    //   Total_time.forEach((object,i)=>{
    //   if (object.time_field === "Story Points" && object.time_value === true && view_story_point === true){

    //   $("#query-id").css("display","flex");
    //     $(".total-for-story-point").css("display","flex");
    //         if(project_id)
    //           {
    //             total_story_points=parseFloat(total_story_points).toFixed(2);
    //         $(".value-story-points").html(total_story_points);
            
        
    //         }
    //         else{
    //           total_story_points=parseFloat(total_story_points).toFixed(2);
    //       $(".value-story-points").html(total_story_points);
          
    //   }
    //   }
    //   })
    //   }
// ---------
                          
                       
                      
       
                 var KanbanTest = new jKanban({
                  element: "#myKanban",
                  color:"red",
                  // gutter: "10px",
                  // widthBoard: "420px",
                  
                  itemHandleOptions:{
                    enabled: true,
                  },
                 context: function(el, e) {
                 },
                 dropEl: function(el, target, source, target_id,source_id){
      
                  getWorkflow(el.dataset.eid);

                  var target_int = parseInt(target_id);
                
                  toastr.options = {
                    closeButton: true,
                    debug: false,
                    newestOnTop: false,
                    progressBar: true,
                    positionClass: "toast-top-right",
                    preventDuplicates: false,
                    onclick: null,
                    showDuration: "300",
                    hideDuration: "1000",
                    timeOut: "2000",
                    extendedTimeOut: "1000",
                    showEasing: "swing",
                    hideEasing: "linear",
                    showMethod: "fadeIn",
                    hideMethod: "fadeOut",
                  };
                  
                


                  if (workflow_status.includes(target_int)) {
                    // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully ");                    
                    // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                    // console.log("successfully applied 1");
                    // console.log(target,"target");
                    // console.log(source,"source");
                    var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                    var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);
  
                    // console.log(header_kanban,"header kanban");
                    // console.log(matches,"matches");
                    if (matches && matches.length === 3) {
                      // Extracted values in integer format
                      var value1 = parseInt(matches[1]);
                      var value2 = parseInt(matches[2]);
          
                     
                      value1++;
          
                    
                      if (value1 > value2) {
                          toastr.warning("Work-in-progress limit exceeded !! ");
                         }       
                      }

                  } 
                  else if (workflow_status.length === 0) {
                    // console.log(KanbanTest,"kanbantest....")
                    // console.log("No the issue[#"+ el.dataset.eid +"] status is never be changed ");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);
                   
                    
                  }
                   else {
                    // console.log(KanbanTest,"kanbantest....")
                    // console.log(workflow_status,"NO the issue[#" + el.dataset.eid +"] status not be change please drop another container");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);
                  
                  }


 
                  var content =
                 {
                     "status_id": parseInt(target_id)
                  }
                 $.ajax({
                type: "PUT",
                url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
                dataType: "json",
                contentType: 'application/json',
                data: JSON.stringify({
                "issue": content
               }),
                success: function (res,status, xhr) {      
                $.ajax({
                 type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                 dataType: "json",
                success: function (Newresult, status, xhr) {
                const params =window.location.search
                const parameters = new URLSearchParams(params);
                const  project_id = parameters.get('project_id');
                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}`:url+`/issues.json?key=${api_key}`,
                dataType: "json",
                success: function (Newres, status, xhr) {
               
                

                   if(Newres.issues.length==0)
                   {
                    $(".nodata").css("display","none");
                    $("#myKanban").css("display","block");
                    //  $("#myKanban").css("display","none");
                    //  $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                   }
                   else{
                       
                          agile_issues=Newres.issues
                          $(".nodata").css("display","none");
                          $("#myKanban").css("display","block");
                   }
                 Newresult.issue_statuses.forEach(object => {
                            object.item= []
                  });
                Newres.issues.forEach(object => {
                    Newresult.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                          option.item.push(object)
                         }
                        });
                     });           
                  const  array_item=[];
                   Newresult.issue_statuses.forEach(object => {
                            array_item.push(''+object.id)    
                  });
                  Newresult.issue_statuses.forEach(object => {
                            object.id=''+object.id
                            object.dragTo=array_item
                          object.issueCount=object.item.length

                   });
                 
                   Newresult.issue_statuses.forEach(object => {
                         result.issue_statuses.forEach(option => {
                          option.issueCount=object.item.length
                            
                  });
                   })
// ------------
                 
issue_bords_ids = KanbanTest.options.boards ;  //boards id
issue_counting = KanbanTest.boardContainer ;    //issue updated values

var issue_update_value = [];
var issue_bords_update = [];


// console.log(issue_bords_update,'isssue boards update');

issue_bords_ids.forEach((object,i)=>{
issue_bords_update.push(object.id);
});



issue_counting.forEach((object,i)=>{
issue_update_value.push(object.childElementCount);
// console.log(object.childElementCount,'child countingg')
});
// console.log(issue_bords_update,"&&&&&&&");
// console.log(issue_update_value,"......");

// -------------
// for (let i = 0; i < issue_bords_update.length; i++) {

// $('.counting' + issue_bords_update[i]).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
// }

for (let i = 0; i < issue_bords_update.length; i++) {
  let currentStatusId = issue_bords_update[i];
  // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
//   let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;

//   let wipLimitHtml = '';
//   if (currentWipLimit) {
//       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
//   } else {
//       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
//   }
  let wipLimitHtml = '( ' + issue_update_value[i] + ' )';

  $('.counting' + currentStatusId).html(wipLimitHtml);
}
//  updateKanbanContainerStatus();

// console.log(issue_bords_update,'issue board update 11');
// console.log(issue_update_value,'issue update value 11');
// console.log(global_wip_limit,"global wip limit 11");
// setTimeout(() => {
//   updateWipLimits();
//   }, 1000);

//   setTimeout(() => {
//    updateKanbanContainerStatus();
//     }, 500);       
                }
               });
              
              },
               error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
              },
               error: function (xhr, status, error) {
                console.log(error,"error");
              //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
                });

                //  updateKanbanContainerStatus();


                // setTimeout(() => {
                //   updateWipLimits();
                //   }, 2000);
      
                //   setTimeout(() => {
                //     updateKanbanContainerStatus();
                //     }, 500);   

                  },
                  
                  itemAddOptions: {
                    enabled: project_id?true:false,
                    content: '+ Add New ISSUE',
                    class: 'Add-card',
                    footer:true
                  },
                  boards:boards_array,
           
                  //boards:boardss,
                   cardCounter:result.issue_statuses.length
                 
        

                  });
        
                   }, 
                 error: function (xhr, status, error) {
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                 alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
                }
                });
              },
               error: function (xhr, status, error) {
              setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
                }
                else{
                  //  console.log("this 2");

                   
                  // if filter or group by applied or user go to the particular project page
                  window.getProjects=function(id)
                  {
                    var trackers;
                    $.ajax({
                      type: "GET",
                      url:`${url}/projects/${id}.json?key=${api_key}&&include=trackers`,
                      dataType: "json",
                      async:false,
                      success: function (result, status, xhr) {
                        // console.log(result,"result");
                        trackers=result.project.trackers;
                      },
                      error:function(error,status,xhr){

                      }
                    })
                    return  trackers;
                  }

                  // Get the full URL path
                    const path = window.location.pathname;

                    // Split the path into segments
                    const pathSegments = path.split('/');

                    // Extract the project identifier
                    var project_id = pathSegments[2]; 

                    // Extract any query parameters
                    const params = redirect_path.split('?')[1];
                    const parameters = new URLSearchParams(params);
                    // Example: const projectIdFromQuery = parameters.get("project_id");

                    // console.log("Project Identifier from path:", project_id);
                    // console.log("Project ID from query parameters:", parameters.get("project_id"));


                //  let  params =window.location.search
                //  let  parameters = new URLSearchParams(params);
                //  var  project_id = parameters.get('project_id');
                 if(project_id)
                 {
                  var trackers= getProjects(project_id);
                 }
                 var issue_id =[]
                $.ajax({
                type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                dataType: "json",
                success: function (result, status, xhr) {
          
                // var params =window.location.search
                //  let  parameters = new URLSearchParams(params);
                // const  project_id = parameters.get('project_id');
                  console.log(params,'heloworld')
                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}` :url+`/issues.json?key=${api_key}&${params}` ,
                dataType: "json",
                // async:false,
                beforeSend: function(){
                let body_div=document.getElementsByClassName("has-main-menu controller-custome_agile_boards");
                let div=document.createElement("div");
                div.className="unknown-div";
                div.style.display="block";
                body_div[0].appendChild(div);
                 $('.circle-loader').show();
               },
                success: function (res, status, xhr) {
                  console.log(res.issues)
                  // agile_issues=res.issues
                  var sprintId = parameters.get('sprint_craft');
                  if(res.issues.length==0)
                  {
                    $(".nodata").css("display","none");
                    $("#myKanban").css("display","block");
                    // $("#myKanban").css("display","none");
                    // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                  }

                  else{
                      
                        agile_issues=res.issues;
                         $(".nodata").css("display","none");
                         $("#myKanban").css("display","block");
                  }
            

                 getSpentTime(project_id);
                $('.circle-loader').toggleClass('load-complete');
                $('.checkmark').toggle();
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
     
     
                 if(cards.includes("Tags")&&tagPluginExists)
                 {
                  fetchtags();
             
                 }
                 if(project_id)
                 {
                   if(project_cards.includes("Notes"))
                   {
                    
                    fetchnotes();
                   }
                 }
                 else{
                   if(cards.includes("Notes"))
                   {
                    fetchnotes();
                   }
                 }
                 
                let  params1 =window.location.search
                let  parameters1 = new URLSearchParams(params1);
                var  group_by = parameters1.get('group_by');
    
                  // function to convert in date format
                 function changeDateFormat(format){
                  var today = new Date(format);
                  var dd = String(today.getDate()).padStart(2, "0");
                  var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
                  var yyyy = today.getFullYear();
                  return  today = dd + "." + mm + "." + yyyy;
                  }
                 

                  if (params.includes('sprint_craft') && res.issues.length!=0 ) {
                  
               
                    res.issues = res.issues.filter(object => object.sprint_craft !== null && object.sprint_craft == sprintId);
                   res.issues.reduce(function(sum, current) {
                    return total_hour= sum + current.estimated_hours;
                    }, 0); 
              
                  }
                else if (!params.includes('sprint_craft')) {
                  res.issues.reduce(function(sum, current) {
                    return total_hour= sum + current.estimated_hours;
                    }, 0);
                    // console.log("total hour else if ",total_hour);
                }
                else{
                  total_hour=0.00;            
         
                  // console.log("total hour else  ",total_hour);
                }

               
                  if(res.issues.length!=0){
                  res.issues.reduce(function(sum, current) {
                    return total_story_points= sum + current.story_points;
                    }, 0);
                } else {
                  total_story_points = 0;
                }

                function updateDisplay(object, timeValue, hourValue, spentTimeValue ,total_story_points ) {
                  // console.log(object,"object");
                  // if (object.id === 1 && time_ids.includes(1) && view_estimated_time === true) {
                  //     $("#query-id").css("display", "flex");
                  //     $(".total-for-estimated-hours").css("display", "flex");
                  //     hourValue = isNaN(hourValue) ? "0.00" : parseFloat(hourValue).toFixed(2);
                  //     $(".value-estimated-time").html(hourValue);
                  // }
                //   if (object.id === 2 && time_ids.includes(2) && view_spent_time === true) {
                //       $("#query-id").css("display", "flex");
                //       $(".total-for-spent-hours").css("display", "flex");
                //       spentTimeValue = parseFloat(spentTimeValue).toFixed(2);
                //       $(".value-spent-time").html(spentTimeValue);
                //   }
 
            //       if (object.time_field === "Story Points" && object.project_time_value === true && view_story_point === true) {
                    
            //         $("#query-id").css("display", "flex");
            //         $(".total-for-story-point").css("display", "flex");
            //         total_story_points = parseFloat(total_story_points).toFixed(2);
            //         $(".value-story-points").html(total_story_points);
            //         // console.log(total_story_points,"total story point particualr project");
            //   }

              }
              
               Total_time.forEach((object) => {
                  if (project_id) {
                    // console.log(total_story_points,"total story point project ..");
                      updateDisplay(object, 'project_time_value', total_hour, total_spent_time_project , total_story_points);
                  } else {
                    // console.log(total_story_points,"total story point out side ..");
                      updateDisplay(object, 'time_value', total_hour, total_spent_time , total_story_points);
                  }
                });

                // -----  
              //   function updateDisplay(object, timeValue, total_story_points ) {
              //     if (object.timefield === "Story Points" && object[timeValue] === true) {
              //       $("#query-id").css("display", "flex");
              //       $(".total-for-story-point").css("display", "block");
              //       total_story_points = parseFloat(total_story_points).toFixed(2);
              //       $(".value-story-points").html(total_story_points);
              //       console.log(total_story_points,"total story point particualr project");
              // }
              // }
              
              //  Total_time.forEach((object) => {
              //     if (project_id) {
              //       console.log(total_story_points,"<<<<<");
              //         updateDisplay(object, 'project_time_value', total_story_points);
              //     } else {
              //         updateDisplay(object, 'time_value', total_story_points);
              //     }
              //   });           
                // ------
               // if group by filter is applied 
               if(group_by)
               {
             
                // Given array of issues
                const issues =res.issues;
   
                // Initialize an empty object to store assigned issues
                const assignedIssues = {};
                // Iterate through the issues and group them by assigned user
                issues.forEach((issue) => {
                  // sprint in the code
                  if(params.includes('sprint_craft'))
                  {
             
                    if(issue.sprint_craft !== null && issue.sprint_craft == sprintId)
                    {
              
                    let assignedUserId = "Blank";
                   // Set default values based on the 'group_by' condition
                    if (group_by === 'category' && !issue.hasOwnProperty(group_by)) {
                      assignedUserId = 'Blank';
                    }
                    else if(group_by === 'assigned_to' && !issue.hasOwnProperty(group_by)){
                      assignedUserId = 'Anonymous';
                    } else if (issue.hasOwnProperty(group_by)) {
                      switch (group_by) {
                        case 'closed_on':
                          assignedUserId = issue.closed_on == null ? 'Blank' : changeDateFormat(issue[group_by]) ;
                          break;
                        case 'is_private':
                          assignedUserId = 'No';
                          break;
                        case 'updated_on':
                        case 'created_on':
                        case 'start_date':
                        case 'due_date':
                          const updatedDate =issue[group_by]!=null? changeDateFormat(issue[group_by]) : "Blank";
                          assignedUserId = updatedDate;
                          break;
                        default:
                          assignedUserId = typeof issue[group_by] === 'object' ? issue[group_by].name : issue[group_by];
                      }
                    }

                    // Check if the user key exists, if not, initialize it with an empty array
                    if (!assignedIssues[assignedUserId]) {
                      assignedIssues[assignedUserId] = [];
                    }
                    // Push the issue to the array of assigned issues for the user
                    assignedIssues[assignedUserId].push(issue)   
                  }    
                  else{
                    // if($(".nodata").length==0)
                    // {
                    //   $("#myKanban").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                    // }
               
                  }      
                  }
                  else{
                    let assignedUserId = "Blank";
                    // if sprint is not there
             
                      // Set default values based on the 'group_by' condition
                      if (group_by === 'category' && !issue.hasOwnProperty(group_by)) {
                      
                        assignedUserId = 'Blank';
                      } 
                      else if(group_by === 'assigned_to' && !issue.hasOwnProperty(group_by)){
                        assignedUserId = 'Anonymous';
                      }else if (issue.hasOwnProperty(group_by)) {
                        switch (group_by) {
                          case 'closed_on':
                            assignedUserId = issue.closed_on == null ? 'Blank' : changeDateFormat(issue[group_by]) ;
                            break;
                          case 'is_private':
                            assignedUserId = 'No';
                            break;
                          case 'updated_on':
                          case 'created_on':
                          case 'start_date':
                          case 'due_date':
                            const updatedDate =issue[group_by]!=null? changeDateFormat(issue[group_by]) : "Blank";
                            assignedUserId = updatedDate;
                            break;
                          default:
                            assignedUserId = typeof issue[group_by] === 'object' ? issue[group_by].name : issue[group_by];
                        }
                      }

                      // Check if the user key exists, if not, initialize it with an empty array
                      if (!assignedIssues[assignedUserId]) {
                        assignedIssues[assignedUserId] = [];
                      }
                      // Push the issue to the array of assigned issues for the user
                      assignedIssues[assignedUserId].push(issue)    
             }
                });
                 
                  const  array_item=[];
                  result.issue_statuses.forEach(object => {
                           array_item.push(''+object.id)    
                 });
                 result.issue_statuses.forEach(object => {
                           object.id=''+object.id
                           object.dragTo=array_item
                          //  object.issueCount=object.item.length
                  });
                  result.issue_statuses.forEach((object,i)=> {
                    // if(i<6)
                    //    {
                    //     boards_array.push(object)
                    //     }
                        if(project_boards_values){
                         project_boards_values.forEach((list)=>{
                          if(list==object.id)
                          {
                            boards_array.push(object)
                            
                          }
                         })
                       }
                     object.id=''+object.id
                     object.dragTo=array_item
                    //  object.issueCount=object.item.length
                     object.tracker_data=trackers
                  });
                  // Counter for unique container IDs
                  kanban_issues=assignedIssues;
                 let mainContainer =document.getElementById("myKanban");
      
                 for (const key in  assignedIssues) {
                  if (Object.hasOwnProperty.call( assignedIssues, key)) {
                    var stringWithoutSpaces = key.replace(/[\s\W-]/g, '');
                    var containerId = `group-${stringWithoutSpaces}`;
                    var userContainer = document.createElement("div");
                    userContainer.className = "myKanban";
                    userContainer.innerHTML+=`<div class="myKanban"  id="${containerId}"> 
                      <div class="group-div">
                      <span  value=${stringWithoutSpaces} class="expander icon icon-expended agile-arrow" onclick="toggleGroup(this)">&nbsp;</span>
                      <span class="name"><span class="user">${key}</span></span>
                      <span style="top:0px;" class="badge badge-count count">${assignedIssues[key].length}</span>
                        </div>
                    </div>`;
          
                       mainContainer.appendChild(userContainer);
                    
                       var kanban_array=  result.issue_statuses.map(item1 => ({
                        ...item1,
                        item:  assignedIssues[key].filter(item2 => item2.status.id == item1.id),
                        dragTo: result.issue_statuses.map(item=>item.id),
                        issueCount:assignedIssues[key].filter(item2 => item2.status.id == item1.id).length
                      }));

                     
                      // if(assignedIssues[key].length!=0)
                      // {
                      //   assignedIssues[key].reduce(function(sum, current) {
                      //     return total_hour= sum + current.estimated_hours;
                      //     }, 0); 
                      //     console.log(total_hour,"total hours")
                      // }
                      // else{
                      //   total_hour=0.00;
                      // }

                      
                    // Total_time.forEach((object,i)=>{
                    // if (object.id === 1 && object.project_time_value === true)
                    // {
                    //   if(total_hour!=NaN)
                    //   {
                    //   $("#query-id").css("display","flex");
                    //   $(".total-for-estimated-hours").css("display","block");
                    //   total_hour=parseFloat(total_hour).toFixed(2);
                    //   $(".value-estimated-time").html(total_hour);
                    //   }
                    //   else{
                    //     $(".value-estimated-time").html("0.00");
                    //   }
                    // }
                    // })

                        let local_data= project_boards_values
                         result.issue_statuses.forEach((object,i)=> {
                             if(local_data.includes(object.id))
                             {
                                boards_array.push(object)
                             }
                        })

                    var ele1 = `#${containerId}`;
                    kanban_issues=ele1;
                    createdContainers.push(ele1);

                    createKanban(ele1,containerId);

                 function createKanban(ele,groupId) { 
                 var KanbanTest = new jKanban({
                  element: ele,
                  itemHandleOptions:{
                    enabled: true,
                  },
                  dragEl:function(el, source){
                },
                 context: function(el, e) {
                 },
                 dropEl: function(el, target, source, sibling ,source_id){
                  getWorkflow(el.dataset.eid);
                  var target_int = parseInt(sibling);
                  var source_int = parseInt(source_id);
                  if (workflow_status.includes(target_int)) {
                    // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully");
                    // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                    // console.log("successfully applied 2");   
                    // console.log(target,"target");
                    // console.log(source,"source");  
                    var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                    var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);
  
                    // console.log(header_kanban,"header kanban");
                    // console.log(matches,"matches");
                    if (matches && matches.length === 3) {
                      // Extracted values in integer format
                      var value1 = parseInt(matches[1]);
                      var value2 = parseInt(matches[2]);
          
                     
                      value1++;
          
                    
                      if (value1 > value2) {
                          toastr.warning("Work-in-progress limit exceeded !! ");
                         }       
                      }           
                  }
                   else if (workflow_status.length === 0) {
                    // console.log(KanbanTest,"kanbantest....")
                    // console.log("no the issue[#"+ el.dataset.eid +"] can't be changed ");
                    toastr["error"]('workflow is not defined for this status');
                    KanbanTest.drake.cancel(true);
                   
                  } else {
                    // console.log(   KanbanTest,"slkdjfk...");
                    // console.log("no the issue[#" + el.dataset.eid +"] cant drop this status");
                    toastr["error"]('workflow is not defined for this status');
                   KanbanTest.drake.cancel(true);
                   
                  }

                 var content =
                 {
                     "status_id": parseInt(sibling)
                  }
                 $.ajax({
                type: "PUT",
                url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
                dataType: "json",
                contentType: 'application/json',
                data: JSON.stringify({
                "issue": content
               }),
                success: function (res,status, xhr) {      
                $.ajax({
                 type: "GET",
                url:url+`/issue_statuses.json?key=${api_key}`,
                 dataType: "json",
                success: function (Newresult, status, xhr) {
                const params =redirect_path.split('?')[1];
                const parameters = new URLSearchParams(params);
                const  project_id = parameters.get('project_id');
                $.ajax({
                type: "GET",
                url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}`:url+`/issues.json?key=${api_key}&${params}`,
                dataType: "json",
                success: function (Newres, status, xhr) {
                    // console.log("Running 4");
              
                    if(Newres.issues.length==0)
                    {
                      console.log("condition--44");
                      $(".nodata").css("display","none");
                      $("#myKanban").css("display","block");
                      // $("#myKanban").css("display","none");
                      // $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                    }
                    else{
                        
                            agile_issues=Newres.issues
                           $(".nodata").css("display","none");
                           $("#myKanban").css("display","block");
                    }
                 Newresult.issue_statuses.forEach(object => {
                            object.item= []
                  });
                Newres.issues.forEach(object => {
                    Newresult.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                          option.item.push(object)
                         }
                        });
                     });           
                  const  array_item=[];
                   Newresult.issue_statuses.forEach(object => {
                            array_item.push(''+object.id)    
                  });
                  Newresult.issue_statuses.forEach(object => {
                            object.id=''+object.id
                            object.dragTo=array_item
                          object.issueCount=object.item.length

                   });
                 
                   Newresult.issue_statuses.forEach(object => {
                         Newresult.issue_statuses.forEach(option => {
                          option.issueCount=object.item.length
                        
                            
                  });
                   })
// ----------------------------------------------
                    issue_bords_ids = KanbanTest.options.boards ;  //boards id
                    issue_counting = KanbanTest.boardContainer ;
            //issue updated values
                  

                   var issue_update_value = [];
                   var issue_bords_update = [];


                  issue_bords_ids.forEach((object,i)=>{
                    issue_bords_update.push(object.id);
                  });
                  // console.log(issue_bords_update,"issue board update...")
                  issue_counting.forEach((object,i)=>{
                    issue_update_value.push(object.childElementCount);
                
                }); 
                // console.log(issue_update_value,"......");

              
                // for (let i = 0; i < issue_bords_update.length; i++) {
                //  $(`.${groupId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                // }
                
                // setTimeout(() => {
                //   updateWipLimits();
                //   }, 1000);
                
                  // setTimeout(() => {
                  //   updateKanbanContainerStatus();
                  //   }, 500); 

                if(project_id){
                  for (let i = 0; i < issue_bords_update.length; i++) {
                    let currentStatusId = issue_bords_update[i];
                    // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                    // let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
  
                    // let wipLimitHtml = '';
                    // if (currentWipLimit) {
                    //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                    // } else {
                    //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                    // }
                    let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                  
                    $(`.${groupId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);
  
  
                    // $(`.${groupId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                   }

                }
                else{
                 for (let i = 0; i < issue_bords_update.length; i++) {
                  let currentStatusId = issue_bords_update[i];
                  // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                  let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;

                //   let wipLimitHtml = '';
                //   if (currentWipLimit) {
                //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                //   } else {
                //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                //   }
                let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                
                  $(`.${groupId} .counting${issue_bords_update[i]}`).html(wipLimitHtml);


                  // $(`.${groupId} .counting${issue_bords_update[i]}`).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                 }
                }
                // updateKanbanContainerStatus();
                    // setTimeout(() => {
                    // updateKanbanContainerStatus();
                    // }, 500); 

                // console.log(issue_bords_update,'issue board update 11');
                // console.log(issue_update_value,'issue update value 11');
                
                
                // if (project_id){
                //   console.log(project_wip_limit,"project wip limit 11");
                // }
                // else {
                //   console.log(global_wip_limit,"global wip limit 11");
                // }



                }
               });
              },
               error: function (xhr, status, error) {
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
              },
               error: function (xhr, status, error) {
                console.log("error");
              //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
                });
                  },
                  itemAddOptions: {
                    enabled: (project_id&&trackers.length!=0)?true:false,
                    content: '+ Add New ISSUE',
                    class: 'Add-card',
                    footer: true
                  },
                  boards:kanban_array,
                  cardCounter:result.issue_statuses.length
                });
              }
                }
              }
            }
            else{
                
              // if group by not applied
                          result.issue_statuses.forEach(object => {
                            object.item= []
                            
                  });
                  if (params.includes('sprint_craft')) {
                    res.issues.forEach(object => {
                      result.issue_statuses.forEach(option=>{
                        if (object.sprint_craft !== null && object.sprint_craft == sprintId) {
                          if(object.status.name==option.name )
                          { 
                            option.item.push(object)
                          }
                        }
                         });
                      });    
                  }
                  else {
                  res.issues.forEach(object => {
                     result.issue_statuses.forEach(option=>{
                       if(object.status.name==option.name)
                        {
                         option.item.push(object)
                          }
                        });
                     });    
                    }

                    if (params.includes('sprint_craft') && res.issues.length!=0 ) {
                  
                      res.issues = res.issues.filter(object => object.sprint_craft !== null && object.sprint_craft == sprintId);
                     res.issues.reduce(function(sum, current) {
                      return total_hour= sum + current.estimated_hours;
                      }, 0); 
                
                    }
                  else if (!params.includes('sprint_craft')) {
                    res.issues.reduce(function(sum, current) {
                      return total_hour= sum + current.estimated_hours;
                      }, 0);
                      // console.log("total hour else if ",total_hour);
                  }
                  else{
                    total_hour=0.00;
                    // console.log("total hour else  ",total_hour);
                  }


                  // Total_time.forEach((object,i)=>{
                  //   if (object.id === 1 && object.project_time_value === true)
                  //   {
                  //     if(total_hour!=NaN)
                  //     {
                  //     $("#query-id").css("display","flex");
                  //     $(".total-for-estimated-hours").css("display","block");
                  //     total_hour=parseFloat(total_hour).toFixed(2);
                  //     $(".value-estimated-time").html(total_hour);
                  //     }
                  //     else{
                  //       $(".value-estimated-time").html("0.00");
                  //     }
                  //   }
                  //   })

                  function updateDisplay(object, timeValue, hourValue, spentTimeValue) {
                    // if (object.id === 1 && time_ids.includes(1) && view_estimated_time === true) {
                    //     $("#query-id").css("display", "flex");
                    //     $(".total-for-estimated-hours").css("display", "flex");
                    //     hourValue = isNaN(hourValue) ? "0.00" : parseFloat(hourValue).toFixed(2);
                    //     $(".value-estimated-time").html(hourValue);
                    // }
                    // if (object.id === 2 && object[timeValue] === true && view_spent_time === true ) {
                    //     $("#query-id").css("display", "flex");
                    //     $(".total-for-spent-hours").css("display", "flex");
                    //     spentTimeValue = parseFloat(spentTimeValue).toFixed(2);
                    //     $(".value-spent-time").html(spentTimeValue);
                    // }
                //     if (object.time_field === "Story Points" && object[timeValue] === true && view_story_point === true) {
                //       $("#query-id").css("display", "flex");
                //       $(".total-for-story-point").css("display", "flex");
                //       total_story_points = parseFloat(total_story_points).toFixed(2);
                //       // console.log(total_story_points,"total story points values ");
                //       $(".value-story-points").html(total_story_points);
                // }
              }
                
                Total_time.forEach((object) => {
                    if (project_id) {
                        updateDisplay(object, 'project_time_value', total_hour, total_spent_time_project , total_story_points);
                    } else {
                        updateDisplay(object, 'time_value', total_hour, total_spent_time , total_story_points); 
                    }
                });

                  const  array_item=[];
                  result.issue_statuses.forEach(object => {
                           array_item.push(''+object.id)    
                 });
                 result.issue_statuses.forEach(object => {
                           object.id=''+object.id
                           object.dragTo=array_item
                           object.issueCount=object.item.length
                  });
                  result.issue_statuses.forEach((object,i)=> {
                    // if(i<6)
                    //    {
                    //     boards_array.push(object)
                    //     }
                        if(project_boards_values){
                         project_boards_values.forEach((list)=>{
                          if(list==object.id)
                          {
                            boards_array.push(object)
                            
                          }
                         })
                       }
                     object.id=''+object.id
                     object.dragTo=array_item
                     object.issueCount=object.item.length
                     object.tracker_data=trackers
                  });
                      let local_data= project_boards_values
                      result.issue_statuses.forEach((object,i)=> {
                           if(local_data.includes(object.id))
                           {
                              boards_array.push(object)
                           }
                      })

             
                
              var KanbanTest = new jKanban({
                element: `#myKanban`,
                itemHandleOptions:{
                  enabled: true,
                },
               context: function(el, e) {
               },
               dropEl: function(el, target, source, sibling ,source_id){
                getWorkflow(el.dataset.eid);
                var target_int = parseInt(sibling);
                var source_int = parseInt(source_id);
                if (workflow_status.includes(target_int)) {
                  // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully");
                  // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                  // console.log("successfully applied 1 ");  
                  var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                  var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);

                  // console.log(header_kanban,"header kanban");
                  // console.log(matches,"matches");
                  if (matches && matches.length === 3) {
                    // Extracted values in integer format
                    var value1 = parseInt(matches[1]);
                    var value2 = parseInt(matches[2]);
        
                   
                    value1++;
        
                  
                    if (value1 > value2) {
                        toastr.warning("Work-in-progress limit exceeded !! ");
                       }       
                    }
                  }

                 else if (workflow_status.length === 0) {
                  console.log(KanbanTest,"kanbantest....")
                  // console.log("no the issue[#"+ el.dataset.eid +"] can't be changed ");
                  toastr["error"]('workflow is not defined for this status');
                  KanbanTest.drake.cancel(true);
             
                } else {
                  console.log(KanbanTest,"kanbantest....")
                  // console.log("no the issue[#" + el.dataset.eid +"] cant drop this status");
                  toastr["error"]('workflow is not defined for this status');
                 KanbanTest.drake.cancel(true);
                

                }

               var content =
               {
                   "status_id": parseInt(sibling)
                }
               $.ajax({
              type: "PUT",
              url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
              dataType: "json",
              contentType: 'application/json',
              data: JSON.stringify({
              "issue": content
             }),
              success: function (res,status, xhr) {      
              $.ajax({
               type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
               dataType: "json",
              success: function (Newresult, status, xhr) {
              const params =redirect_path.split('?')[1];
              const parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
              $.ajax({
              type: "GET",
              url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}`:url+`/issues.json?key=${api_key}&${params}`,
              dataType: "json",
              success: function (Newres, status, xhr) {
               Newresult.issue_statuses.forEach(object => {
                          object.item= []
                });
              Newres.issues.forEach(object => {
                  Newresult.issue_statuses.forEach(option=>{
                     if(object.status.name==option.name)
                      {
                        option.item.push(object)
                       }
                      });
                   });           
                const  array_item=[];
                 Newresult.issue_statuses.forEach(object => {
                          array_item.push(''+object.id)    
                });
                Newresult.issue_statuses.forEach(object => {
                          object.id=''+object.id
                          object.dragTo=array_item
                        object.issueCount=object.item.length

                 });
               
                 Newresult.issue_statuses.forEach(object => {
                       result.issue_statuses.forEach(option => {
                        option.issueCount=object.item.length
                      
                          
                });
                 })
// ----------------------------------------------
                  issue_bords_ids = KanbanTest.options.boards ;  //boards id
                  issue_counting = KanbanTest.boardContainer ;    //issue updated values

                 var issue_update_value = [];
                 var issue_bords_update = [];

                issue_bords_ids.forEach((object,i)=>{
                  issue_bords_update.push(object.id);
                });

                issue_counting.forEach((object,i)=>{
                  issue_update_value.push(object.childElementCount);
                // console.log(object.childElementCount,'child countingg')
              }); 
              // for (let i = 0; i < issue_bords_update.length; i++) {
              //   $('.counting' + issue_bords_update[i]).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
              // }

              // console.log(issue_bords_update,'issue board update 22');
              // console.log(issue_update_value,'issue update value 22');
              
              
              // if (project_id){
              //   console.log(project_wip_limit,"project wip limit 22");
              // }
              // else {
              //   console.log(global_wip_limit,"global wip limit 22");
              // }

              if(project_id){
                for (let i = 0; i < issue_bords_update.length; i++) {
                  let currentStatusId = issue_bords_update[i];
                  // let currentWipLimit = project_wip_limit.find(entry => entry.status_id === currentStatusId);
                  let currentWipLimit =  Array.isArray(project_wip_limit) ? project_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                
                //   let wipLimitHtml = '';
                //   if (currentWipLimit) {
                //       wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                //   } else {
                //       wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                //   }
                let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                
                  $('.counting' + currentStatusId).html(wipLimitHtml);
                }

              }
              else {
              for (let i = 0; i < issue_bords_update.length; i++) {
                let currentStatusId = issue_bords_update[i];
                // let currentWipLimit = global_wip_limit.find(entry => entry.status_id === currentStatusId);
                let currentWipLimit =  Array.isArray(global_wip_limit) ? global_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
              
                // let wipLimitHtml = '';
                // if (currentWipLimit) {
                //     wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                // } else {
                //     wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                // }

                let wipLimitHtml = '( ' + issue_update_value[i] + ' )';
              
                $('.counting' + currentStatusId).html(wipLimitHtml);
              }
            }
              //  updateKanbanContainerStatus();

              // setTimeout(() => {
              //   updateWipLimits();
              //   }, 1000);
              
                // setTimeout(() => {
                //   updateKanbanContainerStatus();
                //   }, 500);  

              }
             });
            },
             error: function (xhr, status, error) {
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
        });
            },
             error: function (xhr, status, error) {
            //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
             }
             });


                },
                itemAddOptions: {
                  enabled: (project_id&&trackers.length!=0)?true:false,
                  content: '+ Add New ISSUE',
                  class: 'Add-card',
                  footer: true
                },
                boards:boards_array,
                cardCounter:result.issue_statuses.length    ,
                dragItems: true,
              });
            }

                   }, 
                 error: function (xhr, status, error) {
                  console.log(xhr.status,".....$$$$");
                $(".show-error").css("display","none");
                setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
              if(xhr.status==422)
              {
               let content=JSON.parse(xhr.responseText).errors;
                $("#myKanban").before(`<div class="show-error" id='errorExplanation'><ul class="ul-time"></ul> </div>`);
                content.forEach(p=>{
                  $(".ul-time").append(`<li>${p}</li>`);
                })
              }
              else if(xhr.status==403)
              {
                $("#myKanban").css("display","none");
                $("#query_form_with_buttons").after(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
              }
              else{
                // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
                }
                });
              },
               error: function (xhr, status, error) {
                console.log(error,"forbittons")
              setTimeout(() => {
                 $(".unknown-div").css("display","none");
                 $('.circle-loader').hide();
                 }, 300);
                // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
          });
                }
  });



// ==================full screen save in local storage =============
// var isAgileFullScreen = localStorage.getItem('agile_full_screen');

// if (isAgileFullScreen === 'true') {
//   fullscreen(true);
// }



  const isOpen = localStorage.getItem('agile_filter') === 'true';
    
  if (isOpen) {
      $(".controller-agile .hide-when-print").addClass("open_filter");
  } else {
      $(".controller-agile .hide-when-print").removeClass("open_filter");
  }

  // document.addEventListener('fullscreenchange', function () {
  //   if (!document.fullscreenElement) {    
  //     var header = document.getElementById('header');
  //     var topMenu = document.getElementById('top-menu');
  //     var contant = $("div#content");   
  //     var myKanban = $("div#myKanban");
  //     var fullScreenIcon = document.querySelector('.fullscreen img');
      
  //     // console.log('Exited fullscreen inside'); 
  //     // document.exitFullscreen();
  //     header.style.display = 'block';
  //     topMenu.style.display = 'block';
  //     myKanban.css('max-height', '775px');
  //     contant.removeClass('full-content');
  //     localStorage.setItem('agile_full_screen', 'false');
  //     fullScreenIcon.src = '/plugin_assets/agile_board/images/Full Screen.svg';
  //   }
  // });

  // ===========issue search by subject ==================

$('#agile_live_search').on('input', function () {
  performSearch();
  // console.log('search ');
});



  function performSearch() {
    var searchValue = $('#agile_live_search').val().toLowerCase();


    $('.kanban-item-color').each(function () {
      var issueSubject = $(this).find('.subject-agile').text().toLowerCase();
      // console.log(issueSubject,'issue subjecr ');
      if (issueSubject.includes(searchValue)) {
        // $(this).show();
        $(this).css('opacity', '1');
      } else {
        // $(this).hide(); 
        $(this).css('opacity', '0.2');
      }
    });
  }
 
})

  // =================full screen ===========

  function fullscreen() {
    var header = document.getElementById('header');
    var topMenu = document.getElementById('top-menu');
    var top_menu = $("div#top-menu");
    var content = $("div#content");
    var myKanban = $("div#myKanban");
    var fullScreenIcon = document.querySelector('.fullscreen img');
    var agileHeader = document.querySelector('.agile_header');
    var filter = document.getElementById('query_form');
    let defaultfooter=document.getElementById('footer');

    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
        var requestFullScreen =
            document.documentElement.requestFullscreen ||
            document.documentElement.webkitRequestFullscreen;

        if (requestFullScreen) {
            try {
                requestFullScreen.call(document.documentElement);
            } catch (err) {
                console.log(err);
            }

            header.style.display = 'none';
            topMenu.style.display = 'none';
            defaultfooter.style.display = 'none';
            content.addClass('full-content');
            $('div#main').addClass('full-content-custom-agile');
            top_menu.removeClass("full-content-top-menu");
            // myKanban.css('max-height', '1015px');
            fullScreenIcon.src = '/plugin_assets/agile_board/images/Minimize.svg';
            agileHeader.style.display = 'none';
            filter.style.display = 'none';
            myKanban.addClass("agile-fullscreen");

            // Add a listener for the fullscreen change event
            document.addEventListener('fullscreenchange', handleFullscreenChange);
            document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
        } else {
            // console.log('Fullscreen not supported');
        }
    } else {
        exitFullscreen();
    }
}


function handleFullscreenChange() {
  if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      exitFullscreen();
  }
}

function exitFullscreen() {
  var exitFullScreen =
      document.exitFullscreen ||
      document.webkitExitFullscreen;

  if (exitFullScreen) {
      exitFullScreen.call(document);

      var header = document.getElementById('header');
      var topMenu = document.getElementById('top-menu');
      var top_menu = $("div#top-menu");
      var content = $("div#content");
      var myKanban = $("div#myKanban");
      var fullScreenIcon = document.querySelector('.fullscreen img');
      var agileHeader = document.querySelector('.agile_header');
      var filter = document.getElementById('query_form');
      let defaultfooter=document.getElementById('footer');

      header.style.display = 'block';
      topMenu.style.display = 'block';
      defaultfooter.style.display = 'block';
      // myKanban.css('max-height', '775px');
      content.removeClass('full-content');
      $('div#main').removeClass('full-content-custom-agile');
      top_menu.addClass("full-content-top-menu");
      fullScreenIcon.src = '/plugin_assets/agile_board/images/Full Screen.svg';
      agileHeader.style.display = 'flex';
      filter.style.display = 'block';
      myKanban.removeClass("agile-fullscreen");
      // Remove the listener for the fullscreen change event
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
  } else {
      // console.log('Exit fullscreen not supported');
  }
}
  
  

// ============= wip limits ================



function updateWipLimits() {
  const params =window.location.search
  const parameters = new URLSearchParams(params);
  const  project_id = parameters.get('project_id');

  // var wipLimits = JSON.parse(localStorage.getItem('wipLimits'));
  // console.log(wipLimits, "wip limits");
  if (project_id) {
    var wipLimits = project_wip_limit ;
    }
    else{
     var wipLimits = global_wip_limit ;
    }

   

  if (wipLimits) {
    wipLimits.forEach(function (limit) {
      var statusId = limit.status_id;
      var wipLimit = limit.limit;

      // Get all columns with the specified status ID
      var boardElements = document.querySelectorAll('.kanban-board[data-id="' + statusId + '"]');

      // Update the WIP limit span for each column
      boardElements.forEach(function (boardElement) {
        var wipLimitSpan = boardElement.querySelector('.wip');

        if (wipLimitSpan) {
          wipLimitSpan.textContent = '/ ' + wipLimit + '';
        } else {
          // Handle the case where the WIP limit span is not found for a column
          console.error('WIP limit span not found for column with status ID ' + statusId);
        }
      });
    });
  }
}



function updateKanbanContainerStatus() {
  // Get all kanban containers
  var kanbanContainers = document.querySelectorAll('.kanban-container');
// console.log(kanbanContainers,"kanban");
  setTimeout(() => {
    if (kanbanContainers) {
      kanbanContainers.forEach(function (container) {
        for (var i = 0; i < container.children.length; i++) {
          var child = container.children[i];

          // Get kanban heading text
          var kanban_heading = child.querySelector('.kanban-title-board').innerText;

          // Check if it's a group kanban or regular kanban
          var isGroupKanban = child.classList.contains('myKanban');

          var matches = kanban_heading.match(/(\d+) \/ (\d+)/);


          if (matches && matches.length === 3) {
            var issueCount = parseInt(matches[1]);
            var wipLimit = parseInt(matches[2]);

            // Check if it's a group kanban or regular kanban
            if (isGroupKanban) {
              var wipLimitElement = child.querySelector('.wip');
            } else {
              var wipLimitElement = child.querySelector('.pc-counting .wip');
            }

            // Update the wip limit element
            // if (wipLimitElement) {
            //   wipLimitElement.textContent = `/ ${wipLimit}`;
            // }

            if (!isNaN(issueCount) && !isNaN(wipLimit) && wipLimit < issueCount) {
              child.classList.add('kanban_red');
            } else {
              child.classList.remove('kanban_red');
            }
          }
        }
      });
    }
  }, 500);
}


// subtask limit
// $(document).ready(function() {
//   setTimeout(function() {
//     // limit in subtask
//     $('.sub-issues').on('click', '.see-more a', function(e){
//       e.preventDefault();
//       $(this).closest('ul').find('li').show();
//       $(this).closest('ul').find('.see-more').hide();
//     });

//     $('.sub-issues ul').each(function(){
//       if($(this).find('li').length > 5) {
//         $(this).find('li:gt(4)').hide();
//         $(this).append('<p class="see-more"><a href="#">See more</a></p>');
//       }
//     });
//   }, 1000);
// });
