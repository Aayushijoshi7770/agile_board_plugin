$(document).ready(function () {


var newDiv = document.createElement('div');
newDiv.className = 'switch_mode_div'; 
// var iconElement = document.createElement('i');
// iconElement.className = 'fa-solid fa-repeat'; 

// newDiv.appendChild(iconElement);

var list_icon = document.createElement('div');
list_icon.className = 'btn-list-view';
list_icon.innerHTML = `<svg width="25" height="25" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="16" cy="16" r="16" fill="#0094ff"/>
<path d="M13.5542 24H9.97699C9.20873 24 8.58594 23.3772 8.58594 22.6089V19.0317C8.58594 18.2634 9.20873 17.6406 9.97699 17.6406H13.5542C14.3225 17.6406 14.9453 18.2634 14.9453 19.0317V22.6089C14.9453 23.3772 14.3225 24 13.5542 24Z" fill="#0094ff" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M22.6089 24H19.0317C18.2634 24 17.6406 23.3772 17.6406 22.6089V19.0317C17.6406 18.2634 18.2634 17.6406 19.0317 17.6406H22.6089C23.3772 17.6406 24 18.2634 24 19.0317V22.6089C24 23.3772 23.3772 24 22.6089 24Z" fill="#0094ff" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.5542 14.9453H9.97699C9.20873 14.9453 8.58594 14.3225 8.58594 13.5543V9.97702C8.58594 9.20876 9.20873 8.58596 9.97699 8.58596H13.5542C14.3225 8.58596 14.9453 9.20876 14.9453 9.97702V13.5543C14.9453 14.3225 14.3225 14.9453 13.5542 14.9453Z" fill="#0094ff" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M22.6089 14.9453H19.0317C18.2634 14.9453 17.6406 14.3225 17.6406 13.5543V9.97702C17.6406 9.20876 18.2634 8.58596 19.0317 8.58596H22.6089C23.3772 8.58596 24 9.20876 24 9.97702V13.5543C24 14.3225 23.3772 14.9453 22.6089 14.9453Z" fill="#0094ff" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;


var board_icon = document.createElement('div');
board_icon.className = 'btn-board-view';
board_icon.innerHTML = `<svg width="25" height="25" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle  cx="16" cy="16" r="16" fill="#0094ff"/>
<path d="M23 23H24V25H23V23ZM8 23H23V25H8V23Z" fill="#ffffff"/>
<path d="M23 16H24V18H23V16ZM8 16H23V18H8V16Z" fill="#ffffff"/>
<path d="M23 9H24V11H23V9ZM8 9H23V11H8V9Z" fill="#ffffff"/>
</svg>`;

newDiv.appendChild(list_icon);
newDiv.appendChild(board_icon);

var targetDiv = document.querySelector('.controller-issues.action-index #content')
var autoScrollDiv = document.querySelector('div.autoscroll');
var flash = document.querySelector('.controller-issues.action-index #content > div.flash')


if (targetDiv && autoScrollDiv) {
    if(flash){
      targetDiv.insertBefore(newDiv, targetDiv.children[2]);
    } else {
      targetDiv.insertBefore(newDiv, targetDiv.children[1]);
    }
    
 }


// -------------------------------------------------------





$('.switch_mode_div').click(function() {
// console.log('clicked');
$('div.autoscroll').toggle();
$('div.card-view').toggle();
$('span.pagination').toggle();
$('fieldset#options').toggle();
$('div.btn-list-view').toggle();
$('div.btn-board-view').toggle();
$('p.query-totals').toggle();
$('p.other-formats').toggle();
var isDisplaying = $('div.autoscroll').is(':visible');
localStorage.setItem('issue_view', JSON.stringify(isDisplaying));
})


var state = localStorage.getItem('issue_view');
if (state) {
  var isDisplaying = JSON.parse(state);
  toggleDivs(isDisplaying);
}

if ($('#agile_live_search').is(':visible')) {
  document.getElementById('agile_live_search').blur();
}
if ($('#version_search').is(':visible')) {
  document.getElementById('version_search').blur();
}
if ($('#sprint_search').is(':visible')) {
  document.getElementById('sprint_search').blur();
}

});

function toggleDivs(isDisplaying) {
  if (isDisplaying) {
  
      $('.controller-issues div.autoscroll').show();
      $('.controller-issues div.card-view').hide();
      $('.controller-issues span.pagination').show();
      $('.controller-issues fieldset#options').show();
      $('.controller-issues div.btn-board-view').hide();
      $('.controller-issues div.btn-list-view').show();
      $('.controller-issues p.query-totals').show();
      $('.controller-issues p.other-formats').show();
  } else {
      
      $('.controller-issues div.autoscroll').hide();
      $('.controller-issues div.card-view').show();
      $('.controller-issues span.pagination').hide();
      $('.controller-issues fieldset#options').hide();
      $('.controller-issues div.btn-board-view').show();
      $('.controller-issues div.btn-list-view').hide();
      $('.controller-issues p.query-totals').hide();
      $('.controller-issues p.other-formats').hide();
  }
}


// =============




var card_array=[{name:"Issue ID", value:"id" }, {name:"Tracker", value:"tracker"}, {name:"Priority", value:"priority"},{name:"Assignee", value:"assigned_to"}, {name:"Subject",value:"subject"},{name:"Due date", value:"due_date"} ,{name:"% Done",  value:"done_ratio"}, {name:"Project", value:"project"}, {name:"Created", value:"created_on"}, {name:"Updated",value:"updated_on"},{name:"Estimated time",value:"estimated_hours"}]


var issue_bords_ids = [];
var issue_counting = [];
var boards_result ;
var cards = [];     
var project_cards = [];  
var card_fields=[];   
var Total_time=[];   
var boardss=[]; 
var project_boardss =[];
var project_boards_values=[];
var issue_tag=[]; 

  function showSettingpopup(){

    setTimeout(() => {
      if (!tagPluginExists)
      {
         var boardNames = document.querySelectorAll('.board-name');
          boardNames.forEach(function(boardName) {
                if (boardName.textContent.trim() === 'Tags') {
                  let randomDiv = boardName.closest('.random-div');
                   let inputcheck = randomDiv.querySelector('input[name="input-board"]');
                    if (inputcheck) {
                      inputcheck.checked = false;
                    }
                  randomDiv.style.display = 'none';
                }
              });
             }
  }, 100);

  setTimeout(() => {
    if (view_estimated_time === false ){
      var boardNames = document.querySelectorAll('.board-name');
      boardNames.forEach(function(boardName) {
            if (boardName.textContent.trim() === 'Estimated Time') {
              const parentDiv = boardName.closest('.random-div');
              let inputcheck = parentDiv.querySelector('input[name="input-board"]');
                if (inputcheck) {
                  inputcheck.checked = false;
                }
                if (parentDiv) {
                parentDiv.style.display = 'none';
                }
            }
          });
    }
    if (view_spent_time === false){
      var boardNames = document.querySelectorAll('.board-name');
      boardNames.forEach(function(boardName) {
            if (boardName.textContent.trim() === 'Spent Time') {
            const parentDiv = boardName.closest('.random-div');
               let inputcheck = parentDiv.querySelector('input[name="input-board"]');
                if (inputcheck) {
                  inputcheck.checked = false;
                }
                if (parentDiv) {
                parentDiv.style.display = 'none';
                }
            }
          });
    }
        //  console.log(view_story_point,"story points...");
      if (view_story_point === false){
   
         var boardNames = document.querySelectorAll('.board-name');
          boardNames.forEach(function(boardName) {
         if (boardName.textContent.trim() === 'Story Points') {
           let randomDiv = boardName.closest('.random-div');
            let inputcheck = randomDiv.querySelector('input[name="input-board"]');
                    if (inputcheck) {
                      inputcheck.checked = false;
                    }
                  randomDiv.style.display = 'none';
    
            }
          });
       }

  },100);
    setTimeout(() => {
     
      if (story_points_enabled != "1")
      {
         var boardNames = document.querySelectorAll('.board-name');
          boardNames.forEach(function(boardName) {
                if (boardName.textContent.trim() === 'Story Points') {
                    let randomDiv = boardName.closest('.random-div');
                     let inputcheck = randomDiv.querySelector('input[name="input-board"]');
                    if (inputcheck) {
                      inputcheck.checked = false;
                    }
                  randomDiv.style.display = 'none';
                }
              });
             }
  }, 100);

  
     let open_div = document.getElementsByClassName("context-menu-popup-main");
     let body_div = document.getElementsByClassName(
            "has-main-menu controller-issues action-index"
          );
          let back_div = document.getElementsByClassName("setting-div");
     
          if (back_div.length!=0) {
            back_div[0].style.display = "block";
            open_div[0].style.display = "block";
          } else {
            let div = document.createElement("div");
            div.className = "setting-div";
            div.style.display = "block";
            body_div[0].appendChild(div);
            var context_menu = document.createElement("div");
            context_menu.className = "context-menu-popup-main";
            context_menu.innerHTML = `<div style="display:flex; justify-content:space-between">
         <div  style="display:flex">
         <h4  style="color:black; font-weight:normal !important;" class="heading-edit-issue" >Settings </h4>
         </div>
         <div   style="display:flex; cursor:pointer;"> 
          <div onclick="closeSettingpopup()" type="button" data-toggle="tooltip" title="Close" style="display:flex; cursor:pointer;">
         <span><i  style="font-size:20px; color:gray; " class="fa-solid fa-xmark close-icon-kanban"></i></span>
           </div>
          </div>
        </div>
          <div class="error-blank-fileld"></div>
            <div style="display:flex; flex-direction:column;">
                <div style="display:flex"> 
                  <div  id="query_form_with_buttons" class="hide-when-print setting-agile">
         <div id="query_form_content">
       
             <div class="table-div" style="display:block; padding:0.5rem 0.5rem !important;">
                <table >
                <tbody>
                <tr>
                <td colspan="2">
                  <span  id="legend-setting" onclick="toggleBoard(this)">Board columns</span>
                      <div class="table-div-board" style="display:flex;flex-wrap:wrap;">
                        
                      </div>
                </td>
                </tr>
                     <tr>
                <td colspan="2">
                  <span onclick="toggleCards(this)" >Card fields</span>
                      <div class="table-div-cardfields" style="display:flex;flex-wrap:wrap;" >
                      </div>
                </td>
                </tr>
                    <tr>
       
                </tr>
               <tr>
                  <td colspan="2">
                <div style="display:flex; flex-direction:row;  gap:22px;">
                  <div  style="display:flex; line-height: 21px;">
                  <label  class="agile_options_label" >Total Time</label>
                  </div>
                  <div   style="display:flex;" class="total_time">
                  </div>
              </div>
                  </td>
                </tr>
                </tbody>
                </table>
        <div    style="display:flex; justify-content: center; margin-bottom:15px;  margin-top:15px !important";>
            
                <div onclick="clearOptions()"   style="display:flex; margin-right:15px; cursor:pointer; ">
                   <button   style="cursor:pointer"  class="button-close">Cancel</button>
                 </div>
                     <div    onclick="updatedOptions()"  style="display:flex;   cursor:pointer; ">
                   <button  style="cursor:pointer"  class="button-save" id="apply_set" >Apply</button>
                 </div>
        </div>
                </div>
         </div>
     
      </div>
                  </div>
        
        
        `

                body_div[0].appendChild(context_menu);

               

          }

          if ($('.context-menu-popup-main').is(':visible')) {
            $(":tabbable").attr("tabindex", -1);
            $("html").css("overflow", "hidden");
            $(".context-menu-popup-main [tabindex='-1']").attr("tabindex", 0);
            
          } else {
            $("[tabindex='-1']").attr("tabindex", 0);
            $("html").css("overflow", "auto");
          }
        
// ------------------------ card field ------------

                // const params = window.location.search;
                // const parameters = new URLSearchParams(params);
                // const project_id = parameters.get("project_id");

                let url = window.location.origin ;
                const urls = window.location.pathname;
                const match = urls.match(/projects\/([^\/]+)\//);
                const project_id = match ? match[1] : null;
               console.log(project_id,"pro==>> ");
               
                
              $(".table-div-cardfields").html(" ");
          
              let result=card_fields
              if(project_id)
              {
               result.forEach((object,i)=>{
                let field="Project";
                if(object.field_name.toLowerCase()!=field.toLowerCase())
                {

              if ( object.project_issue_value == true){
              $(".table-div-cardfields").append(`
                   <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                  <div style="display:flex;">
                    <input  name="input-board"  id="${object.id}" checked="checked"  value="${object.project_issue_value}" class="card_${object.id}"   type="checkbox">
                  </div>
                 <div style="display:flex;">
                    <span  class="board-name">${object.field_name}</span>
                     </div>
                 </div>
                  `);
             }
             else {
                    $(".table-div-cardfields").append(`
                   <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                  <div style="display:flex;">
                    <input  name="input-board"  id="${object.id}"   value="${object.project_issue_value}" class="card_${object.id}"   type="checkbox">
                  </div>
                 <div style="display:flex;">
                    <span  class="board-name">${object.field_name}</span>
                     </div>
                 </div>
                  `);
                  }
                
                }
              });
              
              }
              else{
                result.forEach((object,i)=>{

              if ( object.global_issue_value == true){
              $(".table-div-cardfields").append(`
                   <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                  <div style="display:flex;">
                    <input  name="input-board"  id="${object.id}" checked="checked"  value="${object.global_issue_value}" class="card_${object.id}"   type="checkbox">
                  </div>
                 <div style="display:flex;">
                    <span  class="board-name">${object.field_name}</span>
                     </div>
                 </div>
                  `);
             }
             else {
      
                    $(".table-div-cardfields").append(`
                   <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                  <div style="display:flex;">
                    <input  name="input-board"  id="${object.id}"   value="${object.global_issue_value}" class="card_${object.id}"   type="checkbox">
                  </div>
                 <div style="display:flex;">
                    <span  class="board-name">${object.field_name}</span>
                     </div>
                 </div>
                  `);
                  }
              });
              }





// ------------------time field -------------------

            if(project_id){
              let result1=Total_time;
              $(".total_time").html(" ");
              result1.forEach((object,i)=>{
                if (object.project_issue_time == true){
               $(".total_time").append(`<div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
            <div style="display:flex;">
            <input  name="time-check" value=${object.project_issue_time} checked="checked" class="time_true" id="${object.id}" type="checkbox" >
            </div>
            <div style="display:flex;">
            <span  class="board-name"> ${object.time_field}</span>
             </div>
             </div>`);
                }
                else{
                    $(".total_time").append(`<div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
            <div style="display:flex;">
            <input  name="time-check" value=${object.project_issue_time}  class="time_false" id="${object.id}" type="checkbox" >
            </div>
            <div style="display:flex;">
            <span  class="board-name"> ${object.time_field}</span>
             </div>
             </div>`);
                }
              });


            } else {
              let result1=Total_time;
          $(".total_time").html(" ");
              result1.forEach((object,i)=>{
                if (object.global_issue_time == true){
               $(".total_time").append(`<div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
            <div style="display:flex;">
            <input  name="time-check" value=${object.global_issue_time} checked="checked" class="time_true" id="${object.id}" type="checkbox" >
            </div>
            <div style="display:flex;">
            <span  class="board-name"> ${object.time_field}</span>
             </div>
             </div>`);
                }
                else{
                    $(".total_time").append(`<div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;">
            <div style="display:flex;">
            <input  name="time-check" value=${object.global_issue_time}  class="time_false" id="${object.id}" type="checkbox" >
            </div>
            <div style="display:flex;">
            <span  class="board-name"> ${object.time_field}</span>
             </div>
             </div>`);
                }
              });
            }





        $.ajax({
            type: "GET",
            url:url+`/issue_statuses.json?key=${api_key}`,
            dataType: "json",
            success: function (result, status, xhr) {
          $(".table-div-board").html(" ");
               let content=result.issue_statuses;
              
              
                if(project_id){
                  content.forEach((object,i)=>{
                    if( boardss&&boardss.includes(object.id))
                   {
                      $(".table-div-board").append(`
                     <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                    <div style="display:flex;">
                      <input  name="input-board"  id="${object.id}" value="true" class="boards_${object.id}" checked="checked"   type="checkbox">
                    </div>
                   <div style="display:flex;">
                      <span  class="board-name">${object.name}</span>
                       </div>
                   </div>
                    `);
                   }
                   else{
                        $(".table-div-board").append(`
                     <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                    <div style="display:flex;">
                      <input  name="input-board"  id="${object.id}" value="false" class="boards_${object.id} "   type="checkbox">
                    </div>
                   <div style="display:flex;">
                      <span  class="board-name">${object.name}</span>
                       </div>
                   </div>
                    `);
                }
               })
                }else{
                  content.forEach((object,i)=>{
                    if( boardss&&boardss.includes(object.id))
                   {
                      $(".table-div-board").append(`
                     <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                    <div style="display:flex;">
                      <input  name="input-board"  id="${object.id}" value="true" class="boards_${object.id}" checked="checked"   type="checkbox">
                    </div>
                   <div style="display:flex;">
                      <span  class="board-name">${object.name}</span>
                       </div>
                   </div>
                    `);
                   }
                   else{
                        $(".table-div-board").append(`
                     <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                    <div style="display:flex;">
                      <input  name="input-board"  id="${object.id}" value="false" class="boards_${object.id} "   type="checkbox">
                    </div>
                   <div style="display:flex;">
                      <span  class="board-name">${object.name}</span>
                       </div>
                   </div>
                    `);
                }
               })
                }
 
            },
              error: function (xhr, status, error) {
            
          }
            })
          // ------------color field----------------

          let errorDiv = document.querySelector('.error-blank-fileld');
          errorDiv.style.display= 'none';
          errorDiv.innerHTML = '';

  }
  
$('.priority').css('text-transform','capitalize');






window.updatedOptions=function() {
  
  // const params = window.location.search;
  // const parameters = new URLSearchParams(params);
  // const project_id = parameters.get("project_id");

  let url = window.location.origin ;
  const urls = window.location.pathname;
  const match = urls.match(/projects\/([^\/]+)\//);
  const project_id = match ? match[1] : null;

  let errorDiv = document.querySelector('.error-blank-fileld');
  errorDiv.style.display= 'none';
  errorDiv.innerHTML = '';
  var isError=false;
// --------- board field update ------
var tableDivBoard = document.querySelector('.table-div-board');
var checkboxes = tableDivBoard.querySelectorAll('div.random-div > div:nth-child(1) > input[type="checkbox"]');
var boardboxids = [];
var project_issue_agile_bardboxids =[];
let allAgileStatusFalse;
let allcardfieldsFalse;
if (project_id){
  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked) {
      project_issue_agile_bardboxids.push({"id": checkboxes[i].id, "project_issue_agile": true});
    }
    else {
      project_issue_agile_bardboxids.push({"id": checkboxes[i].id, "project_issue_agile": false});  
    }
    }
} else {
  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked) {
      boardboxids.push({"id": checkboxes[i].id, "global_issue_agile": true});
    }
    else {
      boardboxids.push({"id": checkboxes[i].id, "global_issue_agile": false});  
    }
    }
}

// allAgileStatusFalse=boardboxids.every(issue => issue.agile_boards === false);
if(project_id){
  allAgileStatusFalse=project_issue_agile_bardboxids.every(issue => issue.project_issue_agile === false);
} else {
  allAgileStatusFalse=boardboxids.every(issue => issue.global_issue_agile === false);
}

// ---------------------------------card field update ---------

var tableDivBoard = document.querySelector('.table-div-cardfields');
var checkboxes = tableDivBoard.querySelectorAll('div.random-div > div:nth-child(1) > input[type="checkbox"]');
var cardboxids = [];
var project_cardboxids = [];
if (project_id){
  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked) {
      project_cardboxids.push({"id": checkboxes[i].id, "project_issue_value": true});
    }
    else{
      project_cardboxids.push({"id": checkboxes[i].id, "project_issue_value": false});
    }
    
    }
} else {
  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked) {
      cardboxids.push({"id": checkboxes[i].id, "global_issue_value": true});
    }
    else{
    cardboxids.push({"id": checkboxes[i].id, "global_issue_value": false});
    }
    
    }

}
// allcardfieldsFalse=cardboxids.every(issue => issue.field_value === false);

if(project_id){
  allcardfieldsFalse=project_cardboxids.every(issue => issue.project_issue_value === false);
} else {
  allcardfieldsFalse=cardboxids.every(issue => issue.global_issue_value === false);
}

// ------------------------------------update time field -----------------------

var tableDivBoard = document.querySelector('.total_time');
var checkboxes = tableDivBoard.querySelectorAll('div.random-div > div:nth-child(1) > input[type="checkbox"]');
var timesboxids = [];
var project_timesboxids =[];
if(project_id){

  for (var i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].checked ) {
      project_timesboxids.push({"id": checkboxes[i].id, "project_issue_time": true});
    }
    else{
      project_timesboxids.push({"id": checkboxes[i].id, "project_issue_time": false});
    }
    
    }

 } else {
  
  for (var i = 0; i < checkboxes.length; i++) {
  if (checkboxes[i].checked ) {
    timesboxids.push({"id": checkboxes[i].id, "global_issue_time": true});
  }
  else{
  timesboxids.push({"id": checkboxes[i].id, "global_issue_time": false});
  }
  
  }
}

if (allAgileStatusFalse && allcardfieldsFalse) {
            isError=true;
          errorDiv.style.display= 'block';
          errorDiv.innerHTML ="Please select at least one Board column and one Card field";
    } else if (allAgileStatusFalse) {
          isError=true;
          errorDiv.style.display= 'block';
          errorDiv.innerHTML = 'Please select at least one Board column';
    } else if (allcardfieldsFalse) {
        isError=true;
        errorDiv.style.display= 'block';
        errorDiv.innerHTML = 'Please select at least one Card fields';
    }
// ------

if(!isError){

  $.ajax({
    type: "PUT",
     url:url+`/total_time_update.json?key=${api_key}`,
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    async: false,
    // data: JSON.stringify({
    //   total_times: timesboxids
    // }),

    data:  project_id ? JSON.stringify({project_issue_total_times: project_timesboxids }): JSON.stringify({global_issue_total_times: timesboxids}),
    success: function () {
    }
   });
   $.ajax({
    type: "PUT",
     url:url+`/card_field_update.json?key=${api_key}`,
    contentType: "application/json; charset=utf-8",
    dataType: "json",
     async: false,
    // data: JSON.stringify({
    //   card_fields: cardboxids
    // }),
    data:  project_id ? JSON.stringify({project_issue_agile_cards: project_cardboxids }): JSON.stringify({global_issue_agile_cards: cardboxids}),
    success: function () {
  
    }
})
$.ajax({
  type: "PUT",
   url:url+`/update_agiles_boards.json?key=${api_key}`,
  contentType: "application/json; charset=utf-8",
  dataType: "json",
   async: false,
  // data: JSON.stringify({
  //   issue_statuses: boardboxids
  // }),
  data: project_id? JSON.stringify({project_issue_agiles: project_issue_agile_bardboxids}) : JSON.stringify({global_issue_agiles: boardboxids}),
  success: function () {
 
  }
})
  location.reload();  
$('.context-menu-popup-main').hide();
$('.setting-div').css('display','none');
}
     }




  function closeSettingpopup(){
      window.event.preventDefault();
      $(".context-menu-popup-main").css("display", "none");
       $(".setting-div").css("display", "none");

       if ($('.context-menu-popup-main').is(':visible')) {
        $(":tabbable").attr("tabindex", -1);
        $(".context-menu-popup-main [tabindex='-1']").attr("tabindex", 0);
        
      } else {
        $("[tabindex='-1']").attr("tabindex", 0);
        $("html").css("overflow", "auto");
      }
      
  }

  // function showfilterpopup(){
  //     $(".controller-agiless .hide-when-print ").toggleClass("open_filter");
      
  // }

  // ==================

  