$(document).ready(function(){

    var total_assigned_issue;
    // var user = '<%= User.current.id %>';
    // variable for all project issue in agile board to store in localstorage
    var card_array=[{name:"Issue ID", value:"id" }, {name:"Tracker", value:"tracker"}, {name:"Priority", value:"priority"},{name:"Assignee", value:"assigned_to"}, {name:"Subject",value:"subject"},{name:"Due date", value:"due_date"} ,{name:"% Done",  value:"done_ratio"} , {name:"Project", value:"project"}, {name:"Created", value:"created_on"}, {name:"Updated",value:"updated_on"},{name:"Estimated time",value:"estimated_hours"}]
  var total_hour=" ";
  var card_field=["id","tracker","priority","assigned_to","start_date","due_date","subject"];
  var boards_array=[];
  var total_spent_time=0;
  var total_spent_time_project=0;
  var total_time=["estimated_time","spent_time"];
  var board_data =[];
  var card_data =[];

  // console.log(mypage_wip_limit,"mypage wip limit");

  $.ajax({
    type: "GET",
    url:url+`/agile_issue_statuses.json?key=${api_key}`,
    dataType: "json",
    async:false,
    success: function (result, status, xhr) {
      var boards_result = result.Issue_statuses ;
      boards_result.forEach((object,i)=>{
        // if (object.agile_boards === true ){
          if (object.my_page_status === true ){
          board_data.push(object.id);
        }
      })
  

    }})

       



  
  window.hideColumn = function (boardId) {
    
    function toggleColumnExpansion(columnId) {
      const column = document.getElementById(columnId);
      if (column.classList.contains("expanded")) {
          localStorage.setItem(`mypage-${columnId}`, "expanded");
      } else {
          localStorage.setItem(`mypage-${columnId}`, "collapsed");
      }
  }
    const columns = document.querySelectorAll(".kanban-board");

    columns.forEach(column => {
        const columnId = column.id;
        column.addEventListener("click", function () {
            toggleColumnExpansion(columnId);
        });
    
        // Restore the state when the page loads
        // const initialState = localStorage.getItem(columnId);
        // console.log(columnId,"columns ID")
        // if (initialState === "collapsed") {
        //     toggleColumnExpansion(columnId);
        // }
   
    });
    const cards = document.querySelectorAll('.kanban-board');
    // Define a function to handle the click event
    function clickHandler() {
        // Increase the width of the clicked card by a certain amount (e.g., 50px)
          if(this.getAttribute("data-id")==boardId)
          {
            this.classList.toggle('expanded');
            localStorage.setItem("collapse",`expanded${boardId}`);
          }    
        // Toggle a class on elements with the class "header-back" when the card is expanded
        const headerBackElements = this.querySelectorAll('.header-back');
        headerBackElements.forEach(element => {
          if(this.getAttribute("data-id")==boardId)
          {
          element.classList.toggle('expanded-header-back');
         }  
        });
      // Toggle the visibility of the specified element when the card is expanded
  
      const footerElement = document.querySelector(`#myKanban_ > div.kanban-container > div.kanban-board.board${boardId} > footer`);
      const kanbanContent=  document.querySelector(`#myKanban_ > div.kanban-container > div.kanban-board.board${boardId} > main `);
      if (kanbanContent || footerElement) {
          if(this.getAttribute("data-id")==boardId)
          {
            kanbanContent.classList.toggle('hidden'); 
            if(footerElement)
            {
              footerElement.classList.toggle('hidden');
            }
        
         }
      }
    // Remove the click event listener after it has been executed once
    this.removeEventListener('click', clickHandler);
    }
    // Add a click event listener to each card
    cards.forEach(card => {
        card.addEventListener('click', clickHandler);
    });
          // Get all the div elements with the class "kanban-board"
        var boardElements = document.querySelectorAll('div.kanban-board');
        // Check if all of them have the class "expanded"
    //     setTimeout(()=>{
    //       var allExpanded = Array.from(boardElements).every(function(element) {
    //         return element.classList.contains('expanded');
    //       });
    //       // If all elements have the class "expanded", add a minimum height to them
    //       if (allExpanded) {
    //         Array.from(boardElements).forEach(function(element) {
    //          element.style.minHeight = '64vh'; // Change this value to your desired minimum height
    //         });
    //       }
    //       else{
    //         Array.from(boardElements).forEach(function(element) {
    //           element.style.minHeight = '0px'; // Change this value to your desired minimum height
    //         });  
    //       }
    // })
}


       window.toggleSet=function (el) {

             $.ajax({
              type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
              dataType: "json",
              success: function (result, status, xhr) {
            $(".table-div-board").html(" ");
                 let content=result.issue_statuses;
                //  let board_data=JSON.parse(localStorage.getItem("boards"))

                 content.forEach((object,i)=>{
                  // if(i<6)
                  // {
                  //   var wipLimit = getWipLimit(object.id, mypage_wip_limit);
                  //   $(".table-div-board").append(`
                  //   <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                  //  <div style="display:flex;">
                  //    <input  name="input-board" disabled checked="checked"  id="${object.id}" value="true" class="boards_${object.id}"   type="checkbox">
                  //  </div>
                  // <div style="display:flex;">
                  //    <span  class="board-name">${object.name}</span>
                  //     </div>
                  //     <div style="display:flex;">
                  //     <input  class="board-wip-limit" title="Work-in-progress limit" maxlength="3" placeholder="WIP" id="wip_${object.id}"></input>
                  //      </div>
                  // </div>
                  //  `);
                  //  updateWipLimit(object.id, wipLimit);
                  // }
                 if(board_data&&board_data.includes(object.id))
                  {
                    var wipLimit = getWipLimit(object.id, mypage_wip_limit);
                    $(".table-div-board").append(`
                        <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                       <div style="display:flex;">
                         <input  name="input-board"  id="${object.id}" value="true" class="boards_${object.id}" checked="checked"   type="checkbox">
                       </div>
                      <div style="display:flex;">
                         <span  class="board-name">${object.name}</span>
                          </div>
                          <div style="display:flex;">
                          <input  class="board-wip-limit" title="Work-in-progress limit" maxlength="3" placeholder="WIP" id="wip_${object.id}"></input>
                           </div>
                      </div>
                       `);
                        updateWipLimit(object.id, wipLimit);
                  }
                  else{
                    var wipLimit = getWipLimit(object.id, mypage_wip_limit);
                    $(".table-div-board").append(`
                    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                   <div style="display:flex;">
                     <input  name="input-board"  id="${object.id}" value="false" class="boards_${object.id} "   type="checkbox">
                   </div>
                  <div style="display:flex;">
                     <span  class="board-name">${object.name}</span>
                      </div>
                      <div style="display:flex;">
                      <input  class="board-wip-limit" title="Work-in-progress limit" maxlength="3" placeholder="WIP" id="wip_${object.id}"></input>
                       </div>
                  </div>
                   `);
                    updateWipLimit(object.id, wipLimit);
                  }
               })
             
              },
                error: function (xhr, status, error) {
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
             })
             var fieldset = $(el).parents('fieldset').first();
             fieldset.toggleClass('collapsed');
             fieldset.children('legend').toggleClass('icon-collapsed icon-setting');
             fieldset.children('div').toggle();

             setTimeout(() => {
              if (story_points_enabled != "1")
              {
                 var boardNames = document.querySelectorAll('.board-name');
                  boardNames.forEach(function(boardName) {
                        if (boardName.textContent.trim() === 'Story Points') {
                          boardName.closest('.random-div').style.display = 'none';
                        }
                      });
                     }
          }, 100);
             
         
  
          

          // ----------------------------------------------------
           }
           window.toggleBoard=function (el)
           {
            var fieldset = $(el).parents('fieldset').first();
            fieldset.toggleClass('collapsed');
           fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
           fieldset.children('div').toggle();
           }
                  window.toggleCards=function (el)
           {
             var fieldset = $(el).parents('fieldset').first();
             fieldset.toggleClass('collapsed');
             fieldset.children('legend').toggleClass('icon-boards icon-collapsed');
             fieldset.children('div').toggle();
           }
    function removeAjaxIndicator() {

        $(document).bind('ajaxSend', function(event, xhr, settings) {
          if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
          $('#ajax-indicator').hide();   
          }
        });
        $(document).bind('ajaxStop', function() {
          $('#ajax-indicator').hide(); 
        });
      }
       
      window.updateOptions = function() {
        var tableDivBoard = document.querySelector('.table-div-board');
        var checkboxesBoard = tableDivBoard.querySelectorAll('div.random-div > div:nth-child(1) > input[type="checkbox"]');
        var my_page_boardboxids = [];
        var isError = false;
      
        for (var i = 0; i < checkboxesBoard.length; i++) {
          if (checkboxesBoard[i].checked) {
            my_page_boardboxids.push({"id": checkboxesBoard[i].id, "my_page_status": true});
          } else {
            my_page_boardboxids.push({"id": checkboxesBoard[i].id, "my_page_status": false});
          }
        }
      
        let allAgileStatusFalse = my_page_boardboxids.every(project => project.my_page_status === false);
      
        var tableDivCard = document.querySelector('.table-div-cardfields');
        var checkboxesCard = tableDivCard.querySelectorAll('div.random-div > div:nth-child(1) > input[type="checkbox"]');
        var cardboxids = [];
      
        for (var i = 0; i < checkboxesCard.length; i++) {
          if (checkboxesCard[i].checked) {
            cardboxids.push({"id": checkboxesCard[i].id, "my_page_field": true});
          } else {
            cardboxids.push({"id": checkboxesCard[i].id, "my_page_field": false});
          }
        }
      
        let allCardFieldsFalse = cardboxids.every(project => project.my_page_field === false);
      
        if (allAgileStatusFalse && allCardFieldsFalse) {
          isError = true;
          toastr["error"]("Please select at least one Board column and one Card field");
        } else if (allAgileStatusFalse) {
          isError = true;
          toastr["error"]('Please select at least one Board column');
        } else if (allCardFieldsFalse) {
          isError = true;
          toastr["error"]("Please select at least one Card field");
        }
      
        if (!isError) {
          $.ajax({
            type: "PUT",
            url: url + `/update_agiles_boards.json?key=${api_key}`,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            data: JSON.stringify({
              my_page_issue_statuses: my_page_boardboxids
            }),
            success: function () {
              var randomDivs = tableDivBoard.querySelectorAll('.random-div');
              var wipLimits = [];
              randomDivs.forEach((randomDiv) => {
                var statusId = randomDiv.querySelector('input[name="input-board"]').id;
                var wipLimitInput = randomDiv.querySelector('.board-wip-limit');
                var wipLimit = wipLimitInput.value.trim();
                if (/^\d+$/.test(wipLimit)) {
                  let formattedResult = {
                    status_id: statusId,
                    limit: wipLimit
                  };
                  wipLimits.push(formattedResult);
                }
              });
      
              var wipLimitsJSON = JSON.stringify(wipLimits);
      
              var data = {
                user_id: login_user_id,
                mypage_wip_limit: wipLimitsJSON
              };
      
              $.ajax({
                type: "PUT",
                url: url + `/update_wip_limits.json?key=${api_key}`,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                data: JSON.stringify(data),
                success: function () {
                  // console.log("api run of wip limits");
                }
              });
            }
          });
      
          $.ajax({
            type: "PUT",
            url: url + `/card_field_update.json?key=${api_key}`,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            data: JSON.stringify({
              my_card_fields: cardboxids
            }),
            success: function () {
              // console.log("api run of card fields");
            }
          });
      
          location.reload();
        }
      }

        function getSpentTime(project_Id){
        
           $.ajax({
            type: "GET",
            url: self.url+`/time_entries.json?key=${api_key}`,
            dataType: "json",
            async:false,
            contentType: 'application/json',
            success: function (result, status, xhr) {
           result.time_entries.reduce(function(sum, current) {
             if(current.project.name.split(' ').join('-').toLowerCase()==project_Id)
              {
                      return  total_spent_time_project= total_spent_time_project + current.hours;
              }
               else {
                     return total_spent_time= sum + current.hours;
              }
              }, 0);


  
                setTimeout(() => {
                  mypage_updateKanbanContainerStatus();
                  }, 500);
            
            
                JSON.parse(localStorage.getItem("total_time")).forEach((object,i)=>{
                  if(object==="spent_time" && view_spent_time === true)
                  {
                      $("#query-id").css("display","block");
                           if(project_Id)
                           {
                               total_spent_time_project=parseFloat(total_spent_time_project).toFixed(2);
                          $(".value-spent-time").html(total_spent_time_project);
                       
                           }
                           else{
                           total_spent_time=parseFloat(total_spent_time).toFixed(2);
                         $(".value-spent-time").html(total_spent_time);
                  }
                  }
                })
            },
    
            error: function (xhr, status, error) {
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
             }
          })

        }
        window.clearOptions=function(){
            $("#query_form_with_buttons").toggle();
            if ($('.context-menu-popup-main').is(':visible')) {
              $(":tabbable").attr("tabindex", -1);
              $(".context-menu-popup-main [tabindex='-1']").attr("tabindex", 0);
              
            } else {
              $("[tabindex='-1']").attr("tabindex", 0);
            }
        }
        window.showSettingUI=function (el){
              $("#query_form_with_buttons").toggle();
        }
      function showSettings(el){

         $(`<div style="display:none;"  id="query_form_with_buttons" class="hide-when-print setting-agile">
           <div id="query_form_content">
             <fieldset  class="collapsible collapsed">
             <legend onclick="toggleSet(this)" class="icon icon-collapsed">Settings</legend>
               <div class="table-div" style="display:none">
                  <table >
                  <tbody>
                  <tr>
                  <td colspan="2">
                  <fieldset   style="margin-bottom:13px;"   class="collapsible collapsed">
                    <legend  id="legend-setting" onclick="toggleBoard(this)" class="icon icon-boards">Board columns</legend>
                        <div class="table-div-board" style="display:flex; flex-wrap:wrap;" >
                          
                        </div>
                  </fieldset>
                  </td>
                  </tr>
                       <tr>
                  <td colspan="2">
                  <fieldset  style="margin-bottom:13px;" class="collapsible collapsed">
                    <legend onclick="toggleCards(this)" class="icon icon-boards">Card fields</legend>
                        <div class="table-div-cardfields" style="display:flex; flex-wrap:wrap;" >
                        </div>
                  </fieldset>
                  </td>
                  </tr>
                  <!--  <tr>
                  <td colspan="2">
                  <div style="display:flex;  flex-direction:column; gap:6px; margin-bottom:13px;">
                     <div style="display:flex; flex-direction:row; margin-bottom:0.25rem; gap:20px;">
                     <div  style="display:flex; justify-content:center; align-items:center;">
                     <div   style="display:flex; ">
                        <label class="agile_options_label">
                         Colored by
                         </label>
                         </div>
                         </div>
                         <div style="display:flex;">
                         <select name="color_base" id="color_base">
                           <option value="none">No colors</option>
                           <option  value="tracker">Tracker</option>
                           <option value="priority">Priority</option>
                            <option  value="user">Assignee</option> 
                       </select>
                       </div>
                       </div>
                   
                  </td>
                  </tr>-->
                  </tbody>
                  </table>
                  </div>
           </div>
          <p class="buttons">
          <input  type="submit" value="Save" data-disable-with="Save" style="cursor:pointer"  onclick="updateOptions()"  />
          <a id="cancel_button_mypage" style="cursor:pointer"  onclick="clearOptions()"   >Cancel</a>  
          </p>
        </div>
          `).insertAfter(".heading-agile-board");
          // ------
          //  let card_data=JSON.parse(localStorage.getItem("card_fields"))
        //    card_array.forEach((list,i)=>{
        //     if((list.value==="id")||(list.value==="tracker")||(list.value==="priority")||(list.value==="assigned_to")||(list.value==="start_date")||(list.value==="due_date")||(list.value==="done_ratio")||(list.value==="subject"))
        //     {
        //      $(".table-div-cardfields").append(` <label class="floating">
        //      <input name="input-check"  disabled checked value=${list.value}  class="board-checkbox"  type="checkbox" >
        //          ${list.name}
        //     </label>`)
        //     }
        //     else if(card_data&&card_data.includes(list.value))
        //     {
        //       $(".table-div-cardfields").append(`
        //       <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;width: 150px;">
        //       <div style="display:flex;">
        //       <input name="input-check"   checked value=${list.value}  class="board-checkbox"  type="checkbox" >
        //       </div>
        //      <div style="display:flex;">
        //         <span  class="board-name"> ${list.name}</span>
        //          </div>
        //      </div>
        //     `)
        //     }
        //     else{
        //      $(".table-div-cardfields").append(`    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px;width: 150px;">
        //      <div style="display:flex;">
        //      <input name="input-check"    value=${list.value}  class="board-checkbox"  type="checkbox" >
        //      </div>
        //     <div style="display:flex;">
        //        <span  class="board-name"> ${list.name}</span>
        //         </div>
        //     </div>`)
        //     }
        // })
        // ------
     
        $.ajax({
          type: "GET",
          url:url+`/card_fields.json?key=${api_key}`,
          dataType: "json",
          success: function (result, status, xhr) {
            // cards=result;
          
            $(".table-div-cardfields").html(" ");
            result.forEach((object,i)=>{
              // if (object.field_value === true ){
                if (object.my_page_field === true ){
                cards.push(object.field_name);
                
                }
              // if( object.field_name == "Issue ID" || object.field_name  == "Tracker" || object.field_name == "Subject" || object.field_name  == "Assignee" || object.field_name  == "Priority"){

              //  $(".table-div-cardfields").append(`
              //       <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
              //      <div style="display:flex;">
              //        <input  name="input-board" disabled checked='checked'  id="${object.id}"   value="${object.my_page_field}" class="card_${object.id}"   type="checkbox">
              //      </div>
              //     <div style="display:flex;">
              //        <span  class="board-name">${object.field_name}</span>
              //         </div>
              //     </div>
              //      `);

              // }
               if ( object.my_page_field == true){
               $(".table-div-cardfields").append(`
                    <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
                   <div style="display:flex;">
                     <input  name="input-board"  id="${object.id}" checked="checked"  value="${object.my_page_field}" class="card_${object.id}"   type="checkbox">
                   </div>
                  <div style="display:flex;">
                     <span  class="board-name">${object.field_name}</span>
                      </div>
                  </div>
                   `);
          }
          else {
            $(".table-div-cardfields").append(`
           <div class="random-div" style="display:flex; align-items:center; flex-direction:row; gap:5px; ">
          <div style="display:flex;">
            <input  name="input-board"  id="${object.id}"   value="${object.my_page_field}" class="card_${object.id}"   type="checkbox">
          </div>
         <div style="display:flex;">
            <span  class="board-name">${object.field_name}</span>
             </div>
         </div>
          `);
          }

        });
      }
        });
        // ====
          }
          var workflow_status;
          function getWorkflow(id){
          
               $.ajax({
              type: "GET",
              url: `${self.url}/tracker_workflow_status.json?key=${api_key}` ,
              dataType: "json",
              async:false,
              contentType: 'application/json',
              data:  {
                issue_id:parseInt(id)
              },
              success: function (result, status, xhr) {
                // console.log(result,"result")
                 workflow_status= result;
              },
              error: function (xhr, status, error) {
                // console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
               }
            })
            // console.log(workflow_status,"worflow Satus ");
            return workflow_status;
        }
  
      $(document).ready(function () {
          if(!localStorage.getItem("total_time"))
           {
              localStorage.setItem("total_time",JSON.stringify(total_time))
           }
           if(!localStorage.getItem("selected_color"))
           {
              localStorage.setItem("selected_color","tracker")
           }
           if(!localStorage.getItem("card_fields"))
           {
              localStorage.setItem("card_fields",JSON.stringify(card_field))
           }

           setTimeout(() => {
            // var wipLimits = JSON.parse(localStorage.getItem('my_page wipLimits'));
            var wipLimits = mypage_wip_limit;
            // console.log(wipLimits,"wip limits");
          if (wipLimits) {
            wipLimits.forEach(function (limit) {
              var statusId = limit.status_id;
              var wipLimit = limit.limit;
              // console.log(statusId, wipLimit,"status id and wip limit");
             
              //  var wipLimitInput = document.getElementById(`wip-` + statusId );
              setTimeout(() => {
              var wipLimitInput = document.getElementById(`wip_` + statusId );
              
                // console.log(wipLimitInput, "wip limit input");
                if (wipLimitInput) {
                  // console.log("inside");
                  wipLimitInput.value = wipLimit;
                }
              }, 500);
          
            });
          }
          }), 1000;



       $("#options").css("display","none"); 
           showSettings();
           removeAjaxIndicator();
              const params =window.location.search
              const parameters = new URLSearchParams(params);
              if(window.location.href===`${url}/my/page`)
              {

             $.ajax({
              type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
              dataType: "json",
              success: function (result, status, xhr) {
         
              const params =window.location.search
            
                let  parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
              $.ajax({
              type: "GET",
              url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&assigned_to_id=${login_user_id}`:url+`/issues.json?key=${api_key}&assigned_to_id=${login_user_id}&limit=10`,
              dataType: "json",
              beforeSend: function(){
              let body_div=document.getElementsByClassName("controller-my action-page");
              let div=document.createElement("div");
              div.className="unknown-div";
              div.style.display="block";
              body_div[0].appendChild(div);
               $('.circle-loader').show();
             },
              success: function (res, status, xhr) {
                // console.log(res.total_count,"res");
                agile_issues_my_page=res.issues;
                  if(res.issues.length==0)
              {
                     $(".nodata").css("display","none");
                     $("#myKanban_").css("display","block");
                    // $("#myKanban_").css("display","none");
                    // $(".setting-agile").after(`<p style="margin-top:30px;" class="nodata">No data to display</p>`);
              }
              else{
                     $(".nodata").css("display","none");
                    //  $("#myKanban_").css("display","block"); // Having issue with the expand/collapse functionality in the theme, so I commented it out.
              }
                  total_assigned_issue=res.total_count;
                  $(".agile_board_counting").html(`(${total_assigned_issue})`);
             getSpentTime();
              $('.circle-loader').toggleClass('load-complete');
              $('.checkmark').toggle();
              setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
          
                result.issue_statuses.forEach(object => {
                          object.item= []
                          
                });
                
                res.issues.forEach(object => {
                   result.issue_statuses.forEach(option=>{
                     if(object.status.name==option.name)
                      {
                       option.item.push(object)
                        }
                      });
                   });           
               
                 const  array_item=[];
                 result.issue_statuses.forEach(object => {
                          array_item.push(''+object.id)    
                });
    
                result.issue_statuses.forEach((object,i)=> {
               
                       if(board_data){
                        board_data.forEach((list)=>{
                         if(list==object.id)
                         {
                           boards_array.push(object)
                         }
                        })
                      }
                          object.id=''+object.id
                          object.dragTo=array_item
                          object.issueCount=object.item.length
                 });
                 
                
              // if(JSON.parse(localStorage.getItem("boards")))
              // {
                let local_data= board_data
                // let local_data= JSON.parse(localStorage.getItem("boards"))
                     result.issue_statuses.forEach((object,i)=> {
                          if(local_data.includes(object.id))
                          {
                             boards_array.push(object)
                          }
                     })
              
               
               res.issues.reduce(function(sum, current) {
                   return total_hour= sum + current.estimated_hours;
                    }, 0); 
                   
                      //  if(!localStorage.getItem("total_time"))
                      //   {
                      //     localStorage.setItem("total_time",JSON.stringify(total_time))
                      //    }
                      

                       if(JSON.parse(localStorage.getItem("total_time")))
                       {   
                       JSON.parse(localStorage.getItem("total_time")).forEach((object,i)=>{

                      if(object==="estimated_time" && view_spent_time === true)
                  {
                      
                      $("#query-id").css("display","block");
                       total_hour=parseFloat(total_hour).toFixed(2);
                      $(".value-estimated-time").html(total_hour);
                  }
                })
              }
               var KanbanTest = new jKanban({
                element: "#myKanban_",
                color:"red",
                // gutter: "8px",
                // widthBoard: "445px",
                itemHandleOptions:{
                  enabled: true,
                },
               context: function(el, e) {
               },
               dropEl: function(el, target, source, sibling , target_id){
                getWorkflow(el.dataset.eid);

                var target_int = parseInt(sibling);
              
                toastr.options = {
                  closeButton: true,
                  debug: false,
                  newestOnTop: false,
                  progressBar: true,
                  positionClass: "toast-top-right",
                  preventDuplicates: false,
                  onclick: null,
                  showDuration: "300",
                  hideDuration: "1000",
                  timeOut: "2000",
                  extendedTimeOut: "1000",
                  showEasing: "swing",
                  hideEasing: "linear",
                  showMethod: "fadeIn",
                  hideMethod: "fadeOut",
                };
                
              
                // console.log(workflow_status,'workload status my pagee');
                // console.log(target_int,'target intt my page');

                if (workflow_status.includes(target_int)) {
                  // console.log("successfully applied 6");
                  // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully ");                    
                  // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                  var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                  var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);

                  // console.log(header_kanban,"header kanban");
                  // console.log(matches,"matches");
                  if (matches && matches.length === 3) {
                    // Extracted values in integer format
                    var value1 = parseInt(matches[1]);
                    var value2 = parseInt(matches[2]);
        
                   
                    value1++;
        
                  
                    if (value1 > value2) {
                        toastr.warning("Work-in-progress limit exceeded !! ");
                       }       
                    }

                } 
                else if (workflow_status.length === 0) {
                  // console.log("No the issue[#"+ el.dataset.eid +"] status is never be changed ");
                  toastr["error"]('workflow is not defined for this status');
                  KanbanTest.drake.cancel(true);

                  
                }
                 else {
                  // console.log(workflow_status,"NO the issue[#" + el.dataset.eid +"] status not be change please drop another container");
                  toastr["error"]('workflow is not defined for this status');
                  KanbanTest.drake.cancel(true);

                }

                var content =
               {
                   "status_id": parseInt(sibling)
                }
               $.ajax({
              type: "PUT",
              url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
              dataType: "json",
              contentType: 'application/json',
              data: JSON.stringify({
              "issue": content
             }),
              success: function (res,status, xhr) {      
              $.ajax({
               type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
               dataType: "json",
              success: function (Newresult, status, xhr) {
              const params =window.location.search
              const parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
              $.ajax({
              type: "GET",
              url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}`:url+`/issues.json?key=${api_key}`,
              dataType: "json",
              success: function (Newres, status, xhr) {
                agile_issues_my_page=Newres.issues;
               Newresult.issue_statuses.forEach(object => {
                          object.item= []
                });
              Newres.issues.forEach(object => {
                  Newresult.issue_statuses.forEach(option=>{
                     if(object.status.name==option.name)
                      {
                        option.item.push(object)
                       }
                      });
                   });           
                const  array_item=[];
                 Newresult.issue_statuses.forEach(object => {
                          array_item.push(''+object.id)    
                });
                Newresult.issue_statuses.forEach(object => {
                          object.id=''+object.id
                          object.dragTo=array_item
                        object.issueCount=object.item.length

                 });
                 Newresult.issue_statuses.forEach(object => {
                       result.issue_statuses.forEach(option => {
                        option.issueCount=object.item.length
                          
                });
                 })
                //    Newresult.issue_statuses.forEach((data,i)=>{
                //   $(".counting"+data.id).each(function(index,value){
                //     $(this).html(`(${data.issueCount})`)
                //    });
                //  })
                // ----------------
                issue_bords_ids = KanbanTest.options.boards ;  //boards id
                issue_counting = KanbanTest.boardContainer ;    //issue updated values

               var issue_update_value = [];
               var issue_bords_update = [];

              
              //  console.log(issue_bords_update,'isssue boards update');

              issue_bords_ids.forEach((object,i)=>{
                issue_bords_update.push(object.id);
              });



              issue_counting.forEach((object,i)=>{
                issue_update_value.push(object.childElementCount);
              //  console.log(object.childElementCount,'child countingg')
              });

     
          
// -------------
  

                for (let i = 0; i < issue_bords_update.length; i++) {
                  let currentStatusId = issue_bords_update[i];
                  let currentWipLimit =  Array.isArray(mypage_wip_limit) ? mypage_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                
                  let wipLimitHtml = '';
                  if (currentWipLimit) {
                      wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                  } else {
                      wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                  }
                
                  $('.counting' + currentStatusId).html(wipLimitHtml);
                }
    
                  setTimeout(() => {
                    mypage_updateKanbanContainerStatus();
                    }, 500);

                    // ------
              }
             });
            },
             error: function (xhr, status, error) {
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
        });
            },
             error: function (xhr, status, error) {
            //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
             }
              });
                },
                itemAddOptions: {
                  enabled: project_id?true:false,
                  content: '+ Add New ISSUE',
                  class: 'Add-card',
                  footer: true
                },
                boards:boards_array,
                cardCounter:result.issue_statuses.length
               
              });

                 }, 
               error: function (xhr, status, error) {
              setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
              //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
              });
            },
             error: function (xhr, status, error) {
            setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
        });
              }
              else{
              let  params =window.location.search
               let  parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
           
              $.ajax({
              type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
              dataType: "json",
              success: function (result, status, xhr) {
              const params =window.location.search
               let  parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
              $.ajax({
              type: "GET",
              url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}` :url+`/issues.json?key=${api_key}&${params}` ,
              dataType: "json",
              beforeSend: function(){
              let body_div=document.getElementsByClassName("controller-my action-page");
              let div=document.createElement("div");
              div.className="unknown-div";
              div.style.display="block";
              body_div[0].appendChild(div);
               $('.circle-loader').show();
             },
              success: function (res, status, xhr) {
                agile_issues_my_page=res.issues;
               getSpentTime(project_id);
              $('.circle-loader').toggleClass('load-complete');
              $('.checkmark').toggle();
              setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
          
                result.issue_statuses.forEach(object => {
                          object.item= []
                          
                });
                res.issues.forEach(object => {
                   result.issue_statuses.forEach(option=>{
                     if(object.status.name==option.name)
                      {
                       option.item.push(object)
                        }
                      });
                   });    
                   
       
               res.issues.reduce(function(sum, current) {
                   return total_hour= sum + current.estimated_hours;
                    }, 0); 
                  if(JSON.parse(localStorage.getItem("total_time"))&&JSON.parse(localStorage.getItem("total_time")).length==0)
                        {

                          localStorage.setItem("total_time",JSON.stringify(total_time))
                         }
                       if(JSON.parse(localStorage.getItem("total_time")))
                       {   
                JSON.parse(localStorage.getItem("total_time")).forEach((object,i)=>{
             
                  if(object==="estimated_time")
                  {
                      
                      $("#query-id").css("display","block");
                       total_hour=parseFloat(total_hour).toFixed(2);
                    
                      $(".value-estimated-time").html(total_hour);
                  }
                })
              }

                 const  array_item=[];
                 result.issue_statuses.forEach(object => {
                          array_item.push(''+object.id)    
                });
                result.issue_statuses.forEach(object => {
                          object.id=''+object.id
                          object.dragTo=array_item
                          object.issueCount=object.item.length
                 });
                 result.issue_statuses.forEach((object,i)=> {
                
                        if(JSON.parse(localStorage.getItem("boards"))){
                         JSON.parse(localStorage.getItem("boards")).forEach((list)=>{
                          if(list==object.id)
                          {
                            boards_array.push(object)
                          }
                         })
                       }
                          object.id=''+object.id
                          object.dragTo=array_item
                          object.issueCount=object.item.length
                 });
                 
              if(JSON.parse(localStorage.getItem("boards")))
              {
                let local_data= JSON.parse(localStorage.getItem("boards"))
                     result.issue_statuses.forEach((object,i)=> {
                          if(local_data.includes(object.id))
                          {
                             boards_array.push(object)
                          }
                     })
              }
           var KanbanTest = new jKanban({
                element: "#myKanban_",
                // gutter: "8px",
                // widthBoard: "445px",
                itemHandleOptions:{
                  enabled: true,
                },
               context: function(el, e) {
               },
               dropEl: function(el, target, source, sibling, target_id){
                getWorkflow(el.dataset.eid);

                var target_int = parseInt(target_id);
              
                toastr.options = {
                  closeButton: true,
                  debug: false,
                  newestOnTop: false,
                  progressBar: true,
                  positionClass: "toast-top-right",
                  preventDuplicates: false,
                  onclick: null,
                  showDuration: "300",
                  hideDuration: "1000",
                  timeOut: "2000",
                  extendedTimeOut: "1000",
                  showEasing: "swing",
                  hideEasing: "linear",
                  showMethod: "fadeIn",
                  hideMethod: "fadeOut",
                };
                
              
                // console.log(target_int,'target inttt my page');
                // console.log(workflow_status,'workload status my page');

                if (workflow_status.includes(target_int)) {
                  // console.log("successfully applied 7");
                  // console.log("The issue[#"+ el.dataset.eid +"] is changed  successfully ");                    
                  // toastr["success"]("the issue #"+  el.dataset.eid  +" status  is changed successfully");
                  var header_kanban = el.closest('.kanban-board').querySelector('.kanban-title-board').innerText;
                  var matches = header_kanban.match(/(\d+)\s*\/\s*(\d+)/);

                  // console.log(header_kanban,"header kanban");
                  // console.log(matches,"matches");
                  if (matches && matches.length === 3) {
                    // Extracted values in integer format
                    var value1 = parseInt(matches[1]);
                    var value2 = parseInt(matches[2]);
        
                   
                    value1++;
        
                  
                    if (value1 > value2) {
                        toastr.warning("Work-in-progress limit exceeded !! ");
                       }       
                    }
                } 
                else if (workflow_status.length === 0) {
                  // console.log("No the issue[#"+ el.dataset.eid +"] status is never be changed ");
                  toastr["error"]('workflow is not defined for this status');
                  KanbanTest.drake.cancel(true);

                  
                }
                 else {
                  // console.log(workflow_status,"NO the issue[#" + el.dataset.eid +"] status not be change please drop another container");
                  toastr["error"]('workflow is not defined for this status');
                  KanbanTest.drake.cancel(true);

                }

               var content =
               {
                   "status_id": parseInt(sibling)
                }
               $.ajax({
              type: "PUT",
              url: url+`/issues/${el.dataset.eid}.json?key=${api_key}`,
              dataType: "json",
              contentType: 'application/json',
              data: JSON.stringify({
              "issue": content
             }),
              success: function (res,status, xhr) {      
              $.ajax({
               type: "GET",
              url:url+`/issue_statuses.json?key=${api_key}`,
               dataType: "json",
              success: function (Newresult, status, xhr) {
              const params =window.location.search
              const parameters = new URLSearchParams(params);
              const  project_id = parameters.get('project_id');
              $.ajax({
              type: "GET",
              url: project_id? url+`/projects/${project_id}/issues.json?key=${api_key}&${params}`:url+`/issues.json?key=${api_key}&${params}`,
              dataType: "json",
              success: function (Newres, status, xhr) {
                agile_issues_my_page=Newres.issues;
               Newresult.issue_statuses.forEach(object => {
                          object.item= []
                });
              Newres.issues.forEach(object => {
                  Newresult.issue_statuses.forEach(option=>{
                     if(object.status.name==option.name)
                      {
                        option.item.push(object)
                       }
                      });
                   });           
                const  array_item=[];
                 Newresult.issue_statuses.forEach(object => {
                          array_item.push(''+object.id)    
                });
                Newresult.issue_statuses.forEach(object => {
                          object.id=''+object.id
                          object.dragTo=array_item
                        object.issueCount=object.item.length

                 });
                 Newresult.issue_statuses.forEach(object => {
                       result.issue_statuses.forEach(option => {
                        option.issueCount=object.item.length
                          
                });
                 })
                //    Newresult.issue_statuses.forEach((data,i)=>{
                //   $(".counting"+data.id).each(function(index,value){
                //     $(this).html(`(${data.issueCount})`)
                //    });
                //  })
                                // ----------------
                                issue_bords_ids = KanbanTest.options.boards ;  //boards id
                                issue_counting = KanbanTest.boardContainer ;    //issue updated values
                
                               var issue_update_value = [];
                               var issue_bords_update = [];
                
                              
                              //  console.log(issue_bords_update,'isssue boards update ,,,,');
                
                              issue_bords_ids.forEach((object,i)=>{
                                issue_bords_update.push(object.id);
                              });
                
                
                
                              issue_counting.forEach((object,i)=>{
                                issue_update_value.push(object.childElementCount);
                              //  console.log(object.childElementCount,'child countingg ,,,,,, ')
                              });
                
                     
                          
                // -------------
                            // for (let i = 0; i < issue_bords_update.length; i++) {
                            //   $('.counting' + issue_bords_update[i]).html('( '+ issue_update_value[i] + ' <span class="wip" id="wip_limit_' + issue_bords_update[i] + '"></span>)');
                            // }
                            for (let i = 0; i < issue_bords_update.length; i++) {
                              let currentStatusId = issue_bords_update[i];
                              let currentWipLimit =  Array.isArray(mypage_wip_limit) ? mypage_wip_limit.find(entry => entry.status_id === currentStatusId) : null;
                            
                              let wipLimitHtml = '';
                              if (currentWipLimit) {
                                  wipLimitHtml = '( ' + issue_update_value[i] + ' <span class="wip" id="wip_limit_' + currentStatusId + '"> / ' + currentWipLimit.limit + ' </span>)';
                              } else {
                                  wipLimitHtml = '( ' + issue_update_value[i] + ' )';
                              }
                            
                              $('.counting' + currentStatusId).html(wipLimitHtml);
                            }
              }
             });
            },
             error: function (xhr, status, error) {
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
        });
            },
             error: function (xhr, status, error) {
            //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
             }
              });
                },
                itemAddOptions: {
                  enabled: project_id?true:false,
                  content: '+ Add New ISSUE',
                  class: 'Add-card',
                  footer: true
                },
                boards:boards_array,
                cardCounter:result.issue_statuses.length
               
              });
                 }, 
               error: function (xhr, status, error) {
              setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
              //  alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
              }
              });
            },
             error: function (xhr, status, error) {
            setTimeout(() => {
               $(".unknown-div").css("display","none");
               $('.circle-loader').hide();
               }, 300);
              // alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
            }
        });
              }
});
})





function mypage_updateKanbanContainerStatus() {
  // Get all kanban containers
  var kanbanContainers = document.querySelectorAll('.kanban-container');

  setTimeout(() => {
    if (kanbanContainers) {
      kanbanContainers.forEach(function (container) {
        for (var i = 0; i < container.children.length; i++) {
          var child = container.children[i];

          // Get kanban heading text
          var kanban_heading = child.querySelector('.kanban-title-board').innerText;

          // Check if it's a group kanban or regular kanban
          var isGroupKanban = child.classList.contains('myKanban_');

          var matches = kanban_heading.match(/(\d+) \/ (\d+)/);

          if (matches && matches.length === 3) {
            var issueCount = parseInt(matches[1]);
            var wipLimit = parseInt(matches[2]);

            // Check if it's a group kanban or regular kanban
            if (isGroupKanban) {
              var wipLimitElement = child.querySelector('.wip');
            } else {
              var wipLimitElement = child.querySelector('.pc-counting .wip');
            }

            // Update the wip limit element
            // if (wipLimitElement) {
            //   wipLimitElement.textContent = `/${wipLimit}`;
            // }

            if (!isNaN(issueCount) && !isNaN(wipLimit) && wipLimit < issueCount) {
              child.classList.add('kanban_red');
            } else {
              child.classList.remove('kanban_red');
            }
          }
        }
      });
    }
  }, 500);
}

function getWipLimit(statusId, wipLimits) {
  if (wipLimits) {
      var limit = wipLimits.find((limit) => limit.status_id === String(statusId));
    
      return limit ? limit.limit : null;
      
  }
  return null;
}

function updateWipLimit(statusId, wipLimit) {
  var wipLimitInput = document.getElementById(`wip_${statusId}`);
  if (wipLimitInput) {
      wipLimitInput.value = wipLimit || ""; 
  }
}