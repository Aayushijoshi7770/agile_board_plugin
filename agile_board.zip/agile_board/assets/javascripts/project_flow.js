var selected_users = [];
var selected_roles = [];
$(document).ready(function () {



    $(document).on('change', 'form#new_membership input[type="checkbox"][name="membership[user_ids][]"]', function () {
        var value = this.value;
        if (this.checked) {
            selected_users.push(value);
            // console.log('Checked: ' + value);
        } else {
            var index = selected_users.indexOf(value);
            if (index !== -1) {
                selected_users.splice(index, 1);
                // console.log('Unchecked: ' + value);
            }
        }

        // console.log('Selected Users Array:', selected_users);
        // $('#selected_users_input').val(JSON.stringify(selected_users));
    });


    $(document).on('change', 'form#new_membership input[type="checkbox"][name="membership[role_ids][]"]', function () {
        var value = this.value;
        if (this.checked) {
            selected_roles.push(value);
            // console.log('Checked: ' + value);
        } else {
            var index = selected_roles.indexOf(value);
            if (index !== -1) {
                selected_roles.splice(index, 1);
                // console.log('Unchecked: ' + value);
            }
        }
        // console.log('Selected Roles Array:', selected_roles);
    });


    $(document).on('click', '#member-add-submit', function () {
        if (selected_roles.length > 0) {
        var selectedUsersString = JSON.stringify(selected_users);
        $('#selected_users_input').val(selectedUsersString);
        selected_users = [];
        selected_roles = [];
        } 
        // console.log('Selected Users Array Cleared');
    });

    $(document).on('click', 'form#new_membership > p.buttons > a', function () {
        selected_users = [];
        selected_roles = [];
        // console.log('Selected Users Array Cleared (Anchor Clicked)');
    });

    $(document).on('click', '.ui-dialog-titlebar-close', function () {
        selected_users = [];
        selected_roles = [];
        // console.log('Selected Users Array Cleared (Close Button Clicked)');
    });




  

});
// =============================================

function checked_user(selected_users){
   
    setTimeout(() => {
        checked(selected_users);
      }, 1000);
}

function checked(selected_users){
    // console.log(selected_users,'all the selected users list');
    

    selected_users.forEach(function(userId) {
        var checkbox = document.querySelector('input[type="checkbox"][value="' + userId + '"]');
        //   console.log(checkbox,'total outside');
        if (checkbox) {
          checkbox.checked = true;
          checkbox.setAttribute('checked', 'checked');
        //    console.log(checkbox,'checkbox inside');
        }
    });

    }

