function removeAjaxIndicator() {
  
    $(document).bind('ajaxSend', function(event, xhr, settings) {
      if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
      $('#ajax-indicator').hide();   
      }
    });
    $(document).bind('ajaxStop', function() {
      $('#ajax-indicator').hide(); 
    });
  }

$(document).ready(function () {
  removeAjaxIndicator();
  card_fields.map((object)=>{
    if (object.field_value === true ){
      cards.push(object.field_name);               
      }
    // project 
    if (object.project_field_value === true ){
      // project_cards.push(object.field_name);               
      }
      if(object.version_field_value === true)
      {
        version_cards.push(object.field_name);
      }
      if(object.sprint_field_value === true)
      {
        sprint_cards.push(object.field_name);
      }
      

    //search on backlog
    $('#version_search').on('input', function () {
      performVersionSearch();
    });
    
    function performVersionSearch() {
      var searchValue = $('#version_search').val().toLowerCase();
    
      $('.kanban-item-color').each(function () {
        var issueSubject = $(this).find('.subject-agile').text().toLowerCase();
    
        if (issueSubject.includes(searchValue)) {
          $(this).css('opacity', '1');
        } 
        else {
          $(this).css('opacity', '0.2');
        }
      });
    } 
    
    // search for sprint 
    $('#sprint_search').on('input', function () {
      performSprintSearch();
    });
    
    function performSprintSearch() {
      var searchValue = $('#sprint_search').val().toLowerCase();
    
      $('.kanban-item-color').each(function () {
        var issueSubject = $(this).find('.subject-agile').text().toLowerCase();
    
        if (issueSubject.includes(searchValue)) {
          $(this).css('opacity', '1');
        } 
        else {
          $(this).css('opacity', '0.2');
        }
      });
    } 
  })  
  
  // -------project ---------

  
})