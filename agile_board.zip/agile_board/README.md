# Agile Board Plugin 

## Introduction

The Agile Board plugin enhances Redmine by adding agile project management features,Agile Board provides a visual, interactive platform for organizing tasks, tracking progress, and adapting to changing requirements in real-time. Seamlessly prioritize work, allocate resources efficiently, and foster continuous improvement through iterative development cycles. With customizable workflows and user-friendly interface, Agile Board facilitates agile methodologies such as Scrum and Kanban, enabling teams to respond swiftly to customer feedback and deliver high-quality results with speed and precision. Unlock the full potential of your projects, promote transparency, and drive productivity with Agile Board and its Assist your teams to work smarter, identify and eliminate roadblocks, & deliver projects faster with Agile Board. Agile Board plugin provides an intuitive platform to manage tasks using agile methodologies within Redmine.

![Agile Board Plugin](agile_board_plugin.png)


## Table of Contents
   - [Installation](#installation)
   - [Getting-started](#Getting-started)
   - [Features](#Features)
   - [Uninstallation](#Uninstallation)
   - [Version-Compatibility](#Version-Compatibility)
   - [Library](#Library)



# Installation
To install the Agile Board Plugin, follow the below steps:

   - Ensure that you have a functional installation of Redmine.
   - Unzip the Agile Board Plugin in Redmine/plugins, and do not change the plugin folder name
   - Run the following command to install the dependencies
   
      ```sh
         bundle install
      ```
   
   
   
   - Run migrate command to migrate the database 
   - In production 

      ```sh
        RAILS_ENV=production bundle exec rails redmine:plugins:migrate
      ```
   - In development 

       ```sh
        RAILS_ENV=development bundle exec rails redmine:plugins:migrate
       ```

   - Restarting the Redmine server.

      ```sh
        rails s
      ```

# Getting started

**Step 1:**  To Enable API 
   - Login as a administrator.
   - Navigate to **Administration** tab from top menu.
   - Click on **Settings** and find the **API** tab and enable the rest API.

**step 2:** Add Agile board for particular project
   - Go to project setting page
   - check the checkbox of agile board in project modules
   - click to Apply to save the changes

**step 3:** Add story points 
   - Go to the administration plugin page.
   - Click on the Agile Board Plugin to configure settings.
   - Check the checkbox for Story Points.
   - Select the tracker for which you want to add story points.
   - Enter the desired story points values in the input field.
   - Click on Apply to save the changes.

**step 4:** Add sprint
   - Go to the project settings page.
   - Click on the Sprints tab.
   - Click on the Add Sprint button.
   - Provide necessary details for the new sprint.
   - Click on Save to add the sprint to your project.

**Step 5**: Add Backlog for particular project
   - Navigate to the project setting page.
   - Check the checkbox of Agile Board in the project modules section.
   - Click Apply to save the changes.


**Step 6**: Modify Card Fields and Columns
   - Visit the Agile Board page.
   - Click on the settings icon.
   - A settings popup will appear.
   - In the popup, there are labels with checkboxes representing card fields and column names.
   - Check the card fields you want to display on the card.
   - Check the columns you want to display on the board.
   - Click the Apply button to apply the changes.


**Step 7**: Add Issue in Agile Board
   - Navigate to the particular Agile Board page.
   - Click on the "+ Add New Issue" button.
   - Enter the issue subject and press enter.
   - The issue will be created and displayed on the Agile Board.

**Step 8**: Update the Issue
   - Go to the Agile Board page.
   - Click on the issue card you want to update.
   - An update popup will appear.
   - Click on the field value you wish to update.
   - Close the popup after making the desired changes.

**Step 9**: Delete the Issue
   - Navigate to the Agile Board page.
   - Click on the issue card you want to delete.
   - An update popup will appear.
   - Click on the delete card icon.
   - Confirm deletion in the delete issue popup by clicking the delete button.
   - The issue will be deleted from the Agile Board.

**Step 10**: Add Sprints via Backlog
   - Go to the particular project's backlog page.
   - Navigate to the Sprints tab.
   - Click on the Add Sprint button.
   - Fill out the necessary details in the form.
   - Click on the Submit button to add the sprint to your project.


**Step 11**: Add Versions via Backlog
   - Visit the particular project's backlog page.
   - Navigate to the Versions tab.
   - Click on the Add Version button.
   - Fill out all required fields in the form.
   - Click on the Submit button to add the version to your project.

**Step 12**: Change Board Type from Kanban to Scrum
   - Navigate to the particular project's Agile Board page.
   - Click on the settings icon button.
   - A settings popup will appear.
   - Change the option of board type from Kanban to Scrum.
   - Click the Apply button to save the changes.




# Features

- **Visual Task Management**: Provides a visual representation of tasks and their statuses, allowing teams to easily track progress and identify bottlenecks.
- **Real-Time Updates**: Updates tasks and their statuses in real-time, ensuring that everyone on the team has access to the latest information and can respond promptly to changes.
- **Drag-and-Drop Functionality**: Easily prioritize and reorganize tasks by dragging and dropping them within the board.
- **Customizable Columns**: Tailor the board to your team's workflow by defining custom columns to represent various stages of your process.
- **Efficient Workflow**: Streamline your team's workflow with an intuitive interface designed for agile project management.
- **Integration with Redmine**: Fully integrates with Redmine's features and functionalities, providing a seamless experience for users familiar with the Redmine environment.
- **Time Log**: Log time for tasks directly within the Agile Board for accurate time tracking
- **Issue Card Details**: Agile board issue cards display comprehensive details including subject, project name, tracker name, issue ID, estimated time, start date, due date, completion percentage, tags, assignee name, issue priority, story points, and thumbnails .
- **Dynamically Cards Fields**:  View detailed issue information dynamically within the card view
- **Full Screen Mode**:  Maximize visibility and focus by utilizing the full screen mode
- **Filter Data**: Easily filter data to view specific tasks or information
- **Search Issue Functionality**:  Efficiently search for issues by subject within the Agile Board interface.
- **Dynamically Issue Status**: Display status columns dynamically based on project requirements
- **User-Friendly Interface**: Enjoy a more intuitive and user-friendly experience with optimized interfaces and interactions, ensuring smoother navigation and enhanced usability for all users.
- **Backlog Agile Board Page**: Introducing a dedicated Backlog Agile Board page, designed to organize tasks based on versions and sprints. Easily prioritize and plan tasks according to project milestones, enhancing project management efficiency.
- **Integrate Agile Board into My Page**: Seamlessly incorporate the Agile Board feature directly into My page, ensuring convenient access to task management functionalities without navigating away from your workspace.
- **Issue to Card Conversion**: Seamlessly convert issues into cards and display them in an agile view directly from the issue page, enhancing accessibility and flexibility in task management.
- **Expand/Collapse Columns**: Enhance user experience by providing the ability to expand and collapse columns within the agile board, allowing users to focus on specific stages of their workflow while reducing clutter and optimizing visibility



# Uninstallation   

To uninstall the Agile Board Plugin, follow these steps: 
   - Go to the Agile Board Plugin directory in Redmine. 
   - Delete the entire Agile Board  directory from Redmine/plugins directory. This step removes the plugin files from your Redmine installation. 
   - If the plugin required a migration, run the following command to downgrade your database (make a db backup before) 

   ```sh
       Bundle exec rake redmine:plugins:migrate Name=plugin name VERSION=0  RAILS_ENV=production 
   ```

   - Restart the Redmine server to see the changes. 
   - This will uninstall the Agile Board Plugin from Redmine


# Version Compatibility  

  Redmien Versions 
   - 4.0.x, 4.1.x, 4.2.x 
   - 5.0.x 
   - 6.0.x(coming soon) 



# Library

In this plugin, we utilize libraries to enhance its functionality:

**Kanban Library:** 
The Kanban library utilized in this plugin facilitates drag-and-drop functionality for managing cards representing tasks within the workflow visualization .

**Textile Library:**
The textile library employed in this plugin transforms issue data into a readable and structured format using Textile markup, enhancing the presentation and clarity of information .